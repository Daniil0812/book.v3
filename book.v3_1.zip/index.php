<html>

<head>
        <meta content="text/html; charset=UTF-8" http-equiv="content-type">
        <link rel="stylesheet" href="style.css">
        <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/4.3.1/minty/bootstrap.min.css">
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

</head>
<div class="block" data-attr="<?= $_GET["number"]; ?>"></div>

<body class="c70 c89">
        <div class="paginator" onclick="pagination(event)">
                <nav aria-label="Page navigation example">
                        <ul class="pagination">
                        </ul>
                </nav>
        </div>



        <div class="papper">
                <!-- 1 -->
                <div data-num="1" class="numNUMBER page-mimi" id="container-pagnation1">
                        <p class="c75 c110 c118" style="width: 650px;"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 650px; height: 750px;"><img
                                                alt="" src="images/image71.jpg"
                                                style="width: 650px; height: 750px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                </div>

                <!-- 2 -->
                <div data-num="2" class="numNUMBER page-mimi" id="container-pagnation2">
                        <h1 class="c97" id="h.sv1w9zi0yc92">
                                <span>Дисклеймер:</span><span>&nbsp;</span>
                        </h1>
                        <p class="c25"><span class="c6"></span></p>
                        <ol class="c9 lst-kix_nssuzlkf10db-0 start" start="1">
                                <li class="c72 c116 li-bullet-0"><span class="c0">Это
                                                предварительная
                                                версия книги, она
                                                находится в
                                                состоянии
                                                доработки. Зато
                                                пока вы можете
                                                прочитать её
                                                первыми и
                                                совершенно
                                                бесплатно. </span></li>
                        </ol>
                        <p class="c72 c54"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_nssuzlkf10db-0" start="2">
                                <li class="c72 c116 li-bullet-0"><span class="c0">Автор
                                                будет
                                                признателен за
                                                комментарии и
                                                постарается
                                                учесть их в
                                                работе. </span></li>
                        </ol>
                        <p class="c72"><span class="c4">Комментарии
                                        можно оставлять в
                                        версии в Google Doc: </span><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://docs.google.com/document/d/1k5sqORRfKu9Xh0mgzBcWG0dLsx6qKQ0JMvZfsdEkSuw/edit?usp%3Dsharing&amp;sa=D&amp;source=editors&amp;ust=1614119598389000&amp;usg=AOvVaw2ZSJQyOQypJYzG3q9eUTtV">https://docs.google.com/document/d/1k5sqORRfKu9Xh0mgzBcWG0<br>dLsx6qKQ0JMvZfsdEkSuw/edit?usp=sharing</a></span>
                        </p>
                        <p class="c54 c72"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_nssuzlkf10db-0" start="3">
                                <li class="c72 c116 li-bullet-0"><span class="c0">Контакты
                                                автора: </span></li>
                        </ol>
                        <p class="c72 c54"><span class="c0"></span></p>
                        <p class="c28"><span class="c4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span
                                        class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://www.facebook.com/mushtuk&amp;sa=D&amp;source=editors&amp;ust=1614119598390000&amp;usg=AOvVaw3FOdCdkjU5zcCnTFaLr3iE">https://www.facebook.com/mushtuk</a></span>
                        </p>
                        <p class="c28"><span class="c4 c20"><a class="c2"
                                                href="mailto:sergey@mushtuk.ru">sergey@mushtuk.ru</a></span></p>
                        <p class="c28"><span class="c0">@SergeyMushtuk</span></p>
                        <p class="c28"><span class="c4">+79099994402</span></p>
                        <p class="c56"><span class="c0">©&nbsp;Сергей
                                        Муштук,&nbsp;2020</span></p>
                </div>

                <!-- 3 -->
                <div data-num="3" class="numNUMBER page-mimi" id="container-pagnation3">
                        <p class="c28 c54"><span class="c0"><br> </span></p>
                        <p class="c8"><span class="c4">Здесь вы
                                        познакомитесь</span><span class="c4 c10">&nbsp;</span><span
                                        class="c4">со</span><span class="c4 c10">&nbsp;сквозной
                                        аналитик</span><span class="c4">ой</span><span
                                        class="c4 c10">&nbsp;в&nbsp;маркетинге.
                                        Зачем она нужна,
                                        и&nbsp;как правильно
                                </span><span class="c4 c10">её</span><span class="c0">&nbsp;выстроить.</span></p>
                        <p class="c8"><span class="c4">Узнаете</span><span class="c0">,
                                        как связать сайт, CRM,
                                        рекламные каналы
                                        и&nbsp;методы
                                        коммуникации
                                        в&nbsp;единую систему.
                                        Как&nbsp;определить,
                                        какие рекламные
                                        каналы выгодны,
                                        а&nbsp;какие&nbsp;нет.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">П</span><span class="c4 c10">ознакоми</span><span
                                        class="c4">тесь</span><span class="c0">&nbsp;с
                                        популярными
                                        системами и
                                        инструментами,
                                        которые помогут
                                        эффективно
                                        управлять
                                        бизнес-процессами.</span>
                        </p>
                        <p class="c8"><span class="c4 c10">Со&nbsp;сквозной
                                        аналитикой
                                        повышается
                                        эффективность
                                        digital-рекламы.
                                        Компании, которые
                                </span><span class="c4">о</span><span class="c4 c10">тслеживают</span><span
                                        class="c4">&nbsp;</span><span class="c4 c10">всё
                                        и&nbsp;принимают
                                        решения
                                        на&nbsp;основе данных
                                        выи</span><span class="c4">грывают
                                        конкурентную
                                        гонку</span><span class="c4 c10">.</span><span class="c4 c10">&nbsp;Поэтому
                                </span><span class="c4">можно сказать
                                        что сквозная
                                        аналитика
                                        жизненно
                                        необходима.</span></p>
                </div>

                <!-- 4 -->
                <div data-num="4" class="numNUMBER page-mimi" id="container-pagnation4">
                        <h1 class="c96 c102"><span class="c3">Предисловие</span></h1>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Тучные годы
                                        высоких цен
                                        на&nbsp;нефть прошли,
                                        экономика
                                        прекратила
                                        бурный рост,
                                        и&nbsp;перед бизнесом
                                        возникла
                                        необходимость
                                        задуматься
                                        об&nbsp;эффективности
                                        работы всех
                                        направлений,
                                        включая
                                        маркетинг. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Вопрос
                                        эффективного
                                        управления
                                        маркетинговым
                                        бюджетом давно
                                        назрел, но&nbsp;только
                                        с&nbsp;появлением
                                        digital-каналов на&nbsp;него
                                        получилось
                                        ответить
                                        достаточно точно.
                                </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Сейчас даже
                                        малый бизнес
                                        имеет
                                        возможность
                                        быстро запустить
                                        рекламу для
                                        любого сегмента
                                        аудитории,
                                        настроить
                                        несколько
                                        рекламных
                                        каналов
                                        и&nbsp;оценить их
                                        реальную
                                        эффективность
                                        в&nbsp;продажах
                                        продукта. Именно
                                        об&nbsp;этом данная
                                        книга&nbsp;— о
                                        настройке
                                        сквозной
                                        бизнес-аналитики,
                                        т.е. аналитики,
                                        отслеживающей
                                        путь клиента
                                        от&nbsp;первого
                                        рекламного
                                        касания
                                        и&nbsp;до&nbsp;совершения
                                        сделки, а&nbsp;также
                                        повторных
                                        сделок.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Книга будет
                                        полезна
                                        интернет-маркетологам,
                                        работающим
                                        в&nbsp;сегменте
                                        малого
                                        и&nbsp;среднего
                                        бизнеса. Стоит
                                        заметить, что
                                        в&nbsp;малом бизнесе
                                        практикующим
                                        интернет-маркетологом
                                        часто является
                                        сам собственник
                                        бизнеса.</span></p>
                        <h1 class="c102 c96"><span class="c3">Базовые
                                        понятия</span></h1>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Для начала,
                                        рассмотрим, как
                                        именно работает
                                        реклама в
                                        интернете, как она
                                        оплачивается, и
                                        какие существуют
                                        метрики </span><span class="c4">её</span><span
                                        class="c0">&nbsp;измерения.</span></p>

                </div>

                <!-- 5 -->
                <div data-num="5" class="numNUMBER page-mimi" id="container-pagnation5">
                        <h2 class="c74 c65" id="h.33ue0k7nfysw"><span class="c53">Виды
                                        источников</span><span class="c22 c10">&nbsp;</span></h2>
                        <p class="c8"><span class="c0">Самыми
                                        популярными
                                        средствами
                                        привлечения
                                        клиентов для
                                        малого и среднего
                                        бизнеса являются
                                        контекстная
                                        реклама,
                                        таргетированная
                                        реклама и SEO
                                        (органический
                                        поиск). Но в целом,
                                        источников
                                        привлечения
                                        гораздо больше:
                                        это не только
                                        онлайн и не только
                                        реклама.</span></p>
                        <p class="c7"><span class="c6"></span></p>
                        <p class="c74"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 720.00px; height: 494.67px;"><img
                                                alt="" src="images/image51.jpg"
                                                style="width: 720.00px; height: 494.67px; margin-left: -125px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c0">Разумеется,
                                        не&nbsp;все каналы
                                        подходят
                                        конкретной
                                        компании
                                        и&nbsp;конкретному
                                        бизнесу,
                                        но&nbsp;в&nbsp;большинстве
                                        случаев
                                        задействованными
                                        оказываются
                                        далеко не&nbsp;все
                                        даже из
                                        подходящих.
                                        Почему так
                                        происходит? Что
                                        мешает
                                        попробовать всё
                                        и&nbsp;оставить
                                        только
                                        эффективное?
                                        Ответ прост&nbsp;—
                                        мешает
                                        отсутствие
                                        инструмента
                                        анализа
                                        эффективности
                                        вложений
                                        в&nbsp;рекламу.</span></p>
                </div>

                <!-- 6 -->
                <div data-num="6" class="numNUMBER page-mimi" id="container-pagnation6">
                        <p class="c14"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Мы
                                        рассмотрели,
                                        сколько
                                        вариантов
                                        привлечения
                                        трафика
                                        существует.
                                        Теперь
                                        рассмотрим
                                        каналы обращений
                                        клиента:</span></p>

                        <p class="c5"><span class="c0"></span></p>
                        <h2 class="c74 c65" id="h.ohnwfxaa9isf"><span>Каналы
                                        коммуникаций</span></h2>
                        <p class="c74"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 462.50px; height: 298.68px;"><img
                                                alt="" src="images/image21.png"
                                                style="width: 462.50px; height: 298.68px; margin-left: -20px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                </div>

                <!-- 7 -->
                <div data-num="7" class="numNUMBER page-mimi" id="container-pagnation7">
                        <h2 class="c65 c67" id="h.z39lrnf9nfe1"><span class="c22 c10">Путь
                                        клиента</span></h2>
                        <p class="c46 c93"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Самый простой
                                        путь клиента
                                        представлен ниже.
                                        Человек видит
                                        рекламу, нажимает
                                        на неё, затем
                                        попадает на сайт и
                                        делает там заказ.
                                        В реальной жизни
                                        всё гораздо
                                        сложнее, но пока
                                        рассмотрим
                                        условные
                                        простейшие
                                        варианты.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 500px; height: 169.25px;"><img
                                                alt="" src="images/image66.png"
                                                style="width: 376.50px; height: 169.25px; margin-left: 40px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <h2 class="c74 c65" id="h.d14vqgvu538l"><span class="c22 c10">Модели
                                        продаж рекламы:</span></h2>
                        <p class="c8"><span class="c0">В зависимости
                                        от формата
                                        рекламы, на рынке
                                        сложилось
                                        несколько
                                        моделей оплаты
                                        рекламы.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 8 -->
                <div data-num="8" class="numNUMBER page-mimi" id="container-pagnation8">
                        <ol class="c9 lst-kix_1wqrhc540kn2-0 start" start="1">
                                <li class="c35 li-bullet-0">
                                        <h3 id="h.cv1qdz7qn86o" style="display:inline">
                                                <span>&nbsp;</span><span>В</span><span>ыкуп
                                                        рекламной
                                                        площади
                                                        целиком</span>
                                        </h3>
                                </li>
                        </ol>
                        <p class="c8"><span class="c0">Традиционная
                                        модель из
                                        офлайн-эпохи.</span></p>
                        <p class="c8"><span class="c0">Где
                                        применяется:</span></p>
                        <p class="c8"><span class="c0">• Наружная
                                        реклама</span></p>
                        <p class="c8"><span class="c0">• Реклама
                                        в&nbsp;печатных&nbsp;СМИ</span></p>
                        <p class="c8"><span class="c0">• Отдельные
                                        сайты в
                                        интернете</span></p>
                        <p class="c8"><span class="c0">• SEO с оплатой за
                                        позиции</span></p>
                        <p class="c8"><span class="c0">Покупается
                                        факт размещения.
                                        Нет гарантий даже
                                        по числу
                                        рекламных
                                        касаний.</span></p>
                        <ol class="c9 lst-kix_1wqrhc540kn2-0" start="2">
                                <li class="c35 li-bullet-0">
                                        <h3 id="h.ufeb1b6we883" style="display:inline"><span>&nbsp;</span><span
                                                        class="c11 c10">Рекламные
                                                        показы Pay-Per-Impression (PPI) или
                                                        же Cost-Per-Mille (CPM)</span></h3>
                                </li>
                        </ol>
                        <p class="c8"><span class="c4 c10">Оплата
                                        за&nbsp;показ</span><span class="c4">ы,
                                        обычно за 1000</span><span class="c0">. Т.е.
                                        гарантируется
                                        число рекламных
                                        касаний, не
                                        гарантируется
                                        всё остальное.</span></p>
                        <p class="c8"><span class="c4">Примеры:</span></p>
                        <p class="c8"><span class="c0">• Медийная
                                        реклама</span></p>
                        <p class="c8"><span class="c0">•
                                        Видеореклама</span></p>
                        <p class="c8"><span class="c0">•
                                        Таргетированная
                                        и контекстная
                                        реклама (иногда)</span></p>
                        <ol class="c9 lst-kix_1wqrhc540kn2-0" start="3">
                                <li class="c35 li-bullet-0">
                                        <h3 id="h.ckpaf0x4qwhl" style="display:inline"><span>&nbsp;</span><span
                                                        class="c11 c10">Переходы по
                                                        рекламе, клики Pay-Per-Click
                                                        (PPC) </span></h3>
                                </li>
                        </ol>
                        <p class="c8"><span class="c0">Оплачивается
                                        клик по
                                        рекламному
                                        объявлению. </span></p>
                        <p class="c8"><span class="c0">Примеры:</span></p>
                        <p class="c8"><span class="c0">• Контекстная
                                        реклама</span></p>
                        <p class="c8"><span class="c4">•</span><span class="c4">&nbsp;Таргетированная</span><span
                                        class="c0">&nbsp;реклама</span></p>
                        <p class="c8"><span class="c0">• SEO c с&nbsp;оплатой
                                        по&nbsp;трафику</span></p>
                        <ol class="c9 lst-kix_1wqrhc540kn2-0" start="4">
                                <li class="c35 li-bullet-0">
                                        <h3 id="h.dlwow9nrlac1" style="display:inline"><span class="c10 c11">Лиды —
                                                        т.е. заявки Cost-Per-Action (CPA)</span></h3>
                                </li>
                        </ol>
                        <p class="c8"><span class="c0">Оплачивается
                                        конкретное,
                                        выбранное
                                        рекламодателем
                                        действие. Обычно
                                        это заявка,
                                        содержащая
                                        контактные
                                        данные. Также
                                        называется
                                        лидом.</span></p>
                        <p class="c8"><span class="c0">Примеры:</span></p>
                        <p class="c8"><span class="c0">• CPA-сети</span></p>
                        <p class="c8"><span class="c0">• Колл-центры
                                        и&nbsp;лидогенераторы</span>
                        </p>

                </div>

                <!-- 9 -->
                <div data-num="9" class="numNUMBER page-mimi" id="container-pagnation9">
                        <ol class="c9 lst-kix_1wqrhc540kn2-0" start="5">
                                <li value="5" class="c35 li-bullet-0">
                                        <h3 id="h.61of2c4w9hez" style="display:inline"><span class="c29">Процент с
                                                        продаж </span><span>(Revenue share</span><span
                                                        class="c11 c10">)</span></h3>
                                </li>
                        </ol>
                        <p class="c46"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c4 c10">И, наконец,
                                        можно платить
                                        только
                                        за&nbsp;клиентов,
                                        которые
                                        совершили
                                        покупку. </span><span class="c4">При
                                        этом, платить
                                        можно как
                                        фиксированную
                                        стоимость, так и % с
                                        выручки, либо
                                        прибыли.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Примеры:</span></p>
                        <p class="c8"><span class="c0">• Партнёрские
                                        программы</span></p>
                        <p class="c8"><span class="c0">• CPA-сети</span></p>
                        <p class="c28"><span class="c4">• Активные
                                        продажи
                                        (менеджеры по
                                        продажам обычно
                                        имеют небольшой
                                        оклад + % с продаж)</span>
                        </p>
                        <hr style="page-break-before:always;display:none;">
                        <p></p>
                </div>

                <!-- 10 -->
                <div data-num="10" class="numNUMBER page-mimi" id="container-pagnation10">
                        <h2 class="c74 c65" id="h.smfdazcjrbr5"><span class="c23">Конверсия</span></h2>
                        <h2 class="c74 c65" id="h.e6dvi1gey1z1"><span class="c6">Одним
                                        из&nbsp;базовых
                                        понятий
                                        интернет-маркетинга
                                        является
                                        конверсия.</span></h2>
                        <p class="c62 c92"><span class="c10 c73">Конверсия</span><span
                                        class="c4 c10">&nbsp;в&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%2598%25D0%25BD%25D1%2582%25D0%25B5%25D1%2580%25D0%25BD%25D0%25B5%25D1%2582-%25D0%25BC%25D0%25B0%25D1%2580%25D0%25BA%25D0%25B5%25D1%2582%25D0%25B8%25D0%25BD%25D0%25B3&amp;sa=D&amp;source=editors&amp;ust=1614119598402000&amp;usg=AOvVaw1FnYnx0oAyQIDJ84EAW_EW">интернет-маркетинге</a></span><span
                                        class="c4 c10">&nbsp;— это
                                        отношение числа
                                        посетителей&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%25A1%25D0%25B0%25D0%25B9%25D1%2582&amp;sa=D&amp;source=editors&amp;ust=1614119598402000&amp;usg=AOvVaw0qBn5wYUaiBefvPH6Ttr7_">сайта</a></span><span
                                        class="c4 c10">, выполнивших
                                        на&nbsp;нём какие-либо
                                        целевые действия
                                        (скрытые или
                                        прямые указания
                                        рекламодателей,
                                        продавцов,
                                        создателей&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%259A%25D0%25BE%25D0%25BD%25D1%2582%25D0%25B5%25D0%25BD%25D1%2582&amp;sa=D&amp;source=editors&amp;ust=1614119598402000&amp;usg=AOvVaw1wn-aWDdjaKWKaqqEaoAPg">контента</a></span><span
                                        class="c4 c10">&nbsp;— покупку,
                                        регистрацию,
                                        подписку,
                                        посещение </span><span class="c4 c10">определённой</span><span
                                        class="c0">&nbsp;страницы
                                        сайта, переход
                                        по&nbsp;рекламной
                                        ссылке), к&nbsp;общему
                                        числу
                                        посетителей
                                        сайта, выраженное
                                        в&nbsp;процентах. (Wikipedia.org)</span><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 528.50px; height: 211.59px;"><img
                                                alt="5d3ed4422589ef0007a6dcab.jpg" src="images/image65.jpg"
                                                style="width: 528.50px; height: 211.59px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c0">Конверсию все
                                        стараются
                                        повысить, считая
                                        её &nbsp;«священным
                                        Граалем»
                                        интернет-маркетинга.
                                        Ведь увеличив
                                        конверсию
                                        в&nbsp;2&nbsp;раза, мы
                                        пропорционально
                                        поднимем продажи
                                        без изменения
                                        рекламного
                                        бюджета. Однако
                                        в&nbsp;реальности
                                        не&nbsp;всё так просто.
                                        Рассмотрим
                                        стандартную
                                        воронку продаж:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 11 -->
                <div data-num="11" class="numNUMBER page-mimi" id="container-pagnation11">
                        <p class="c43"><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 624.00px; height: 422.67px;"><img
                                                alt="" src="images/image38.png"
                                                style="width: 624.00px; height: 422.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c49"><span class="c0">Обычная
                                        воронка продаж</span></p>
                        <p class="c8"><span class="c0">Давайте
                                        разберемся,
                                        действительно&nbsp;ли
                                        конверсия сайта
                                        так значима. </span></p>
                        <p class="c8"><span class="c4">На первый
                                        взгляд кажется,
                                        что важна, т.к.
                                        благодаря </span><span class="c4">её</span><span class="c0">&nbsp;увеличению
                                        можно
                                        существенно
                                        поднять продажи,
                                        не&nbsp;увеличивая
                                        рекламный бюджет.
                                        Но в&nbsp;подавляющем
                                        большинстве
                                        бизнесов воронка,
                                        проходящая через
                                        сайт, далеко не
                                        единственная
                                        и&nbsp;не полная.</span></p>
                        <p class="c8"><span class="c4">&nbsp;Для того,
                                        чтобы конверсия
                                        сайта
                                        пропорционально
                                        соответствовала
                                        прибыльности
                                        инвестиций
                                        в&nbsp;рекламу, нужно:</span>
                        </p>
                        <p class="c8"><span class="c0">1. Продавать
                                        только через сайт
                                        и&nbsp;не&nbsp;иметь
                                        других каналов
                                        продаж
                                        и&nbsp;коммуникации,
                                        например,
                                        офлайн-магазина,
                                        холодного
                                        обзвона,
                                        коммуникации
                                        в&nbsp;социальных
                                        сетях и&nbsp;т.д.</span></p>
                </div>

                <!-- 12 -->
                <div data-num="12" class="numNUMBER page-mimi" id="container-pagnation12">
                        <p class="c8"><span class="c4">2. </span><span class="c0">Чтобы
                                        оформление
                                        заказа на&nbsp;сайте
                                        сопровождалось
                                        онлайн-оплатой,
                                        тогда факт оплаты
                                        можно факт
                                        условно
                                        приравнять к
                                        продаже,
                                        поскольку
                                        процент отказов
                                        после оплаты
                                        обычно
                                        незначителен.</span></p>
                        <p class="c8"><span class="c4">Т.е. </span><span class="c4">приведённая</span><span
                                        class="c0">&nbsp;схема
                                        работает только
                                        для бизнесов
                                        с&nbsp;коротким
                                        циклом принятия
                                        решения
                                        о&nbsp;покупке
                                        и&nbsp;транзакционным
                                        заказом на&nbsp;сайте.
                                        В реальности же,
                                        не так много
                                        бизнесов
                                        осуществляют
                                        продажи через
                                        сайт с
                                        онлайн-оплатой.
                                        В&nbsp;пример можно
                                        привести:</span></p>
                        <ul class="c9 lst-kix_v2zwiuljqlmr-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">Инфобизнес</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Сервисы
                                                доставки&nbsp;еды</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">ПО, игры,&nbsp;SAAS</span></li>
                        </ul>
                        <p class="c8"><span class="c0">В&nbsp;остальных&nbsp;случаях
                                        есть несколько
                                        моментов, которые
                                        не&nbsp;позволяют
                                        рассматривать
                                        конверсию сайта
                                        в&nbsp;отрыве
                                        от&nbsp;других
                                        показателей:</span></p>
                        <p class="c8"><span class="c0">1. Имеются
                                        другие каналы
                                        продаж:</span></p>
                        <ul class="c9 lst-kix_w2qadyzcoozd-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">Офлайн-магазины,
                                                салоны, шоу-румы</span>
                                </li>
                                <li class="c17 li-bullet-2"><span class="c0">Указание
                                                средств
                                                коммуникации
                                                (телефон,&nbsp;email,
                                                мессенджеры
                                                и&nbsp;пр.) напрямую
                                                в&nbsp;рекламных
                                                материалах</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Размещение
                                                прейскуранта
                                                на&nbsp;прайс-площадках,
                                                информации
                                                в&nbsp;каталогах,
                                                справочниках
                                                и&nbsp;т.&nbsp;д.</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Прямые
                                                продажи</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Продажи
                                                через дилеров</span></li>
                        </ul>
                        <p class="c8"><span class="c0">2. Реальный
                                        цикл принятия
                                        решения
                                        о&nbsp;покупке
                                        гораздо длиннее
                                        указанной
                                        воронки. Он
                                        начинается
                                        с&nbsp;формирования
                                        потребности
                                        и&nbsp;поиска
                                        решений</span></p>
                        <hr style="page-break-before:always;display:none;">
                </div>

                <!-- 13 -->
                <div data-num="13" class="numNUMBER page-mimi" id="container-pagnation13">
                        <p class="c8"><span class="c0">Итак, имеет&nbsp;ли
                                        смысл
                                        увеличивать
                                        конверсию сайта?
                                        Да, имеет. Но&nbsp;стоит
                                        учитывать
                                        несколько
                                        моментов:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">1. Конверсия
                                        сайта, если это
                                        конверсия в&nbsp;лид,
                                        является лишь
                                        конверсией 1-го
                                        уровня. Далее </span><span class="c4">идёт</span><span
                                        class="c0">&nbsp;конверсия в
                                        продажу (2 уровень).
                                        &nbsp;Есть также
                                        конверсия 0-го
                                        уровня
                                        из&nbsp;рекламного
                                        либо не
                                        рекламного
                                        касания
                                        в&nbsp;посещение
                                        сайта.</span></p>
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 622.17px; height: 567.50px;"><img
                                                alt="" src="images/image16.png"
                                                style="width: 622.17px; height: 567.50px; margin-left: -60px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c49"><span class="c0">Пример
                                        возможной
                                        воронки продаж</span></p>
                        <p class="c8"><span class="c0">2. Конверсия
                                        сайта сильно
                                        отличается
                                        на&nbsp;разных типах
                                        трафика. Поэтому
                                        информация
                                        об&nbsp;общей
                                        конверсии
                                        не&nbsp;имеет большой
                                        ценности. Нужно,
                                        как минимум,
                                        делить трафик
                                        по&nbsp;источникам
                                        и&nbsp;отсекать
                                        брендовые
                                        поисковые
                                        запросы,
                                        конверсия
                                        которых
                                        значительно
                                        выше.</span></p>

                </div>

                <!-- 14 -->
                <div data-num="14" class="numNUMBER page-mimi" id="container-pagnation14">
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">3. Некоторые
                                        изменения сайта
                                        могут увеличить
                                        видимую
                                        конверсию, просто
                                        переведя клиента
                                        на&nbsp;другой
                                        уровень воронки
                                        продаж. Реальная
                                        совокупная
                                        конверсия от
                                        этого не
                                        изменится.
                                        Например, если
                                        не&nbsp;написать
                                        на&nbsp;сайте цену
                                        товара, звонков
                                        и&nbsp;заявок, </span><span class="c4">то</span><span class="c0">&nbsp;желающих
                                        её
                                        узнать станет
                                        больше. Увеличит
                                        ли это продажи?
                                        Зависит от того,
                                        насколько
                                        компетентны ваши
                                        менеджеры.
                                        Возможно, они
                                        смогут вытянуть
                                        клиента и закрыть
                                        сделку. А
                                        возможно, другие
                                        клиенты просто не
                                        смогут до вас
                                        дозвониться, пока
                                        менеджеры будут
                                        отвечать на одни и
                                        те же вопросы
                                        нецелевой
                                        аудитории, не имея
                                        никаких шансов на
                                        продажу.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h3 class="c15" id="h.nnlppwfrzq3b"><span class="c11 c10">Как
                                        увеличить
                                        конверсию?</span></h3>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">1. Большие
                                        изменения дадут
                                        изменения
                                        продукта, его
                                        цены, способов
                                        оплаты
                                        и&nbsp;доставки,
                                        позиционирования.
                                        Смысл изменения
                                        текстов на&nbsp;сайте
                                        не&nbsp;в&nbsp;том, чтобы
                                        попробовать
                                        другой заголовок,
                                        а&nbsp;в&nbsp;том, чтобы
                                        лучше убедить
                                        аудиторию,
                                        показать ей
                                        преимущества: &nbsp;то,
                                        что важно, а&nbsp;не&nbsp;то,
                                        что и&nbsp;так
                                        понятно.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Важно
                                        понимать рынок
                                        в&nbsp;целом, сроки
                                        принятия решения
                                        и&nbsp;критерии,
                                        по&nbsp;которым
                                        выбирает
                                        покупатель.
                                        Понимать, какая
                                        аудитория
                                        приходит к&nbsp;вам, и
                                        нужно&nbsp;ли её
                                        убеждать
                                        в&nbsp;преимуществах
                                        вашей компании
                                        или вашего товара
                                        перед прямыми
                                        конкурентами.
                                        Например,
                                        продавая
                                        автомобили, вам
                                        не&nbsp;нужно
                                        рассказывать об
                                        их&nbsp;преимуществах
                                        перед
                                        велосипедом
                                        или&nbsp;общественным
                                        транспортом.
                                        Подобные
                                        описания
                                        на&nbsp;сайте
                                        автосалона будут
                                        выглядеть
                                        неуместно. Если же
                                        вы предлагаете
                                        клиентам занятия
                                        йогой, то в этом
                                        случае стоит
                                        уделить внимание
                                        их преимуществам
                                        перед
                                        фитнес-тренировками
                                        или аэробикой. </span></p>

                </div>

                <!-- 15 -->
                <div data-num="15" class="numNUMBER page-mimi" id="container-pagnation15">
                        <p class="c8"><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 532.83px; height: 486.50px;"><img
                                                alt="" src="images/image56.png"
                                                style="width: 532.83px; height: 486.50px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c0">2. Для высокой
                                        конверсии нужно
                                        соответствовать
                                        ожиданиям
                                        клиента, а лучше
                                        превосходить их.
                                        Этому
                                        способствуют:</span></p>
                        <ul class="c9 lst-kix_7dw28p3teyfy-0 start">
                                <li class="c17 li-bullet-2"><span class="c4">Удобный с
                                                точки зрения UX
                                                сайт, не
                                                отпугивающий
                                                дизайном и не
                                                имеющий проблем
                                                с
                                                кроссбраузерностью
                                                и</span><span class="c4">&nbsp;адаптивн</span><span class="c0">остью под
                                                мобильные
                                                устройства;</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Полнота и
                                                качество
                                                информации о
                                                продукте
                                                (описания,
                                                фотографии,
                                                характеристики,
                                                инструкции,
                                                видео, обзоры);</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Репутация
                                                и известность
                                                вашей компании и
                                                компаний, товары
                                                которых вы
                                                продаёте;</span></li>
                                <li class="c17 li-bullet-2"><span class="c4">Подтверждённое</span><span
                                                class="c0">&nbsp;высокое
                                                качество
                                                продукта (как на
                                                вашем сайте, так и
                                                независимыми
                                                источниками —
                                                например,
                                                отзывами,
                                                которые можно
                                                найти в поиске);</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Цена,
                                                бонусы и акции;</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Простая
                                                процедура
                                                оформления
                                                заказа;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Понятные
                                                условия оплаты,
                                                доставки,
                                                гарантийного
                                                обслуживания;</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Условия
                                                работы,
                                                удовлетворяющие
                                                как можно
                                                больший процент
                                                посетителей —
                                                например,
                                                широкий спектр
                                                возможностей
                                                оплаты (онлайн на
                                                сайте, картой или
                                                наличными
                                                курьеру),
                                                возможность
                                                доставки в
                                                разные регионы
                                                различными
                                                способами
                                                (курьерская
                                                служба, почта,
                                                транспортные
                                                компании).</span></li>
                        </ul>
                </div>

                <!-- 16 -->
                <div data-num="16" class="numNUMBER page-mimi" id="container-pagnation16">
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Как видим,
                                        дизайн и удобство
                                        сайта являются
                                        необходимым, но
                                        недостаточным
                                        требованием для
                                        высокой
                                        конверсии. Без
                                        конкурентоспособного
                                        продукта и
                                        адекватного
                                        ценообразования
                                        никакой сайт не
                                        сможет
                                        обеспечить
                                        хороший поток
                                        заказов.</span></p>
                        <p class="c28 c54"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">3. В&nbsp;целом, сайт
                                        должен нравиться
                                        клиентам,
                                        а&nbsp;не&nbsp;вам.
                                        Например, если
                                        клиенты&nbsp;—
                                        проектировщики,
                                        прорабы,
                                        сотрудники &nbsp;НИИ и
                                        проектных
                                        институтов,
                                        привыкшие
                                        к&nbsp;сухой
                                        документации,
                                        лендинг
                                        с&nbsp;красивой
                                        визуализацией
                                        на&nbsp;них
                                        впечатления
                                        не&nbsp;произведет,
                                        а&nbsp;сайт
                                        с&nbsp;объёмными
                                        текстами
                                        не&nbsp;вызовет
                                        вопросов
                                        и&nbsp;не&nbsp;покажется
                                        устаревшим, каким
                                        мог&nbsp;бы выглядеть
                                        в глазах
                                        молодёжной
                                        аудитории.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Если у&nbsp;вас
                                        «горячие»
                                        клиенты, и&nbsp;время
                                        принятия решения
                                        минимально, важны,
                                        в&nbsp;первую очередь,
                                        цена
                                        и&nbsp;доступность
                                        контакта. Если
                                        решение
                                        принимается
                                        долго, сумма
                                        сделки большая,
                                        а&nbsp;конверсия
                                        перетекает
                                        на&nbsp;более низкий
                                        уровень (общение
                                        с&nbsp;менеджером), то в
                                        этом случае
                                        от&nbsp;сайта
                                        достаточно
                                        не&nbsp;отталкивать
                                        клиента, добиться
                                        первоначального
                                        обращения,
                                        но&nbsp;никакие
                                        средства
                                        повышения
                                        конверсии
                                        не&nbsp;позволят
                                        существенно
                                        повлиять
                                        на&nbsp;продажи.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Резюмируя</span><span class="c0">: гнаться нужно
                                        не&nbsp;столько
                                        за&nbsp;конверсией
                                        сайта, сколько за
                                        конверсией
                                        бизнеса в&nbsp;целом
                                        и&nbsp;его
                                        прибыльностью.
                                        Доход зависит
                                        от&nbsp;таких
                                        факторов, как:<br></span></p>
                        <ul class="c9 lst-kix_vy5xh13pfqmi-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">Базовые
                                                показатели
                                                эффективности
                                                рекламы
                                                (например,
                                                стоимость
                                                касания);</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Конверсия
                                                1-го уровня (обычно,
                                                конверсия
                                                сайта);</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Конверсия
                                                2-го уровня (обычно,
                                                конверсия
                                                отдела продаж);</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Удовлетворённость
                                                клиента, которая
                                                приносит
                                                повторные
                                                продажи и
                                                продажи по
                                                рекомендациям
                                                (сарафанное
                                                радио).</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p><a id="id.3dy6vkm"></a><a id="id.tyjcwt"></a>
                </div>

                <!-- 17 -->
                <div data-num="17" class="numNUMBER page-mimi" id="container-pagnation17">
                        <h2 class="c113 c81 c65"><span class="c22 c10">ROI (ROMI)</span></h2>
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 509.45px; height: 402.50px;"><img
                                                alt="" src="images/image8.png"
                                                style="width: 509.45px; height: 402.50px; margin-left: -30px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c49"><span class="c4 c10">Рекламное
                                        агентство
                                        обещает клиентам
                                        выс</span><span class="c4">ок</span><span class="c0">ий&nbsp;ROI</span></p>
                        <p class="c92 c76"><span class="c10 c73">ROI</span><span
                                        class="c4 c10">&nbsp;(от&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%2590%25D0%25BD%25D0%25B3%25D0%25BB%25D0%25B8%25D0%25B9%25D1%2581%25D0%25BA%25D0%25B8%25D0%25B9_%25D1%258F%25D0%25B7%25D1%258B%25D0%25BA&amp;sa=D&amp;source=editors&amp;ust=1614119598410000&amp;usg=AOvVaw1s5NUWG7Gyx_CcxP676ZKL">англ.</a></span><span
                                        class="c4 c10">&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://en.wikipedia.org/wiki/Return_on_investment&amp;sa=D&amp;source=editors&amp;ust=1614119598410000&amp;usg=AOvVaw1v8nVHKN7rrUPCJO1NDAk9">return
                                                on investment</a></span><span class="c4 c10">) или&nbsp;</span><span
                                        class="c10 c73">ROR</span><span class="c4 c10">&nbsp;(</span><span
                                        class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%2590%25D0%25BD%25D0%25B3%25D0%25BB%25D0%25B8%25D0%25B9%25D1%2581%25D0%25BA%25D0%25B8%25D0%25B9_%25D1%258F%25D0%25B7%25D1%258B%25D0%25BA&amp;sa=D&amp;source=editors&amp;ust=1614119598411000&amp;usg=AOvVaw1YpiF9LAH0bQhDmK9F1W7y">англ.</a></span><span
                                        class="c4 c10">&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://en.wikipedia.org/wiki/Rate_of_return&amp;sa=D&amp;source=editors&amp;ust=1614119598411000&amp;usg=AOvVaw1qf8Fye--p63_ueNryiGY0">rate
                                                of&nbsp;return</a></span><span class="c4 c10">)&nbsp;— </span><span
                                        class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%25A4%25D0%25B8%25D0%25BD%25D0%25B0%25D0%25BD%25D1%2581%25D1%258B&amp;sa=D&amp;source=editors&amp;ust=1614119598411000&amp;usg=AOvVaw0VczUmq0PNmphFsoIrkW_9">финансовый</a></span><span
                                        class="c4 c10">&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%259A%25D0%25BE%25D1%258D%25D1%2584%25D1%2584%25D0%25B8%25D1%2586%25D0%25B8%25D0%25B5%25D0%25BD%25D1%2582&amp;sa=D&amp;source=editors&amp;ust=1614119598411000&amp;usg=AOvVaw2UmsjbFj4F_bYg48LeaCVc">коэффициент</a></span><span
                                        class="c4 c10">,
                                        иллюстрирующий
                                        уровень
                                        доходности или
                                        убыточности&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%2591%25D0%25B8%25D0%25B7%25D0%25BD%25D0%25B5%25D1%2581&amp;sa=D&amp;source=editors&amp;ust=1614119598412000&amp;usg=AOvVaw0PUvJ-H7TQmBABbWkUuu2a">бизнеса</a></span><span
                                        class="c4 c10">, учитывая
                                        сумму сделанных
                                        в&nbsp;этот бизнес
                                        инвестиций. ROI
                                        обычно
                                        выражается
                                        в&nbsp;процентах,
                                        реже&nbsp;— в&nbsp;виде
                                        дроби. Этот
                                        показатель может
                                        также иметь
                                        следующие
                                        названия: </span><span class="c4 c18">прибыль
                                        на&nbsp;инвестированный
                                        капитал, прибыль
                                        на&nbsp;инвестиции,
                                        возврат,
                                        доходность
                                        инвестированного
                                        капитала, норма
                                        доходности.</span></p>
                </div>

                <!-- 18 -->
                <div data-num="18" class="numNUMBER page-mimi" id="container-pagnation18">
                        <p class="c88"><span class="c4 c10">Показатель ROI
                                        является
                                        отношением суммы
                                        прибыли или
                                        убытков к&nbsp;сумме
                                        инвестиций.
                                        Значением
                                        прибыли может
                                        быть&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%259F%25D1%2580%25D0%25BE%25D1%2586%25D0%25B5%25D0%25BD%25D1%2582%25D0%25BD%25D1%258B%25D0%25B9_%25D0%25B4%25D0%25BE%25D1%2585%25D0%25BE%25D0%25B4&amp;sa=D&amp;source=editors&amp;ust=1614119598412000&amp;usg=AOvVaw0GAOu5M52xEfqnulBNOqYC">процентный
                                                доход</a></span><span class="c4 c10">, </span><span
                                        class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%259F%25D1%2580%25D0%25B8%25D0%25B1%25D1%258B%25D0%25BB%25D1%258C&amp;sa=D&amp;source=editors&amp;ust=1614119598412000&amp;usg=AOvVaw1tNv27XUBvqFE9CIpu8pii">прибыль</a></span><span
                                        class="c4 c10">/убытки
                                        по&nbsp;бухгалтерскому
                                </span><span class="c4 c10">учёту</span><span class="c4 c10">,
                                        прибыль/убытки
                                        по&nbsp;управленческому
                                        учёту или&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%25A7%25D0%25B8%25D1%2581%25D1%2582%25D0%25B0%25D1%258F_%25D0%25BF%25D1%2580%25D0%25B8%25D0%25B1%25D1%258B%25D0%25BB%25D1%258C&amp;sa=D&amp;source=editors&amp;ust=1614119598413000&amp;usg=AOvVaw3xRwuadESNUhT03w79TJFa">чистая
                                                прибыль</a></span><span class="c4 c10">/убыток.
                                        Значением суммы
                                        инвестиций могут
                                        быть&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%2590%25D0%25BA%25D1%2582%25D0%25B8%25D0%25B2&amp;sa=D&amp;source=editors&amp;ust=1614119598413000&amp;usg=AOvVaw0GggMw4YdJnf1Kj7p5yRL2">активы</a></span><span
                                        class="c4 c10">, </span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%259A%25D0%25B0%25D0%25BF%25D0%25B8%25D1%2582%25D0%25B0%25D0%25BB&amp;sa=D&amp;source=editors&amp;ust=1614119598413000&amp;usg=AOvVaw3oEupUqEYe0rG9DsjxjN7O">капитал</a></span><span
                                        class="c4 c10">, сумма
                                        основного&nbsp;</span><span class="c4 c20 c26"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%2594%25D0%25BE%25D0%25BB%25D0%25B3&amp;sa=D&amp;source=editors&amp;ust=1614119598414000&amp;usg=AOvVaw3SAPDRiaohCb3huFvJV7rp">долга</a></span><span
                                        class="c0">&nbsp;бизнеса
                                        и&nbsp;другие
                                        выраженные
                                        в&nbsp;деньгах
                                        инвестиции.</span></p>
                        <p class="c8"><span class="c0">В&nbsp;предыдущей
                                        главе мы поняли,
                                        что конверсия
                                        сайта
                                        не&nbsp;является
                                        достоверным
                                        показателем,
                                        отвечающим
                                        за&nbsp;выгодность
                                        интернет-маркетинга.
                                        Но что&nbsp;же таковым
                                        является?
                                        Компании тратят
                                        деньги
                                        на&nbsp;рекламу,
                                        привлекают
                                        клиентов,
                                        получают прибыль
                                        с&nbsp;продаж своих
                                        товаров и&nbsp;услуг.
                                        Логично будет
                                        применить
                                        к&nbsp;интернет-маркетингу
                                        показатель
                                        возврата
                                        инвестиций ROI,
                                        а&nbsp;точнее, ROMI.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c70">Return on Marketing Investment или
                                        сокращенно&nbsp;</span><span class="c73 c70">ROMI</span><span
                                        class="c4 c70">&nbsp;</span><span class="c4">—</span><span
                                        class="c4 c70">&nbsp;это
                                        показатель
                                        рентабельности
                                        рекламных
                                        кампаний и в целом
                                        инвестиций в
                                        маркетинговую
                                        деятельность.
                                        Рентабельность
                                        оперирует такими
                                        метриками, как
                                        окупаемость,
                                        прибыль, возврат
                                        вложений.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c10">Какую бы
                                        модель оплаты мы
                                        ни использовали,
                                        важно </span><span class="c4">считать</span><span class="c4 c10">&nbsp;возврат
                                        инвестиций, и
                                        именно для этого
                                </span><span class="c4">существует</span><span class="c0">&nbsp;показатель ROMI.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Кажется, или
                                        мы нашли
                                        показатель,
                                        которым стоит
                                        измерять
                                        эффективность
                                        рекламы? И&nbsp;да,
                                        и&nbsp;нет: сам по&nbsp;себе
                                        показатель
                                        возврата
                                        инвестиций хорош,
                                        но, как всегда,
                                        есть важные
                                        нюансы. Посмотрим,
                                        почему&nbsp;же
                                        высокий ROI это
                                        хорошо и&nbsp;почему
                                        это плохо. И
                                        сейчас перед нам
                                        стоят два вопроса:
                                        как и что
                                        считать?</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Посчитать </span><span class="c4">ROMI</span><span
                                        class="c0">&nbsp;не&nbsp;так
                                        просто, как
                                        кажется.
                                        Посмотрим
                                        на&nbsp;простом
                                        примере.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 19 -->
                <div data-num="19" class="numNUMBER page-mimi" id="container-pagnation19">
                        <p class="c8"><span class="c0">Отчётность
                                        компании ООО
                                        «Ромашка»
                                        за&nbsp;январь
                                        2019&nbsp;года:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">• Затраты
                                        на&nbsp;рекламу:
                                        120&nbsp;000&nbsp;рублей</span></p>
                        <p class="c8"><span class="c0">• Продажи
                                        700&nbsp;000&nbsp;рублей</span></p>
                        <p class="c8"><span class="c4">•
                                        Маржинальный
                                        доход (без
                                        рекламных
                                        вложений)
                                        210&nbsp;000&nbsp;рублей</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c49"><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 268.50px; height: 46.43px;"><img
                                                alt="" src="images/image40.png"
                                                style="width: 268.50px; height: 46.43px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c54 c119"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">ROMI равен&nbsp;75%</span><span class="c4">.
                                </span><span class="c0">Коэффициент
                                        выше 0, т.е. вроде бы
                                        всё хорошо.
                                        Но&nbsp;всё&nbsp;ли
                                        правильно мы
                                        посчитали?</span></p>
                        <p class="c28 c54"><span class="c0"></span></p>
                        <p class="c28"><span class="c4">Представим,
                                        что застройщик
                                        построил новый ЖК,
                                        создал для него
                                        сайт и&nbsp;запустил
                                        рекламную
                                        кампанию. Вот
                                        статистика
                                        за&nbsp;первые
                                        полгода:</span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 624.00px; height: 286.67px;"><img
                                                alt="" src="images/image64.jpg"
                                                style="width: 624.00px; height: 286.67px; margin-left: -75px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c49 c54"><span class="c0"></span></p>
                        <p class="c49 c54"><span class="c0"></span></p>
                </div>

                <!-- 20 -->
                <div data-num="20" class="numNUMBER page-mimi" id="container-pagnation20">
                        <p class="c49"><span class="c0">Статистика
                                        продаж квартир</span></p>
                        <p class="c8"><span class="c4">Что&nbsp;же мы
                                        видим? В&nbsp;первые
                                        3&nbsp;месяца продаж
                                        нет. Если считать
                                        &nbsp;ROMI по&nbsp;месяцам,
                                        кажется, что
                                        реклама
                                        не&nbsp;работает.
                                        Но&nbsp;потом
                                        появляются
                                        первые продажи.
                                        Делаем вывод, что
                                        люди, пришедшие
                                        по&nbsp;рекламе
                                        в&nbsp;первые месяцы,
                                        покупают
                                        не&nbsp;сразу.
                                        Соответственно,
                                        если построить
                                        управленческий
                                </span><span class="c4">отчёт</span><span class="c4">&nbsp;за
                                </span><span class="c4">определённый</span><span class="c4">&nbsp;период,
                                        указывая все
                                        затраты и&nbsp;все
                                        продажи, он будет
                                        некорректным
                                        с&nbsp;точки зрения
                                        возврата
                                        инвестиций
                                        в&nbsp;рекламу. Только
                                        в&nbsp;бизнесах
                                        с&nbsp;моментальным
                                        спросом такой </span><span class="c4">отчёт</span><span class="c0">&nbsp;будет
                                        приближённо
                                        отражать
                                        реальную
                                        ситуацию.</span></p>
                        <p class="c74"><span class="c10 c73">Сквозной
                                        принцип в
                                        аналитике</span></p>
                        <p class="c74"><span class="c4 c10">Итак, мы
                                        выяснили что при
                                        использовании
                                        обычной
                                        управленческой
                                </span><span class="c4 c10">отчётности</span><span class="c0">, в которой
                                        зафиксированы
                                        расходы на
                                        рекламу и продажи
                                        за тот или иной
                                        период,
                                        более-менее
                                        корректно ROMI
                                        посчитать можно
                                        только при
                                        определенных
                                        условиях:</span></p>
                        <ul class="c9 lst-kix_list_3-0 start">
                                <li class="c37 c81 li-bullet-1"><span class="c0">Моментальный
                                                цикл сделки</span></li>
                                <li class="c37 c81 li-bullet-1"><span class="c0">Отсутствие
                                                органического
                                                (не рекламного)
                                                трафика</span></li>
                        </ul>
                        <p class="c62 c81"><span class="c4 c10">В остальных
                                        случаях </span><span class="c4 c10">подсчёт</span><span
                                        class="c4 c10">&nbsp;будет
                                        некорректен. И
                                        главное, с такими
                                        данными мы можем
                                        посчитать только
                                        общий ROMI, но мы не
                                        узнаем ROMI
                                        отдельных
                                        рекламных
                                        каналов. Причина
                                        проста</span><span class="c4">:</span><span class="c4 c10">&nbsp;мы знаем,
                                        сколько денег
                                        потратили на </span><span class="c4">каждый</span><span
                                        class="c4 c10">&nbsp;рекламный
                                        канал, но не знаем,
                                        с каких </span><span class="c4">именно</span><span class="c0">&nbsp;пришли
                                        клиенты.</span></p>
                        <p class="c62 c81"><span class="c0">В связи с этим
                                        мы приходим к
                                        необходимости
                                        отслеживать
                                        каждую заявку и
                                        заказ, сохраняя
                                        информацию о
                                        рекламном
                                        источнике. В этом
                                        и смысл сквозной
                                        аналитики. Без
                                        этого
                                        анализировать
                                        более чем 1
                                        рекламный канал с
                                        не моментальными
                                        продажами не
                                        получится никак. </span>
                        </p>
                </div>

                <!-- 21 -->
                <div data-num="21" class="numNUMBER page-mimi" id="container-pagnation21">
                        <p class="c43 c54"><span class="c0"></span></p>
                        <p class="c43"><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 456.43px; height: 583.50px;"><img
                                                alt="" src="images/image60.jpg"
                                                style="width: 456.43px; height: 583.50px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c43 c54"><span class="c6"></span></p>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c6">Логическая
                                        ошибка высокого
                                        ROMI</span></p>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Итак, примем ROMI
                                        за основной
                                        показатель
                                        эффективности
                                        рекламных
                                        кампаний. Его
                                        требуется
                                        корректно
                                        посчитать и
                                        оценить. Принять
                                        верные решения.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Основная
                                        логическая
                                        ошибка, которую
                                        сознательно, либо
                                        неосознанно,
                                        допускают многие
                                        маркетологи, &nbsp;это
                                        стремление к
                                        высокому ROMI.
                                        Кажется, что чем
                                        выше возврат
                                        инвестиций, тем
                                        лучше. Так ли это?</span></p>
                        <p class="c8"><span class="c0">&nbsp;</span></p>
                </div>

                <!-- 22 -->
                <div data-num="22" class="numNUMBER page-mimi" id="container-pagnation22">
                        <p class="c8"><span class="c0">С одной
                                        стороны — да,
                                        высокий ROMI
                                        является
                                        прекрасным
                                        достижением.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">С другой,
                                        следует
                                        учитывать 2 вещи:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_6w5zifwq7jcy-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">ROMI
                                                показатель
                                                относительный,
                                                он не говорит
                                                напрямую о
                                                прибыли или
                                                обороте, т.е. тех
                                                вещах, которые на
                                                самом деле
                                                интересуют
                                                бизнес. Высокий ROMI
                                                вполне может
                                                быть из-за
                                                эффекта «низкой
                                                базы», и динамика
                                                его снижения при
                                                увеличении
                                                инвестиций
                                                заранее
                                                непредсказуема.<br></span>
                                </li>
                                <li class="c17 li-bullet-1"><span class="c0">Сам по себе
                                                высокий ROMI — это не
                                                конечная цель, а
                                                лишь
                                                промежуточная.
                                                Поэтому кейсы
                                                маркетологов,
                                                где они гордятся
                                                высокими
                                                показателями ROMI,
                                                вызывают
                                                вопросы, если не
                                                описано, что
                                                дальше с этим
                                                делать.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Правильная
                                        работа с рекламой
                                        должна выглядеть
                                        итеративно:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_2edpqgqfem9s-0 start" start="1">
                                <li class="c17 li-bullet-1"><span class="c0">Оптимизация
                                                рекламы =&gt;
                                                повышение ROMI</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Расширение
                                                охвата =&gt;
                                                снижение ROMI</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Повторить
                                                п. 1.</span></li>
                        </ol>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Т.е. за </span><span class="c4">счёт</span><span
                                        class="c4">&nbsp;оптимизации
                                        мы повышаем
                                        эффективность,
                                        что позволяет
                                        масштабироваться,
                                        привлекая больше
                                        клиентов.
                                        Безусловно,
                                        оптимизация
                                        (уменьшение
                                        затрат,
                                        увеличение ROMI) тоже
                                        приносит
                                        увеличение
                                        прибыли компании.
                                        Однако
                                        масштабирование
                                </span><span class="c4">даёт</span><span class="c0">&nbsp;ничуть не
                                        меньший эффект.
                                        Ведь с
                                        увеличением
                                        потока трафика
                                        соответствующим
                                        образом растут и
                                        продажи. Хотя ROMI на
                                        данном этапе
                                        парадоксальным
                                        образом
                                        снижается.</span></p>
                        <p class="c8"><span class="c0">&nbsp;</span></p>
                        <p class="c8"><span class="c4">Работая в
                                        сфере
                                        интернет-маркетинга,
                                        стоит учитывать,
                                        что для performance-каналов
                                        с</span><span class="c4">тоимость
                                        привлечения
                                        клиента
                                        с&nbsp;увеличением
                                        рекламного
                                        бюджета </span><span class="c4">растёт</span><span class="c4">. </span><span
                                        class="c4">Привлечение
                                        клиентов с
                                        помощью
                                        контекстной</span><span class="c4">&nbsp;и
                                        таргетированной
                                        рекламы</span><span class="c4 c70">&nbsp;устроено
                                        по&nbsp;принципу
                                        «больше = дороже и
                                        менее
                                        качественно».
                                        &nbsp;В&nbsp;итоге, ROMI
                                        максимизируется
                                        при
                                        использовании
                                        минимального
                                        маркетингового
                                        бюджета, только
                                        одного </span><span class="c4">—</span><span class="c4 c70">&nbsp;самого
                                        выгодного </span><span class="c4">—</span><span class="c4 c70">&nbsp;канала и
                                        минимального
                                        набора ключевых
                                        запросов. Вы ведь
                                        знаете, что
                                        больших продаж &nbsp;и
                                        прибыли &nbsp;таким
                                        образом достичь
                                        не получится,
                                        остается лишь
                                        гордиться
                                        высоким ROMI на
                                        основании
                                        минимального </span><span class="c4 c70">объёма</span><span
                                        class="c0 c70">&nbsp;продаж.</span></p>
                        <p class="c5"><span class="c0 c70"></span></p>
                </div>

                <!-- 23 -->
                <div data-num="23" class="numNUMBER page-mimi" id="container-pagnation23">
                        <h3 class="c15" id="h.b4fzszem3ckm"><span>Как считать?
                                </span><a id="id.1t3h5sf"></a><span class="c11 c10">Пример:</span></h3>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <ul class="c9 lst-kix_cx7ofub9hdup-0 start">
                                <li class="c17 li-bullet-2"><span class="c4 c18">Средний
                                                чек: </span><span class="c4 c48">10 000</span><span
                                                class="c4 c48 c70">₽</span>
                                </li>
                                <li class="c17 li-bullet-1"><span class="c4 c18">Марж</span><span
                                                class="c4 c48">инальность</span><span class="c4 c18">:&nbsp;</span><span
                                                class="c4 c48">3</span><span class="c4 c18">0%
                                                (3000</span><span class="c4 c48 c70">₽</span><span
                                                class="c4 c18 c38">)</span></li>
                                <li class="c17 li-bullet-1"><span class="c4 c18">Конверсия
                                                (в&nbsp;продажу): 2,00% </span></li>
                                <li class="c17 li-bullet-2"><span class="c4 c48">100 кликов мы
                                                можем получать
                                                по 10 рублей за
                                                клик</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 624.00px; height: 221.33px;"><img
                                                alt="" src="images/image29.png"
                                                style="width: 624.00px; height: 221.33px; margin-left: -75px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Зеленым
                                        выделены лучше
                                        показатели, рыжим
                                        — худшие.</span></p>
                        <p class="c8"><span class="c4">Как видим, при
                                        небольшом
                                        количестве
                                        трафика у нас
                                        максимальный ROMI, но
                                        минимальная
                                        выручка. Далее,
                                        при увеличении
                                        бюджета ROMI падает,
                                        стоимость
                                        привлечений 1
                                        клиента растёт. До
                                        какого-то момента
                                </span><span class="c4">растёт</span><span class="c4">&nbsp;общая прибыль,
                                        потом она
                                        начинает также
                                        падать. &nbsp;И
                                        наоборот, при
                                        большом трафике
                                        максимизируется
                                        &nbsp;ROMI уменьшается и
                                </span><span class="c4">ста</span><span class="c0">новится
                                        отрицательным.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Зато валовая
                                        прибыль растёт
                                        и&nbsp;максимизируется
                                        лишь при ROI ~200%. Если же
                                        учитывать
                                        повторные заказы
                                        (LTV), картина
                                        меняется.
                                        Допустим, число
                                        повторных
                                        заказов равное 50%
                                        от числа новых
                                        заказов. Тогда
                                        прибыль
                                        максимизируется
                                        при ROI равном ~140%. Если
                                        же повторных
                                        заказов больше,
                                        выгодней
                                        удерживать еще
                                        меньший ROI.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 24 -->
                <div data-num="24" class="numNUMBER page-mimi" id="container-pagnation24">
                        <p class="c8"><span class="c0">А&nbsp;если у&nbsp;вас
                                        повторных
                                        заказов больше?
                                        Тогда вполне
                                        возможно, что ROI
                                        ниже 100% даст
                                        максимальную
                                        долгосрочную
                                        прибыль! Понятно,
                                        что в&nbsp;реальных
                                        условиях даже
                                        максимизация
                                        прибыли
                                        не&nbsp;всегда
                                        является
                                        приоритетом:
                                        часто бывают
                                        риски, проблемы
                                        роста и&nbsp;многое
                                        другое. Но&nbsp;она
                                        явно намного
                                        важнее, чем
                                        максимизация ROI,
                                        которая является
                                        ложной целью.</span>
                                <span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 336.00px;"><img
                                                alt="59e53d2bdcff638b31b24dfd.jpg" src="images/image53.jpg"
                                                style="width: 566.67px; height: 336.00px; margin-left: -60px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span>
                        </p>
                </div>

                <!-- 25 -->
                <div data-num="25" class="numNUMBER page-mimi" id="container-pagnation25">
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 600.00px; height: 360.00px;"><img
                                                alt="image" src="images/image84.png"
                                                style="width: 600.00px; height: 360.00px; margin-left: -75px; margin-top: -0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Выводы:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_iztjzbrs0qh9-0 start" start="1">
                                <li class="c17 li-bullet-1"><span class="c0">Не&nbsp;нужно
                                                максимизировать
                                                ROI. Если вы
                                                гонитесь
                                                за&nbsp;прибылью
                                                здесь и&nbsp;сейчас,
                                                показатель
                                                должен быть
                                                положительным
                                                (больше 100%). Если
                                                отношения
                                                с&nbsp;клиентами
                                                у&nbsp;вас
                                                долгосрочные,
                                                то&nbsp;ROI первой
                                                сделки вполне
                                                может быть
                                                отрицательным
                                                (меньше 100%).</span></li>
                        </ol>
                        <p class="c5"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_iztjzbrs0qh9-0" start="2">
                                <li class="c17 li-bullet-2"><span class="c0">Высокий ROI
                                                говорит о&nbsp;том,
                                                что у&nbsp;вас
                                                большой запас
                                                эффективности
                                                для расширения
                                                рекламных
                                                кампаний.
                                                Делайте это,
                                                пусть ROI снижается,
                                                а&nbsp;общая прибыль
                                                растёт.</span></li>
                        </ol>
                        <p class="c5"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_iztjzbrs0qh9-0" start="3">
                                <li class="c17 li-bullet-1"><span class="c4">Считайте
                                                прибыль
                                                в&nbsp;деньгах, а&nbsp;не
                                                процентах.
                                                Относительные
                                                величины всегда
                                                дают
                                                возможность
                                                манипулировать
                                                статистикой
                                                и&nbsp;представлять
                                                ситуацию
                                                не&nbsp;совсем
                                                достоверно. Рост
                                                числа заказов
                                                с&nbsp;1&nbsp;на&nbsp;10&nbsp;— это
                                                рост на&nbsp;1000%. А&nbsp;рост
                                                с&nbsp;1000&nbsp;до&nbsp;1100&nbsp;— всего
                                                10%.</span></li>
                        </ol><a id="id.4d34og8"></a>
                </div>

                <!-- 26 -->
                <div data-num="26" class="numNUMBER page-mimi" id="container-pagnation26">
                        <h1 class="c59 c65 c100" id="h.rwe69xlsznmu"><span class="c3">Сквозная
                                        аналитика как
                                        жизненная
                                        необходимость</span></h1>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c4">Но&nbsp;и&nbsp;это ещё
                                        не&nbsp;всё. Не&nbsp;более 30%
                                        клиентов делают
                                        заказ при
                                        первом&nbsp;же
                                        посещении сайта.
                                        Конкретное
                                        количество
                                        зависит
                                        от&nbsp;теплоты рынка
                                        и&nbsp;цикла принятия
                                        сделки, которая
                                        обычно невелика.
                                        Прежде чем что-то
                                        купить (совершить
                                        конверсию),
                                        человек, </span><span class="c4">привлечённый</span><span
                                        class="c4">&nbsp;разными
                                        рекламными
                                        источниками,
                                        заходит на&nbsp;сайт
                                        несколько раз.
                                        Мультиканальные
                                        конверсии
                                        появились в&nbsp;Google Analytics
                                        несколько лет
                                        назад, но&nbsp;многие
                                        до&nbsp;сих пор
                                        используют
                                        принцип </span><span class="c4">LastClickWins</span><span class="c0">, т.е.
                                        считают
                                        конверсии
                                        по&nbsp;последнему
                                        заходу.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Правильнее
                                        будет учитывать
                                        все касания
                                        (заходы)
                                        посетителя
                                        и&nbsp;использовать
                                        более
                                        продвинутые
                                        модели
                                        атрибуции.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c43"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 624.00px; height: 280.00px;"><img
                                                alt="" src="images/image10.png"
                                                style="width: 624.00px; height: 280.00px; margin-left: -75px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Проблема&nbsp;1:</span></p>
                        <p class="c8"><span class="c0">Посетитель
                                        заходит на&nbsp;сайт
                                        из&nbsp;разных
                                        источников.
                                        Конверсия
                                        зачастую
                                        мультиканальна.
                                        Нужно применять
                                        некие модели
                                        атрибуции.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 27 -->
                <div data-num="27" class="numNUMBER page-mimi" id="container-pagnation27">
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Проблема&nbsp;2:</span></p>
                        <p class="c8"><span class="c0">Покупатель
                                        совершает
                                        не&nbsp;1&nbsp;покупку.
                                        Повторные
                                        покупки могут
                                        быть намного
                                        больше, чем размер
                                        первого заказа.
                                        Значит, нужно
                                        считать LTV, а для
                                        этого не обойтись
                                        без внедрения CRM.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Проблема&nbsp;3:</span></p>
                        <p class="c8"><span class="c0">Каналы
                                        общения. Нужно
                                        отслеживать все
                                        каналы. &nbsp;В
                                        противном случае
                                        мы получим
                                        аналитику, не
                                        точно отражающую
                                        реальность, с
                                        необоснованными
                                        выводами,
                                        писанными вилами
                                        по воде. </span></p>
                        <p class="c8"><span class="c0">Нельзя при
                                        этом считать
                                        заявки только
                                        через сайт или
                                        даже заявки +
                                        звонки. Вот
                                        поэтому
                                        необходимо
                                        выстраивать
                                        сквозную
                                        аналитику.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Сквозная
                                        аналитика в
                                        маркетинге —
                                        метод анализа
                                        эффективности
                                        маркетинговых
                                        инвестиций (ROMI) на
                                        основе данных,
                                        отслеживающих
                                        полный путь
                                        клиента, начиная
                                        от просмотра
                                        рекламного
                                        объявления,
                                        посещения сайта и
                                        заканчивая
                                        продажей и
                                        повторными
                                        заказами (LTV). При
                                        наличии
                                        нескольких
                                        рекламных
                                        касаний,
                                        предшествующих
                                        продаже,
                                        применяются
                                        различные модели
                                        атрибуции.
                                        Базируется на
                                        веб-аналитике и
                                        когортном
                                        анализе данных из
                                        CRM/ERP[1][2].</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Для реальной
                                        оценки
                                        эффективности
                                        маркетинга стоит
                                        поставить
                                        конкретную
                                        задачу:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Определить
                                        KPI для оценки;</span></p>
                        <p class="c8"><span class="c0">•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Определиться
                                        с тем, какими
                                        должны быть
                                        дашборды, отчеты;</span>
                        </p>
                        <p class="c8"><span class="c0">•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Выяснить,
                                        кто отвечает за
                                        проведение
                                        оценки
                                        эффективности РК
                                        в организации;</span></p>
                        <p class="c8"><span
                                        class="c4">•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Проанализировать,
                                </span><span class="c4">каковы пути
                                        пользователей;</span></p>
                        <p class="c8"><span class="c0">•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Учесть
                                        данные как онлайн,
                                        так и офлайн,
                                        убедиться в их
                                        качестве;</span></p>
                        <p class="c8"><span class="c0">•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Провести
                                        анализ ряда
                                        моделей
                                        атрибуции, что
                                        даст возможность
                                        подобрать
                                        решение, наиболее
                                        подходящее для
                                        конкретного
                                        бизнеса.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 28 -->
                <div data-num="28" class="numNUMBER page-mimi" id="container-pagnation28">
                        <p class="c8"><span class="c0">Обычно для
                                        сквозной
                                        аналитики
                                        требуется
                                        объединить
                                        информацию
                                        из&nbsp;рекламных
                                        каналов (например,
                                        Google Ads, Яндекс.Директ,
                                        Facebook), каналов
                                        коммуникации
                                        (телефонный
                                        звонок,
                                        онлайн-заказ
                                        через корзину
                                        на&nbsp;сайте,
                                        электронная
                                        почта и&nbsp;др.)
                                        и&nbsp;CRM-системы, где
                                        находится
                                        информация
                                        о&nbsp;продажах (Wikipedia).</span></p>

                        <p class="c8"><span class="c0">В&nbsp;целом,
                                        процесс
                                        аналитики
                                        рекламных
                                        кампаний
                                        и&nbsp;бизнеса&nbsp;устроен&nbsp;так:</span>
                        </p>
                        <p class="c74"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 463.50px; height: 107.86px;"><img
                                                alt="" src="images/image41.png"
                                                style="width: 463.50px; height: 107.86px; margin-left: -20px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span><span class="c0"><br> &nbsp; &nbsp; &nbsp; </span></p>

                        <p class="c74"><span class="c4 c10">Лучше,
                                        если&nbsp;так:</span></p>

                        <p class="c43"><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 417.50px; height: 237.09px;"><img
                                                alt="" src="images/image36.png"
                                                style="width: 417.50px; height: 237.09px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                </div>

                <!-- 29 -->
                <div data-num="29" class="numNUMBER page-mimi" id="container-pagnation29">

                        <p class="c57"><span class="c4">И совсем
                                        хорошо</span><span class="c0">, если
                                        вот&nbsp;так:</span></p>
                        <p class="c57"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 553.50px; height: 321.48px;"><img
                                                alt="" src="images/image45.png"
                                                style="width: 553.50px; height: 321.48px; margin-left: -60px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span><span class="c0"><br></span></p>
                        <p class="c57"><span class="c4 c10">Ни показы, </span><span class="c4 c10">ни</span><span
                                        class="c0">&nbsp;клики,
                                        ни даже звонки
                                        не&nbsp;скажут ничего.
                                        Мы точно знаем,
                                        сколько
                                        затратили
                                        на&nbsp;рекламу, и&nbsp;нам
                                        нужно также точно
                                        знать, сколько мы
                                        с&nbsp;этого
                                        заработали.
                                        К&nbsp;счастью, сейчас
                                        это стало
                                        реальностью.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c14"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c75 c86 c54"><span class="c0"></span></p><a id="kix.jzmtef32ykek"></a>
                </div>

                <!-- 30 -->
                <div data-num="30" class="numNUMBER page-mimi" id="container-pagnation30">

                        <h2 class="c74 c59 c65" id="h.a6qdq852nadi"><span class="c22 c10">Кому
                                        нужна сквозная
                                        аналитика</span></h2>
                        <p class="c8"><span class="c4">Всем ли нужна
                                        сквозная
                                        аналитика, все ли
                                        могут </span><span class="c4">её</span><span class="c0">&nbsp;внедрить?
                                        Конечно же нет.
                                        Рассмотрим
                                        необходимые и
                                        желательные
                                        условия для того
                                        чтобы внедрение
                                        было полезным.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_ycftmiswvcdv-0 start" start="1">
                                <li class="c35 li-bullet-0"><span class="c4">Компания
                                                должна
                                                продавать
                                                товары или
                                                услуги в онлайне,
                                                таких сейчас.
                                                Например, к
                                                ритейлу она мало
                                                применима, а к &nbsp;ecommerce
                                        </span><span class="c4 c45">—</span><span class="c0">&nbsp;более
                                                чем.</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">Чтобы
                                                внедрение было
                                                целесообразно
                                                экономически,
                                                рекламный
                                                бюджет
                                                рекомендуется
                                                не менее 1-2 тысяч $ в
                                                месяц.</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">Чем больше
                                                рекламных
                                                каналов, тем выше
                                                эффективность
                                                аналитики.
                                                Сравнение
                                                внутри 1 канала
                                                тоже полезно, но
                                                на 3-5 каналах
                                                эффективность
                                                наверняка будет
                                                выше. Вы сможете
                                                сравнивать и
                                                каналы друг с
                                                другом и
                                                кампании,
                                                запросы,
                                                настройки
                                                внутри каналов.</span>
                                </li>
                                <li class="c35 li-bullet-0"><span class="c0">У вас есть
                                                повторные
                                                продажи и есть %
                                                отвала (т.е.
                                                конверсия лидов
                                                в продажу далека
                                                от 100%). Иначе можно
                                                обойтись просто
                                                веб-аналитикой.</span>
                                </li>
                        </ol>
                        <p class="c46"><span class="c0"></span></p>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <h3 class="c8 c59 c65" id="h.dxmtlgwxn31"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 635.50px; height: 250.67px;"><img
                                                alt="" src="images/image30.jpg"
                                                style="width: 635.50px; height: 250.67px; margin-left: -75px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h3>
                        <p class="c75 c86 c54"><span class="c0"></span></p>
                        <p class="c75 c54 c86"><span class="c0"></span></p>
                        <p class="c5"><span class="c6"></span></p><a id="kix.lk4kwnxssg8v"></a>
                </div>

                <!-- 31 -->
                <div data-num="31" class="numNUMBER page-mimi" id="container-pagnation31">
                        <h2 class="c74 c65" id="h.zdrqwj9ev679"><span class="c22 c10">Кому не
                                        обязательна
                                        сквозная
                                        аналитика</span></h2>
                        <p class="c8"><span class="c4">• Компании с
                                        очень длительным
                                        циклом сделки. Они
                                        будут ждать, пока
                                        система
                                        аналитики начнет
                                        приносить
                                        реальную пользу,
                                        потратив за&nbsp;это
                                        время
                                        существенную
                                        сумму на&nbsp;сам
                                        сервис.</span></p>
                        <p class="c8"><span class="c0">• Бизнесу
                                        с&nbsp;высокой
                                        маржинальностью
                                        (высокая маржа
                                        нивелирует
                                        управленческие
                                        и&nbsp;маркетинговые
                                        ошибки
                                        и&nbsp;неэффективность,
                                        обеспечивая
                                        больший
                                        потенциал для
                                        масштабирования
                                        и роста).</span></p>
                        <p class="c8"><span class="c0">• Компаниям
                                        с&nbsp;LTV меньше
                                        нескольких
                                        средних чеков:
                                        отчет
                                        об&nbsp;источниках
                                        первой покупки
                                        дает
                                        представление
                                        об&nbsp;эффективности
                                        канала в&nbsp;целом.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p><a id="kix.cptv5tmf6m2"></a><a
                                id="kix.rv4gb3gitfk7"></a>
                </div>

                <!-- 32 -->
                <div data-num="32" class="numNUMBER page-mimi" id="container-pagnation32">
                        <h2 class="c74 c65" id="h.wpnhxmv1b95f"><span class="c23">Проблемы
                                        внедрения</span></h2>
                        <p class="c43"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 505.53px; height: 350.70px;"><img
                                                alt="" src="images/image76.png"
                                                style="width: 505.53px; height: 350.70px; margin-left: -30px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Внедрение
                                        сквозной
                                        аналитики
                                        на&nbsp;практике
                                        является
                                        непростой
                                        задачей,
                                        и&nbsp;в&nbsp;процессе
                                        появляется
                                        немало ошибок или
                                        сознательных
                                        компромиссов,
                                        которые
                                        существенно
                                        искажают
                                        результат.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Первой
                                        задачей является
                                        убеждение
                                        руководства в
                                        необходимости
                                        сквозной
                                        аналитики как
                                        таковой.
                                        Требуется
                                        показать что
                                        обычный
                                        управленческий
                                </span><span class="c4">отчёт</span><span class="c0">, в
                                        котором есть
                                        расходы на
                                        рекламу по
                                        каналам и доходы с
                                        продаж это далеко
                                        не сквозная
                                        аналитика, по
                                        многим причинам:</span>
                        </p>
                        <ul class="c9 lst-kix_4yc7nahaf6tj-0 start">
                                <li class="c35 li-bullet-0"><span class="c0">Разделение на
                                                каналы возможно
                                                только в
                                                расходах, но не в
                                                доходах. Это
                                                хорошо, когда
                                                рекламный канал
                                                один. Но плохо
                                                когда их
                                                несколько.</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">Без связки
                                                рекламного
                                                источника с
                                                продажей, при
                                                долгом цикле
                                                сделки даже
                                                интуитивного
                                                понимания, какая
                                                реклама
                                                сработала и
                                                сработала ли
                                                вообще, например,
                                                реклама
                                                запущена зимой, а
                                                заявки и продажи
                                                начались летом.
                                                Без сквозной
                                                аналитики мы не
                                                узнаем, были ли
                                                эти клиенты
                                                прогреты
                                                рекламой с
                                                самого начала
                                                или же они
                                                обратились по
                                                другим
                                                источникам.</span></li>
                        </ul>
                        <p class="c46"><span class="c0"></span></p>
                </div>

                <!-- 33 -->
                <div data-num="33" class="numNUMBER page-mimi" id="container-pagnation33">
                        <p class="c75 c86"><span class="c0">Внедрение
                                        сквозной
                                        аналитики
                                        позволяет
                                        понимать, какие
                                        рекламные каналы
                                        участвовали в
                                        привлечении
                                        клиента. Какие
                                        рекламные
                                        кампании. Какие
                                        ключевые слова.
                                        Такая
                                        детализация
                                        позволяет
                                        эффективно
                                        управлять
                                        рекламными
                                        кампаниями и
                                        экономить
                                        существенный %
                                        рекламного
                                        бюджета. Система Roistat
                                        заявляет об
                                        экономии до 56%, но
                                        даже более
                                        пессимистичные 30%
                                        при бюджете в 200. тыс
                                        в месяц
                                        составляют сумму
                                        ощутимые 60 тыс.
                                        рублей.</span></p>
                        <h3 class="c75 c63" id="h.lu6htw1gcifz"><span class="c11 c10"></span></h3><a
                                id="kix.v76thrz6aznr"></a>
                        <h3 class="c15" id="h.en568pbzwwd6"><span class="c11 c10">Проблема
                                        1: отдел продаж</span></h3>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c4">Нужно
                                        понимать, что
                                        маркетинговая
                                        составляющая
                                        построения
                                        системы сквозной
                                        аналитики далеко
                                        не&nbsp;доминирующая.
                                        Даже если
                                        говорить о&nbsp;числе
                                        сотрудников, то
                                        отдел
                                        маркетинга</span><span class="c4 c70">&nbsp;(</span><span
                                        class="c4">в&nbsp;средней
                                        компании — хоть b2b,
                                        хоть b2с) </span><span class="c4 c70">обычно </span><span class="c4">существенно
                                        уступает отделу
                                        продаж или
                                        IT-отделу.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Маркетинг</span><span class="c4">&nbsp;— это часть
                                        бизнеса, наряду с
                                        производством,
                                        логистикой,
                                        продажами, IT, HR и
                                        другими
                                        отделами.</span><span class="c0">&nbsp;Бизнесу нужны
                                        продажи, а
                                        маркетинг по
                                        большей части
                                        обеспечивает
                                        именно
                                        привлечение
                                        клиентов, тогда
                                        как с удержанием
                                        дела обстоят
                                        сложнее. Дело в
                                        том, что
                                        маркетологи
                                        зачастую не имеют
                                        возможности
                                        контролировать
                                        все этапы и опыт
                                        взаимодействия
                                        клиента с
                                        компанией в целом
                                        (будь то отдел
                                        продаж,
                                        бухгалтерия,
                                        секретарь или
                                        впечатление об
                                        офисе компании),
                                        поэтому с
                                        удержанием
                                        возникают
                                        проблемы, которые
                                        находятся вне
                                        сферы
                                        ответственности
                                        маркетологов.
                                        Именно отдел
                                        продаж,
                                        а&nbsp;не&nbsp;маркетинга,
                                        является
                                        основной точкой
                                        взаимодействия
                                        с&nbsp;клиентом,
                                        точкой получения
                                        данных от&nbsp;него
                                        и&nbsp;точкой
                                        занесения этой
                                        &nbsp;информации
                                        в&nbsp;некую систему,
                                        из&nbsp;которой она
                                        потом попадает
                                        в&nbsp;аналитику.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Т.е. без
                                        грамотного
                                        построения
                                        отдела продаж
                                        не&nbsp;будет
                                        сквозной
                                        аналитики. При
                                        этом нужно, чтобы
                                        отдел продаж
                                        использовал
                                        в&nbsp;работе
                                        CRM-систему. Всего
                                        лишь!</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 34 -->
                <div data-num="34" class="numNUMBER page-mimi" id="container-pagnation34">
                        <p class="c8"><span class="c0">Проблема
                                        в&nbsp;том, что CRM сама
                                        по&nbsp;себе отделу
                                        продаж не&nbsp;нужна
                                        от&nbsp;слова
                                        «совсем». Чтобы
                                        она стала ему
                                        нужна
                                        и&nbsp;не&nbsp;воспринималась
                                        в&nbsp;штыки, нужно
                                        соблюдение
                                        множества
                                        условий:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h4 class="c105 c59 c106" id="h.y3elynl1ekzy"><span class="c6">&nbsp; &nbsp;Для
                                        менеджера:</span></h4>
                        <p class="c75 c54 c101"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_qxj53ce3fija-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">Система
                                                должна сразу
                                                облегчать
                                                какие-то
                                                привычные
                                                действия,
                                                которые раньше
                                                делались менее
                                                удобно;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Она
                                                не&nbsp;должна
                                                дублировать
                                                другие системы
                                                и&nbsp;действия &nbsp;—
                                                только
                                                замещать&nbsp;их;</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Обращения
                                                всех клиентов
                                                должны попадать
                                                в&nbsp;систему
                                                автоматически;</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Общение
                                                с&nbsp;клиентами
                                                (отправка писем,
                                                звонки и&nbsp;т.д.)
                                                проходит внутри
                                                системы.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <h4 class="c82 c59" id="h.6h1mdf9wagez"><span class="c6">Для
                                        руководителя
                                        (РОП`а):</span></h4>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_s4ifojrxxpe4-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">Прозрачная
                                                информация
                                                по&nbsp;каждому
                                                менеджеру и&nbsp;его
                                                действиям;</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Настройки
                                                распределения
                                                лидов
                                                в&nbsp;зависимости
                                                от&nbsp;эффективности
                                                работы
                                                сотрудников;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Гибкая
                                                система
                                                выстраивания KPI
                                                менеджеров
                                                и&nbsp;отчётности.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 35 -->
                <div data-num="35" class="numNUMBER page-mimi" id="container-pagnation35">
                        <p class="c8"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 680.05px; height: 369.33px;"><img
                                                alt="" src="images/image70.png"
                                                style="width: 680.05px; height: 369.33px; margin-left: -100px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span><span class="c0">Отдел
                                        продаж примет CRM
                                        не&nbsp;в&nbsp;штыки
                                        только совместно
                                        с&nbsp;системой
                                        мотивации,
                                        в&nbsp;которой
                                        «пряников» будет
                                        больше, чем
                                        «кнутов».
                                        И&nbsp;только при
                                        внутреннем
                                        принятии отделом
                                        продаж системы
                                        можно двигаться
                                        дальше —
                                        на&nbsp;технические
                                        минные поля
                                        внедрения. Если
                                        вы&nbsp;—
                                        маркетолог,&nbsp;дружите
                                        с&nbsp;РОП`м. Если ему
                                        не очевидна
                                        польза от&nbsp;ваших
                                        маркетинговых
                                        заморочек,
                                        сквозную
                                        аналитику вы
                                        не&nbsp;построите.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Вывод:
                                        внедрить
                                        сквозную
                                        аналитику
                                        в&nbsp;компанию, где
                                        уже есть CRM, и
                                        компанию, где CRM нет,
                                        — это, как
                                        говорится,
                                        2&nbsp;большие разницы.
                                        Внедрение CRM — это
                                        не&nbsp;столько
                                        технический,
                                        сколько
                                        управленческий
                                        процесс,
                                        требующий
                                        комплексного
                                        подхода
                                        к&nbsp;построению
                                        отдела продаж. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Необходимо
                                        не&nbsp;просто
                                        поставить
                                        программу,
                                        но&nbsp;и&nbsp;обучить
                                        менеджеров,
                                        описать и
                                        внедрить
                                        бизнес-процессы,
                                        написать скрипты
                                        разговоров,
                                        продумать
                                        систему KPI
                                        сотрудников,
                                        написать
                                        регламенты
                                        работы с CRM и
                                        обеспечить
                                        контроль работы
                                        как сотрудников,
                                        так и технических
                                        средств.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Про самые
                                        популярные
                                        CRM-системы вы
                                        узнаете в
                                        следующих
                                        разделах.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p><a id="kix.11zo1wen39ea"></a><a
                                id="kix.8y6rbhbjjaf7"></a>
                </div>

                <!-- 36 -->
                <div data-num="36" class="numNUMBER page-mimi" id="container-pagnation36">
                        <h3 class="c15" id="h.1j0sembdxyqq"><span class="c11 c10">Проблема
                                        2: техническая</span></h3>
                        <p class="c75 c54"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c4">Популярные </span><span class="c4">облачные
                                        сервисы</span><span class="c0">&nbsp;(в
                                        том числе системы
                                        сквозной
                                        аналитики) обычно
                                        интегрируются
                                        друг с другом в
                                        пару кликов.
                                        Однако в
                                        реальности всё не
                                        так просто, как
                                        кажется.
                                        Рассмотрим
                                        некоторые
                                        проблемы, которые
                                        могут
                                        возникнуть:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_dmlt6rufnbgx-0 start" start="1">
                                <li class="c35 li-bullet-0"><span class="c6">Для
                                                облачных систем
                                                аналитики. </span></li>
                        </ol>
                        <p class="c75 c54"><span class="c6"></span></p>
                        <p class="c75 c98"><span class="c4">1.1
                                        Ограниченная
                                        функциональность.
                                        Вы не можете
                                        настроить всё так,
                                        как нужно именно
                                        вам. С некоторыми
                                        системами нет
                                        стандартной
                                        интеграции, и
                                        приходится
                                        интегрироваться
                                        при помощи API и </span><span class="c4">вебхуков</span><span
                                        class="c0">.</span></p>
                        <p class="c46"><span class="c0"></span></p>
                        <p class="c75 c98"><span class="c4">1.2 Облачная
                                        система
                                        аналитики обычно
                                        является для вас
                                        закрытым “</span><span class="c4">чёрным</span><span class="c0">&nbsp;ящиком”.
                                        Вы не
                                        знаете, что и как
                                        она считает, и
                                        приходится
                                        просто верить.
                                        Точность
                                        подсчёта может
                                        вызывать много
                                        вопросов: данные в
                                        системе
                                        аналитики часто
                                        не совпадают с
                                        данными CRM, а сделки
                                        не
                                        идентифицируются
                                        с источником. </span></p>
                        <p class="c46"><span class="c0"></span></p>
                        <p class="c75 c98"><span class="c0">1.3 Работая с
                                        облачной
                                        системой
                                        аналитики, вы
                                        доверяете свои
                                        данные третьей
                                        стороне. В крупных
                                        компаниях отдел
                                        маркетинга может
                                        просто не
                                        получить
                                        разрешения от
                                        службы
                                        безопасности на
                                        подобные
                                        интеграции с CRM.</span></p>
                        <p class="c46"><span class="c0"></span></p>
                        <p class="c75 c98"><span class="c0">1.4 Еще одно
                                        следствие
                                        прошлого пункта:
                                        не всегда можно
                                        выгрузить данные
                                        в удобном формате.
                                        Вряд ли вы сможете
                                        сменить систему
                                        аналитики с
                                        переносом всех
                                        ваших данных.</span></p>
                        <p class="c46"><span class="c0"></span></p>
                </div>

                <!-- 37 -->
                <div data-num="37" class="numNUMBER page-mimi" id="container-pagnation37">
                        <ol class="c9 lst-kix_dmlt6rufnbgx-0" start="2">
                                <li class="c35 li-bullet-0"><span class="c6">Для
                                                кастомных
                                                систем
                                                аналитики. </span></li>
                        </ol>
                        <p class="c75 c54"><span class="c6"></span></p>
                        <p class="c75 c98"><span class="c4">Здесь дела
                                        обстоят </span><span class="c4">ещё</span><span class="c4">&nbsp;сложнее.
                                        Спроектировать и
                                        построить
                                        собственную
                                        систему
                                        аналитики
                                        непросто, так как
                                        может не хватить
                                        сил 1-2 штатных
                                        &nbsp;разработчиков, а
                                        надеяться
                                        получить такой
                                        результата от
                                        фрилансеров ещё
                                        более
                                        опрометчиво. В
                                        любом случае,
                                        прежде чем
                                        приступать к
                                        разработке, стоит
                                </span><span class="c4">чётко</span><span class="c0">&nbsp;определить:</span></p>
                        <p class="c46"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_w3ikqt7xdmik-0 start">
                                <li class="c34 li-bullet-0"><span class="c0">Источники
                                                данных — чем их
                                                меньше, тем
                                                проще;</span></li>
                                <li class="c34 li-bullet-0"><span class="c0">Какие
                                                данные
                                                потребуются и
                                                как их
                                                объединять;</span></li>
                                <li class="c34 li-bullet-0"><span class="c4">Выбрать
                                                систему
                                                визуализации и
                                                продумать
                                                форматы </span><span class="c4">отчётов</span><span class="c0">.</span>
                                </li>
                        </ul>
                        <p class="c54 c66"><span class="c0"></span></p>
                        <p class="c75 c98"><span class="c0">Наибольшие
                                        проблемы обычно
                                        возникают с
                                        выгрузкой и
                                        объединением
                                        данных. Не все
                                        системы
                                        позволяют
                                        выгружать не
                                        агрегированные
                                        данные. У многих
                                        систем есть
                                        ограничения по
                                        числу запросов по
                                        API. Если не говорить
                                        о крупных
                                        компаниях (в штате
                                        которых есть и
                                        разработчики, и
                                        аналитики, у
                                        которых уже
                                        построен
                                        корпоративный &nbsp;DWH),
                                        для выгрузки
                                        данных лучше
                                        воспользоваться
                                        готовыми
                                        коннекторами, а
                                        для визуализации
                                        — популярными на
                                        рынке решениями,
                                        такими как Microsoft Power BI или
                                        Google Data Studio.</span></p>
                        <p class="c46"><span class="c0"></span></p>
                        <p class="c75 c98"><span class="c4">Какие п</span><span class="c0">роблемы с
                                        подключением
                                        всех каналов
                                        коммуникации
                                        могут
                                        возникнуть:</span></p>
                        <p class="c75 c54"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-0 start" start="1">
                                <li class="c61 li-bullet-3"><span class="c0">При
                                                отслеживании
                                                звонков
                                                используется
                                                коллтрекинг
                                                (подмена номеров).
                                                С ним есть
                                                сложности:</span></li>
                        </ol>
                        <p class="c41"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-1 start" start="1">
                                <li class="c75 c79 li-bullet-3"><span class="c0">Телефонные
                                                номера не
                                                бесплатны, а
                                                федеральный “8-800”
                                                стоит дорого.
                                                Если вы
                                                используете
                                                такой номер на
                                                сайте, возникает
                                                дилемма: или
                                                платить
                                                неоправданно
                                                много за пул
                                                подменных
                                                номеров, или от
                                                чего-то
                                                отказываться (от
                                                самих номеров
                                                либо от идеи их
                                                отслеживать). </span></li>
                        </ol>
                        <p class="c75 c54 c99"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-1" start="2">
                                <li class="c75 c79 li-bullet-3"><span class="c4">Подменные
                                                номера придётся
                                                указывать и в </span><span class="c4">офлайн</span><span
                                                class="c0">-рекламе, и в
                                                POS-материалах,
                                                выделяя по
                                                номеру на каждый
                                                канал, который вы
                                                хотите
                                                отслеживать.</span></li>
                        </ol>
                </div>

                <!-- 38 -->
                <div data-num="38" class="numNUMBER page-mimi" id="container-pagnation38">
                        <p class="c75 c54 c99"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-1" start="3">
                                <li class="c75 c79 li-bullet-3"><span class="c0">У
                                                компании больше
                                                не будет единого
                                                красивого
                                                запоминаемого
                                                номера. Для
                                                некоторых
                                                сервисов это
                                                критично.</span></li>
                        </ol>
                        <p class="c75 c54 c99"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-1" start="4">
                                <li class="c75 c79 li-bullet-3"><span class="c0">При
                                                длительном
                                                использовании
                                                коллтрекинга
                                                создаётся
                                                токсичный
                                                трафик, когда
                                                люди записали
                                                подменный номер
                                                и звонят по нему
                                                позднее, не
                                                заходя на сайт.
                                                Система может
                                                ошибочно
                                                связать данный
                                                звонок с
                                                рекламным
                                                каналом, по
                                                которому в этот
                                                момент зашёл
                                                другой
                                                посетитель (и не
                                                позвонил).</span></li>
                        </ol>
                        <p class="c75 c54 c99"><span class="c0"></span></p>
                        <p class="c75 c110"><span
                                        class="c4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span
                                        class="c4">Кстати, т</span><span class="c4">елефонные
                                        звонки можно
                                        отслеживать и без
                                        подмены номеров —
                                        например,
                                        скрытием части
                                        номера на сайте и
                                        показом только по
                                        клику. Такой
                                        подход имеет свои
                                        плюсы и минусы.</span></p>
                        <p class="c75 c54"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-0" start="2">
                                <li class="c40 li-bullet-4"><span class="c0">С
                                                онлайн-консультантами
                                                часто возникают
                                                проблемы с
                                                отслеживанием и
                                                назначением
                                                ответственного
                                                в CRM. </span></li>
                        </ol>
                        <p class="c41"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-0" start="3">
                                <li class="c40 li-bullet-4"><span class="c0">Email. Можно
                                                отслеживать
                                                подменой, но это
                                                не всегда удобно
                                                и не все системы
                                                аналитики это
                                                умеют.</span></li>
                        </ol>
                        <p class="c41"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-0" start="4">
                                <li class="c40 li-bullet-5"><span class="c0">Мессенджеры. По
                                                большей части не
                                                отслеживаются,
                                                тем более если
                                                просто указать
                                                на сайте номер WhatsApp
                                                или ID Telegram, а не
                                                ставить
                                                интеграцию.</span></li>
                        </ol>
                        <p class="c41"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-0" start="5">
                                <li class="c40 li-bullet-6"><span class="c4">Маркетплейсы.
                                                Тут всё зависит
                                                от самого
                                                маркетплейса, но
                                                не стоит
                                                рассчитывать на
                                                глубокую
                                                аналитику и на
                                                возможность </span><span class="c4">её</span><span
                                                class="c0">&nbsp;доработки.</span></li>
                        </ol>
                        <p class="c41"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_mm7tp8j5i3n5-0" start="6">
                                <li class="c40 li-bullet-6"><span class="c4">Офлайн.
                                                Связать офлайн
                                                продажи с
                                                онлайном
                                                непросто, и мало
                                                кто это делает. </span><span class="c4">Кейсы с
                                                RFID-метками</span><span class="c4">&nbsp;(автоматическая
                                                идентификация
                                                объектов) не
                                                выглядят
                                                жизнеспособными.
                                                Для небольших
                                                магазинов есть
                                                возможность
                                                связать онлайн с
                                        </span><span class="c4">офлайном</span><span class="c0">&nbsp;через
                                                резервирование
                                                товара. В ритейле
                                                такой
                                                возможности нет,
                                                но там и сквозная
                                                аналитика не
                                                всегда
                                                применима. </span></li>
                        </ol>
                        <p class="c75 c54"><span class="c0"></span></p>
                        <p class="c54 c75"><span class="c0"></span></p><a id="kix.etcsdtmr2ggf"></a>
                </div>

                <!-- 39 -->
                <div data-num="39" class="numNUMBER page-mimi" id="container-pagnation39">
                        <h3 class="c32" id="h.47d6qpiyca83"><span class="c23">ROPO-</span><span>эффект</span></h3>
                        <p class="c54 c109"><span class="c0"></span></p>
                        <p class="c36"><span class="c0">Каким бы
                                        успешным ни был
                                        ваш
                                        омниканальный
                                        бизнес, вы можете
                                        даже не
                                        подозревать, что
                                        недополучаете
                                        около трети
                                        прибыли. И дело
                                        может быть даже не
                                        в том, что ваш
                                        онлайн-маркетинг
                                        работает
                                        недостаточно
                                        эффективно. Речь
                                        сейчас пойдёт об
                                        особенностях
                                        онлайн и
                                        офлайн-поведения
                                        клиентов, а также
                                        о том, как они
                                        между собой
                                        связаны.</span></p>
                        <p class="c36"><span class="c0">Пожалуй,
                                        многим может быть
                                        знакома привычка
                                        сначала искать
                                        информацию о
                                        товаре в сети, а
                                        потом идти в
                                        офлайн-магазин за
                                        покупкой. Такая
                                        наклонность у
                                        покупателей
                                        встречается всё
                                        чаще — настолько,
                                        что такому
                                        поведенческому
                                        признаку дали
                                        название с
                                        аббревиатурой ROPO —
                                        Research Online Purchase Offline. Как
                                        выяснилось, для
                                        такого поведения
                                        есть причины:</span></p>
                        <ul class="c9 lst-kix_40upqo51tifb-0 start">
                                <li class="c13 li-bullet-7"><span class="c0">Выбрать и
                                                сравнить товар в
                                                интернет-магазине
                                                проще и быстрее;</span>
                                </li>
                                <li class="c13 li-bullet-7"><span class="c0">Покупку в
                                                офлайн-магазине
                                                можно осмотреть
                                                и проверить на
                                                месте, а забрать
                                                сразу же после
                                                оплаты;</span></li>
                                <li class="c13 li-bullet-7"><span class="c0">Люди
                                                склонны
                                                неохотно
                                                совершать в
                                                интернете
                                                слишком дорогие
                                                или, наоборот,
                                                дешёвые
                                                покупки;</span></li>
                                <li class="c13 li-bullet-7"><span class="c0">Онлайн
                                                платежи могут
                                                вызывать
                                                недоверие.</span></li>
                        </ul>
                        <p class="c36"><span class="c0">Конечно,
                                        процент
                                        ROPO-покупателей в
                                        разных типах
                                        бизнеса может
                                        заметно
                                        отличаться. Тем не
                                        менее, его
                                        величина слишком
                                        значительна,
                                        поэтому
                                        пренебрегать им
                                        не стоит. Какой бы
                                        ни была доля
                                        ROPO-покупок в ваших
                                        магазинах, вы
                                        можете извлечь из
                                        этого выгоду.</span></p>
                        <p class="c36"><span class="c6">Оптимизируйте
                                        рекламные
                                        каналы</span></p>
                        <p class="c36"><span class="c0">Так как
                                        многие
                                        покупатели
                                        заходят на ваш
                                        сайт «просто
                                        посмотреть», а
                                        покупку делают за
                                        его пределами, то
                                        оценить
                                        стоимость
                                        конверсии и
                                        окупаемости
                                        рекламы
                                        становится делом
                                        более сложным.
                                        Лучшее, что можно
                                        с этим сделать, —
                                        это сравнить
                                        продажи ваших
                                        розничных
                                        магазинов с
                                        онлайн-активностью.
                                        Так вы выясните,
                                        пользуется ли
                                        товар реальным
                                        спросом, и стоит
                                        ли
                                        пересматривать
                                        рекламный
                                        бюджет.</span></p>
                </div>

                <!-- 40 -->
                <div data-num="40" class="numNUMBER page-mimi" id="container-pagnation40">
                        <p class="c36"><span class="c6">Увеличивайте
                                        прибыль</span></p>
                        <p class="c36"><span class="c4">Согласно
                                        масштабным
                                        исследованиям,
                                        ROPO-покупатели
                                        оставляют в
                                        офлайн-магазинах
                                        на 20-40% больше денег,
                                        чем те, кто
                                        предпочитает
                                        изучать товар «на
                                        месте» перед
                                        покупкой. Если вы
                                </span><span class="c4">сосредоточите</span><span class="c0">&nbsp;ваши усилия на
                                        продаже именно
                                        этих товаров, то
                                        сможете извлечь
                                        дополнительную
                                        прибыль.</span></p>
                        <p class="c36"><span class="c6">Обновляйте
                                        ваш сайт и
                                        улучшайте
                                        продажи онлайн</span></p>
                        <p class="c36"><span class="c0">Как только вы
                                        выясните, что за
                                        некоторыми
                                        товарами ваши
                                        покупатели идут в
                                        магазин вместо
                                        совершения
                                        покупки в
                                        интернете, то
                                        самое время
                                        разобраться в
                                        причинах.
                                        Наиболее часто
                                        встречающиеся:</span></p>
                        <ul class="c9 lst-kix_a0hwjjiztzfw-0 start">
                                <li class="c13 li-bullet-2"><span class="c0">Значительное
                                                различие цен и
                                                акций в ваших
                                                магазинах;</span></li>
                                <li class="c13 li-bullet-7"><span class="c0">Сервис
                                                доставки
                                                недостаточно
                                                хорошо отлажен;</span>
                                </li>
                                <li class="c13 li-bullet-1"><span class="c0">Непроработанный
                                                интерфейс или
                                                неудобная
                                                процедура
                                                оплаты.</span></li>
                        </ul>
                        <p class="c36"><span class="c4">ROPO-анализ
                                        поможет понять, в
                                </span><span class="c4">чём</span><span class="c4">&nbsp;именно
                                        загвоздка, и тогда
                                        вы сможете
                                        увеличить
                                        онлайн-продажи,
                                        исправив </span><span class="c4">недочёты</span><span class="c4">&nbsp;и
                                        сделав
                                        интернет-покупку
                                        для посетителей
                                        более
                                        привлекательной.
                                        Хорошо сработают
                                        дополнительные
                                        скидки, </span><span class="c4">продлённая</span><span
                                        class="c0">&nbsp;гарантия,
                                        подробный
                                        FAQ-раздел и т.д.</span></p>
                        <p class="c54 c77"><span class="c0"></span></p>
                        <p class="c83"><span class="c6">Проведение
                                        ROPO-анализа</span></p>
                        <p class="c36"><span class="c0">Наиболее
                                        часто
                                        используемый
                                        метод основан на
                                        отслеживании
                                        действий
                                        конкретного
                                        зарегистрированного
                                        пользователя
                                        сайта и его
                                        покупок в
                                        розничном
                                        магазине. Итак,
                                        порядок действий
                                        выглядит
                                        следующим
                                        образом:</span></p>
                </div>

                <!-- 41 -->
                <div data-num="41" class="numNUMBER page-mimi" id="container-pagnation41">
                        <ol class="c9 lst-kix_wrcmw3lwvffx-0 start" start="1">
                                <li class="c13 li-bullet-2"><span class="c4">Соотнесение
                                                данных </span><span class="c4">учётных</span><span
                                                class="c0">&nbsp;записей сайта
                                                с транзакциями
                                                из CRM;</span></li>
                                <li class="c13 li-bullet-2"><span class="c0">Определение
                                                доли ROPO-покупок в
                                                продажах — как
                                                онлайн, так и
                                                офлайн;</span></li>
                                <li class="c13 li-bullet-7"><span class="c0">Создание
                                                дашбордов для
                                                отслеживания
                                                данных;</span></li>
                                <li class="c13 li-bullet-7"><span class="c0">Определить
                                                спектр
                                                дальнейших
                                                действий и
                                                мероприятий,
                                                связанных с
                                                ROPO-покупателями:
                                                оптимизация
                                                сайта, рекламных
                                                каналов и т.д.</span></li>
                        </ol>
                        <p class="c36"><span class="c6">Объединение
                                        онлайн- и
                                        офлайн-данных</span></p>
                        <p class="c36"><span class="c0">Для решения
                                        задачи по
                                        объединению
                                        данных можно
                                        использовать как
                                        популярные
                                        BI-платформы,
                                        подходящие
                                        среднему и
                                        крупному бизнесу,
                                        так и обычный Google Sheets
                                        для небольшого
                                        предприятия.
                                        Золотой же
                                        серединой может
                                        стать облачное
                                        хранилище данных
                                        Google BigQuery, которое
                                        отличается
                                        гибкостью и
                                        простотой
                                        взаимодействия.</span>
                        </p>
                        <p class="c36"><span class="c6">Необходимые
                                        данные для
                                        ROPO-анализа</span></p>
                        <p class="c36"><span class="c73">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span
                                        class="c0">1.
                                        Поведенческие
                                        данные
                                        зарегистрированных
                                        пользователей.</span></p>
                        <p class="c36"><span class="c4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Обычно
                                        без проблем
                                        выгружаются даже
                                        из бесплатной
                                        версии Google Analytics прямо в
                                        Google BigQuery при помощи OWOX BI Pipeline. В
                                        GA </span><span class="c4">передаётся</span><span class="c0">&nbsp;с сайта
                                        идентификатор User ID,
                                        поэтому
                                        проследите, чтобы
                                        он был корректно
                                        настроен.</span></p>
                        <p class="c36"><span class="c4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.
                                        Офлайн-данные о </span><span class="c4">завершённых</span><span
                                        class="c0">&nbsp;заказах.</span></p>
                        <p class="c36"><span class="c0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Из
                                        вашей CRM в
                                        хранилище Google BigQuery
                                        должны поступать
                                        как минимум
                                        следующие
                                        данные:</span></p>
                        <p class="c36"><span class="c0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;•
                                        Дата совершения
                                        заказа<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• ID
                                        транзакции<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;•
                                        Сумма
                                        заказа<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• ID
                                        покупателя</span></p>
                        <p class="c36"><span class="c0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.
                                        Рекламные
                                        расходы.</span></p>
                </div>

                <!-- 42 -->
                <div data-num="42" class="numNUMBER page-mimi" id="container-pagnation42">
                        <p class="c36"><span class="c0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Помимо
                                        ROPO-данных, нелишним
                                        будет также
                                        выявить и ROAS, а для
                                        этого
                                        потребуется
                                        информация о
                                        ваших рекламных
                                        источниках.
                                        Данные о
                                        рекламных
                                        расходах
                                        загружаются в GA, и
                                        затем оттуда уже
                                        кочуют в BigQuery.</span></p>
                        <p class="c36"><span class="c0">Как только
                                        все необходимые
                                        данные окажутся в
                                        хранилище, вам
                                        останется только
                                        соотнести их друг
                                        с другом,
                                        например, при
                                        помощи
                                        уникального
                                        идентификатора User ID.
                                        Таким образом,
                                        когда
                                        пользователь
                                        обращается к
                                        личному кабинету
                                        на сайте, то при
                                        наличии
                                        соответствующей
                                        настройки GA об
                                        этом узнаёт и
                                        синхронизирует
                                        данные о
                                        производимых на
                                        сайте действиях.</span>
                        </p>
                        <p class="c14"><span class="c0"></span></p><a id="kix.lxxf5cgwx6o3"></a><a
                                id="kix.ougkzdk94n8"></a>
                        <h2 class="c30" id="h.xexaujuyzixu"><span class="c22 c10">Сквозной
                                        идентификатор
                                        на&nbsp;примере GOOGLE CLIENT&nbsp;ID</span></h2>
                        <p class="c8"><span class="c0">Для чего
                                        нужен Client ID в&nbsp;Google Analytics?</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Выражаясь
                                        более простым
                                        языком, с&nbsp;помощью
                                </span><span class="c4">ClientID</span><span class="c0">&nbsp;в&nbsp;Google Analytics
                                        считается
                                        количество
                                        уникальных
                                        пользователей
                                        или посетителей
                                        на&nbsp;сайтах. Связка
                                        «устройство-браузер»
                                        является
                                        своеобразным
                                        идентификатором,
                                        который
                                        позволяет
                                        достаточно точно
                                        определить, какое
                                        количество
                                        уникальных
                                        посещений
                                        получил тот или
                                        иной сетевой
                                        ресурс.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">По&nbsp;понятным
                                        причинам
                                        параметр Client ID
                                        чрезвычайно
                                        важен для
                                        настройки
                                        сквозной
                                        аналитики, ведь
                                        именно
                                        от&nbsp;количества
                                        посещений
                                        продающего сайта
                                        напрямую зависит
                                        итоговая
                                        конверсия.
                                        С&nbsp;помощью этого
                                        показателя
                                        и&nbsp;данных из&nbsp;CRM
                                        можно получить
                                        наглядное
                                        представление
                                        о&nbsp;том, насколько
                                        успешно работают
                                        запущенные
                                        рекламные
                                        кампании вашего
                                        бизнеса.</span></p>
                        <p class="c5"><span class="c6"></span></p>
                </div>

                <!-- 43 -->
                <div data-num="43" class="numNUMBER page-mimi" id="container-pagnation43">
                        <h3 class="c15" id="h.nk49r1a0bjoo"><span class="c11 c10">Работа
                                        Client&nbsp;ID</span></h3>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c4">Чисто
                                        технически </span><span class="c4">Client
                                        ID</span><span class="c0">&nbsp;представляет
                                        собой cookie-файл,
                                        который
                                        создаётся
                                        браузером
                                        и&nbsp;хранится
                                        на&nbsp;стороне
                                        клиента. Каждый
                                        раз, когда
                                        пользователь
                                        заходит
                                        на&nbsp;какой-либо
                                        сайт, браузер
                                        передаёт этот
                                        файл по&nbsp;запросу Google
                                        Analytics. В&nbsp;файле
                                        содержится
                                        числовой код,
                                        являющийся
                                        уникальным для
                                        каждого
                                        отдельного
                                        пользователя.
                                        Таким образом, при
                                        открытии любой
                                        интернет-страницы
                                        служба
                                        веб-аналитики
                                        Гугла получает
                                        из&nbsp;cookie-файла всю
                                        необходимую
                                        информацию,
                                        состоящую
                                        из&nbsp;адреса
                                        ресурса,
                                        источника
                                        перехода, языка
                                        и&nbsp;т.&nbsp;д.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Такой файл </span><span class="c4">создаётся</span><span
                                        class="c4">&nbsp;для
                                        каждого
                                        посещаемого
                                        сайта, и&nbsp;его срок
                                        жизни составляет
                                        2&nbsp;года. Причём, при
                                        каждом посещении
                                        этот срок
                                        обновляется,
                                        поэтому если
                                        не&nbsp;посещать сайт
                                        больше 2х лет (или
                                        удалить cookies), то при
                                        открытии ресурса
                                        будет
                                        сгенерирован
                                        новый </span><span class="c4">Client ID</span><span class="c0">,
                                        а&nbsp;вы будете
                                        считаться новым
                                        уникальным
                                        пользователем.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Чтобы найти
                                        отчёт GA по&nbsp;всем Client ID,
                                        достаточно
                                        пройти
                                        в&nbsp;«Аудитория» =&gt;
                                        «Статистика
                                        по&nbsp;пользователям».
                                        Там вы </span><span class="c4">найдёте</span><span class="c0">&nbsp;как сами
                                        уникальные
                                        идентификаторы
                                        посетителей
                                        вашего сайта, так
                                        и&nbsp;данные
                                        по&nbsp;количеству
                                        сессий,
                                        показателю
                                        отказов,
                                        транзакциям,
                                        доходам и&nbsp;CR. Это
                                        важная
                                        информация для
                                        любого
                                        специалиста
                                        по&nbsp;продвижению.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <h3 class="c15" id="h.4zaiebb8w1ma"><span class="c11 c10">Client ID в&nbsp;CRM</span></h3>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Параметр Client ID
                                        позволяет
                                        не&nbsp;только
                                        отследить
                                        поведение
                                        клиента на&nbsp;вашем
                                        целевом ресурсе,
                                        но&nbsp;и&nbsp;выяснить
                                        другую важную
                                        информацию.
                                        К&nbsp;примеру,
                                        источник
                                        перехода каждого
                                        посетителя
                                        поможет выяснить,
                                        какая
                                        из&nbsp;запущенных
                                        рекламных
                                        кампаний окупает
                                        себя наиболее
                                        эффективным
                                        образом.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">С&nbsp;помощью
                                        синергии вашей CRM
                                        с&nbsp;данными из&nbsp;Google Analytics
                                        появится
                                        возможность
                                        оперативно
                                        отслеживать,
                                        к&nbsp;примеру,
                                        показатель
                                        выкупленных
                                        заказов. Передача
                                        идентификатора
                                        каждого
                                        покупателя
                                        обычно
                                        настраивается
                                        через форму
                                        заказа товара
                                        на&nbsp;сайте. Иногда
                                        готовые
                                        конструкторы
                                        таких форм уже
                                        есть в&nbsp;некоторых
                                        CRM, а&nbsp;иногда
                                        требуется
                                        внедрение силами
                                        специалиста.</span></p>
                        <h1 class="c108 c59 c125" id="h.qzlg1pfnvqaf"><span class="c6"></span></h1>
                        <p class="c25"><span class="c42 c10 c38"></span></p><a id="id.35nkun2"></a><a
                                id="id.lnxbz9"></a>
                </div>

                <!-- 44 -->
                <div data-num="44" class="numNUMBER page-mimi" id="container-pagnation44">
                        <h2 class="c113 c81 c65"><span class="c23">Модели
                                        атрибуции </span></h2>
                        <h3 class="c15"><span class="c11 c10">Зачем нужна
                                        атрибуция</span></h3>
                        <p class="c8"><span class="c0">Стандартно
                                        воронка продаж
                                        имеет четыре
                                        этапа:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_5eesn1ewbq25-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">Человек
                                                знакомится
                                                с&nbsp;торговой
                                                маркой;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Он знает
                                                о&nbsp;компании,
                                                но&nbsp;размышляет,
                                                совершать&nbsp;ли
                                                покупку, и
                                                поэтому
                                                проводит
                                                сравнение
                                                стоимости
                                                и&nbsp;анализирует
                                                характеристики
                                                предлагаемого
                                                товара;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Этап
                                                конверсии&nbsp;—
                                                покупка
                                                совершается;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Этап
                                                удержания&nbsp;—
                                                покупатель
                                                повторяет
                                                покупку.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Как известно,
                                        удержать тех, кто
                                        уже совершил
                                        покупку, намного
                                        дешевле для
                                        компании, чем
                                        искать новых
                                        покупателей.
                                        Привлечение
                                        используют не
                                        персонализированные
                                </span><span class="c4">кампании</span><span class="c0">,
                                        которые нацелены
                                        на&nbsp;широкий охват
                                        и&nbsp;трудно
                                        поддаются
                                        оценке.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Удержание
                                        подразумевает
                                        применение более
                                        целевых кампаний,
                                        для которых
                                        значительно
                                        проще проводить
                                        анализ и
                                        рассчитывать
                                        эффективность.
                                        Конкретный
                                        пользователь
                                        известен и теперь
                                        его действия
                                        и&nbsp;покупки можно
                                        отследить.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Чтобы
                                        разобраться,
                                        какие
                                        используемые
                                        рекламные каналы
                                        и&nbsp;кампании
                                        срабатывают
                                        на&nbsp;этапах
                                        имеющейся
                                        воронки,
                                        необходимо
                                        воспользоваться
                                        атрибуцией.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Атрибуция</span><span class="c4 c18 c38">&nbsp;— это
                                        распределение
                                        ценности от
                                        конверсии между
                                        кампаниями,
                                        которые
                                        продвигали
                                        пользователя по
                                        воронке. Она
                                        помогает
                                        ответить на
                                        вопрос, в какой
                                        мере каждый из
                                        каналов повлиял
                                        на ту прибыль,
                                        которую вы
                                        получили в итоге.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 45 -->
                <div data-num="45" class="numNUMBER page-mimi" id="container-pagnation45">
                        <p class="c8"><span class="c0">Выбрав модель
                                        атрибуции,
                                        которая подходит
                                        для конкретного
                                        бизнес-проекта,
                                        можно
                                        распределить
                                        рекламный бюджет
                                        эффективно, что,
                                        в&nbsp;свою очередь,
                                        поможет
                                        сократить
                                        затраты
                                        и&nbsp;увеличить
                                        прибыль.</span></p>
                        <h3 class="c15"><span class="c11 c10">Доступные
                                        модели
                                        атрибуции</span></h3>
                        <p class="c8"><span class="c0">Моделей
                                        атрибуции много,
                                        и&nbsp;они поддаются
                                        определенной
                                        классификации.
                                        Опираться нужно
                                        на&nbsp;то, какая
                                        именно логика
                                        применяется
                                        во&nbsp;время
                                        расчета:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_ywgie1ey0oq9-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">Если вся
                                                ценность отдана
                                                единственному
                                                каналу,
                                                участвовавшему
                                                в&nbsp;воронке, то это -
                                                одноканальная
                                                модель
                                                атрибуции;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Если
                                                обратить
                                                внимание
                                                на&nbsp;место канала
                                                в&nbsp;цепочке
                                                непосредственно
                                                перед покупкой,
                                                то применяется
                                                атрибуция
                                                на&nbsp;основе
                                                позиции;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Если
                                                распределение
                                                происходит
                                                между всеми
                                                участвовавшими
                                                в&nbsp;цепочке
                                                каналами, то это -
                                                многоканальная
                                                модель;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Если
                                                в&nbsp;расчет
                                                берутся прочие
                                                факторы —
                                                не&nbsp;только
                                                позиция, — то
                                                алгоритмическая.<br></span>
                                </li>
                        </ul>
                        <p class="c8"><span class="c4">Модели
                                        нуждаются
                                        в&nbsp;более
                                        подробном
                                        рассмотрении.
                                        Ниже мы подробнее
                                        познакомимся с
                                        моделями
                                        атрибуции,
                                        разберем пример,
                                        где и как они
                                        используются и
                                        какими чаще всего
                                        пользуются
                                        маркетологи. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h4 class="c82 c59" id="h.8wjrjh5ol3kk"><span class="c6">Позиции
                                        канала в цепочке</span>
                        </h4>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Данные
                                        варианты
                                        считаются
                                        наиболее
                                        простыми, они
                                        доступны
                                        пользователям
                                        бесплатной
                                        версии Google Analytics, а также
                                        Яндекс.Метрики и
                                        других систем.
                                        Рассмотрим 6
                                        позиций канала в
                                        цепочке.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 46 -->
                <div data-num="46" class="numNUMBER page-mimi" id="container-pagnation46">
                        <h5 class="c50" id="h.v8q2ekh2b7oo"><span class="c6">First Click (FCM)</span></h5>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Одноканальная
                                        модель, в&nbsp;которой
                                        ценность,
                                        полученная
                                        от&nbsp;конверсии,
                                        атрибутируется
                                        первому
                                        источнику,
                                        повлиявшему
                                        на&nbsp;решение
                                        покупателя.
                                        В&nbsp;цепочке
                                        из&nbsp;четырех
                                        касаний ценность
                                        уходит первому
                                        каналу.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Преимущества:</span><span
                                        class="c0">&nbsp;<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Легко
                                        настраивается,
                                        не&nbsp;требует
                                        вычислений или
                                        иных аргументов
                                        при
                                        распределении
                                        ценности среди
                                        использованных
                                        каналов.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Помогает
                                        маркетологам
                                        сформировать
                                        узнаваемость
                                        торговой марки
                                        и&nbsp;спрос. <br></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Недостатки:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Не&nbsp;демонстрирует
                                        всей картины,
                                        заставляет
                                        переоценить
                                        каналы первого
                                        уровня.
                                        Пользователь
                                        обычно совершает
                                        несколько
                                        касаний, однако
                                        модель
                                        игнорирует
                                        данный момент.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Кому
                                        подходит:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Подойдет
                                        проектам, для
                                        которых имеет
                                        значение
                                        создание или
                                        повышение
                                        узнаваемости
                                        собственного
                                        бренда,
                                        увеличение
                                        охвата аудитории.
                                        Модель даст
                                        информацию о&nbsp;том,
                                        где лучше
                                        покупать трафик
                                        для последующей
                                        конвертации.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c50" id="h.7uwwft6z73mn"><span class="c6">Last Click (LCM)</span></h5>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Одноканальная
                                        модель, где
                                        ценность
                                        конверсии
                                        передается
                                        последнему
                                        каналу, с&nbsp;которым
                                        покупатель
                                        соприкасается
                                        непосредственно
                                        перед конверсией.
                                        Снова вклад
                                        предыдущих
                                        каналов
                                        полностью
                                        игнорируется.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 47 -->
                <div data-num="47" class="numNUMBER page-mimi" id="container-pagnation47">
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Преимущества:</span>
                        </p>
                        <p class="c5"><span class="c4 c20 c48 c38 c29"></span></p>
                        <p class="c8"><span class="c0">Используется
                                        многими
                                        маркетологами.
                                        Позволяет
                                        оценить кампании,
                                        цель которых&nbsp;—
                                        быстро
                                        спровоцировать
                                        покупки, допустим,
                                        во&nbsp;время
                                        определенного
                                        сезона. <br></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Недостатки:</span>
                        </p>
                        <p class="c5"><span class="c4 c20 c48 c38 c29"></span></p>
                        <p class="c8"><span class="c0">Не&nbsp;демонстрирует
                                        всей картины,
                                        заставляя
                                        исключить прочие
                                        каналы цепочки.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Кому
                                        подходит:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Подходит
                                        бизнесам
                                        с&nbsp;коротким
                                        циклом продаж,
                                        которые обычно
                                        не&nbsp;используют
                                        более трех
                                        каналов для
                                        рекламы.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c85 c59" id="h.cnqrjqzht3yu"><span class="c6">Last Non-Direct Click (LN-DC)</span>
                        </h5>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Одноканальная
                                        модель, которая
                                        представлена в&nbsp;Google
                                        Analytics, применяется
                                        там по&nbsp;умолчанию.
                                        При этом ценность
                                        конверсии
                                        атрибутируется,
                                        как
                                        и&nbsp;в&nbsp;предыдущем
                                        варианте, по
                                        последнему
                                        каналу.</span></p>
                        <p class="c8"><span class="c0">Однако
                                        различие в&nbsp;том,
                                        что если это
                                        прямой заход,
                                        ценность будет
                                        атрибутирована
                                        предыдущему
                                        источнику.</span></p>
                        <p class="c8"><span class="c0">Например,
                                        пользователь
                                        переходит
                                        непосредственно
                                        из&nbsp;собственных
                                        закладок или&nbsp;же
                                        прямо вводит
                                        ссылку. Вероятно,
                                        он хорошо знает
                                        бренд, является
                                        уже привлеченным
                                        покупателем,
                                        которого
                                        не&nbsp;требуется
                                        брать в&nbsp;расчет.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Преимущества:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">В&nbsp;этом случае
                                        можно исключить
                                        каналы, которые
                                        незначительны
                                        с&nbsp;точки зрения
                                        расходов
                                        на&nbsp;кампанию,
                                        полностью
                                        сосредоточившись
                                        на&nbsp;оплачиваемых
                                        источниках.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Может
                                        применяться
                                        в&nbsp;качестве базы
                                        для сравнения.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 48 -->
                <div data-num="48" class="numNUMBER page-mimi" id="container-pagnation48">
                        <p class="c8"><span class="c4 c20 c48">Недостатки:</span><span
                                        class="c4 c20 c48">&nbsp;</span><span class="c0"><br><br>Не&nbsp;демонстрирует
                                        всей картины,
                                        не&nbsp;учитывает
                                        вклад прочих
                                        каналов
                                        в&nbsp;конверсию.
                                        Предпоследним
                                        каналом чаще
                                        всего является
                                        электронная
                                        почта, однако эта
                                        модель
                                        не&nbsp;позволяет
                                        отследить, где
                                        именно
                                        покупатель
                                        познакомился
                                        с&nbsp;торговой
                                        маркой и&nbsp;почему
                                        оставил почту,
                                        чтобы в&nbsp;итоге
                                        прийти
                                        к&nbsp;покупке.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Кому
                                        подходит:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Модель
                                        подходит, если
                                        нужно оценить
                                        эффективность
                                        определенного
                                        платного канала,
                                        а&nbsp;узнаваемость
                                        бренда уже
                                        не&nbsp;является
                                        важным аспектом.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c50" id="h.hezh25kaa2ln"><span class="c6">Position Based&nbsp;(PB)</span></h5>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c4">Многоканальная
                                        модель, где
                                        наибольшую
                                        ценность
                                        получают первый
                                        канал </span><span class="c4">— </span><span class="c4">то
                                        есть тот, который
                                        познакомил
                                        покупателя
                                        и&nbsp;торговую марку,
                                </span><span class="c4">—</span><span class="c0">&nbsp;и&nbsp;последний,
                                        что закрыл
                                        транзакцию.
                                        Каждому из&nbsp;них
                                        присваивается
                                        сорок процентов.
                                        На&nbsp;все средние
                                        каналы
                                        приходится
                                        двадцать
                                        процентов.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Преимущества:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Ценность
                                        передается
                                        каналам, которые
                                        привлекают
                                        и&nbsp;мотивируют
                                        покупателей </span><span class="c4">— т.е. </span><span class="c0">играют
                                        важнейшую роль. <br></span>
                        </p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Недостатки:</span>
                        </p>
                        <p class="c5"><span class="c4 c20 c48 c38 c29"></span></p>
                        <p class="c8"><span class="c0">Случается,
                                        что именно
                                        средние каналы
                                        в&nbsp;цепочке больше
                                        продвигают
                                        покупателя, чем
                                        те, которые
                                        получают
                                        наибольшую
                                        ценность.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 49 -->
                <div data-num="49" class="numNUMBER page-mimi" id="container-pagnation49">
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Кому
                                        подходит:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Этот вариант
                                        подойдет
                                        бизнесам, которые
                                        рассчитывают
                                        привлекать новых
                                        пользователей
                                        и&nbsp;подталкивать
                                        уже
                                        заинтересованных
                                        к&nbsp;совершению
                                        покупок.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c50" id="h.138lutj0mbdk"><span class="c6">Time Decay&nbsp;(TD)</span></h5>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">В&nbsp;этом случае
                                        ценность
                                        конверсии будет
                                        распределена
                                        между каналами,
                                        которые заняты
                                        в&nbsp;цепочке,
                                        по&nbsp;принципу
                                        нарастания.
                                        Первый источник
                                        получает
                                        наименьшую
                                        ценность,
                                        последний&nbsp;—
                                        наибольшую.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Преимущества:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Рассматриваются
                                        все каналы.
                                        Наибольшая
                                        ценность
                                        отдается тому,
                                        который все&nbsp;же
                                        сумеет
                                        подтолкнуть
                                        к&nbsp;покупке. <br></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Недостатки:</span>
                        </p>
                        <p class="c5"><span class="c4 c20 c48 c38 c29"></span></p>
                        <p class="c8"><span class="c0">Недооценивается
                                        вклад отдельных
                                        каналов, которые
                                        могли повлиять
                                        на&nbsp;решение
                                        покупателя.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Кому
                                        подходит:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Подходит тем,
                                        кто желает
                                        оценить
                                        эффективность
                                        рекламных
                                        кампаний,
                                        ограниченных
                                        по&nbsp;времени </span><span class="c4">—</span><span class="c0">&nbsp;например,
                                        распродаж.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c50" id="h.4nymakkctg45"><span class="c6">Linear model&nbsp;(LM)</span></h5>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Применяя
                                        данную модель,
                                        ценность
                                        конверсии
                                        принято
                                        разделять между
                                        всеми каналами
                                        цепочки.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Преимущества:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Более
                                        продвинутая, чем
                                        одноканальные
                                        модели. Позволяет
                                        учесть все каналы
                                        в&nbsp;цепочке,
                                        которые были
                                        задействованы
                                        перед покупкой. <br></span>
                        </p>
                </div>

                <!-- 50 -->
                <div data-num="50" class="numNUMBER page-mimi" id="container-pagnation50">
                        <p class="c8"><span class="c4 c20 c48">Недостатки:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Не&nbsp;помогает
                                        перераспределять
                                        бюджет.
                                        Разделение его
                                        между всеми
                                        каналами поровну
                                        может оказаться
                                        неэффективным.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Кому
                                        подходит:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Подойдёт
                                        бизнесам с
                                        длительным
                                        циклом продаж.
                                        В&nbsp;этом случае
                                        важно
                                        поддержание
                                        контакта
                                        с&nbsp;покупателем
                                        на&nbsp;всех этапах
                                        прохождения
                                        воронки. Пример&nbsp;—
                                        B2B-компании.</span></p>
                        <p class="c5"><span class="c0"></span></p><a id="id.z337ya"></a>
                        <h3 class="c15"><span class="c11 c10">Выбор модели
                                        атрибуции
                                        и&nbsp;проблема
                                        стандартных
                                        вариантов</span></h3>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c0">Правильный
                                        выбор модели
                                        помогает оценить
                                        эффективность
                                        рекламной
                                        кампании.
                                        В&nbsp;зависимости
                                        от&nbsp;него, можно
                                        получить
                                        противоположные
                                        выводы о&nbsp;том,
                                        насколько
                                        рентабелен
                                        конкретный
                                        используемый
                                        канал.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Наиболее
                                        заметно это
                                        в&nbsp;тематиках,
                                        которые
                                        традиционно
                                        заставляют
                                        покупателя
                                        размышлять перед
                                        покупкой
                                        продолжительное
                                        время. Например,
                                        в&nbsp;сфере
                                        недвижимости или
                                        при приобретении
                                        автомобиля.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Классические
                                        модели атрибуции
                                        достаточно
                                        ограничены. Это
                                        может показать
                                        простой пример.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Допустим, что
                                        основная цель (D)&nbsp;—
                                        пригласить
                                        девушку на&nbsp;кофе
                                        к&nbsp;себе домой.
                                        Каналы и цепочка
                                        действий, которые
                                        могли&nbsp;бы
                                        привести
                                        к&nbsp;желанной цели,
                                        следующие:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Знакомство
                                        с&nbsp;девушкой →
                                        Приглашение
                                        в&nbsp;кафе → Цветы
                                        в&nbsp;подарок →
                                        Прогулка в&nbsp;парке
                                        → Проводить домой
                                        → Свидание
                                        в&nbsp;ресторане →
                                        Цветы в&nbsp;подарок →
                                        Ужин в&nbsp;ресторане
                                        → Коктейль в&nbsp;баре
                                        → Второй коктейль
                                        → Танцпол →
                                        Приглашение
                                        на&nbsp;кофе к&nbsp;себе
                                        домой.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 51 -->
                <div data-num="51" class="numNUMBER page-mimi" id="container-pagnation51">
                        <p class="c8"><span class="c4">На&nbsp;примере
                                        этой цепочки
                                        становится
                                        понятно, что при
                                        использовании FCM
                                        (по первому
                                        каналу)</span><span class="c4">&nbsp;</span><span class="c4">наиболее
                                        важным
                                        представляется
                                        знакомство. Если
                                        оно свершилось, то
                                        цель практически
                                        достигнута.
                                        Если&nbsp;же
                                        использовать</span><span class="c4">&nbsp;LCM (по последнему
                                        каналу) ,</span><span class="c0">&nbsp;то
                                        достаточно
                                        пригласить
                                        девушку на&nbsp;танец,
                                        чтобы в&nbsp;итоге
                                        получить
                                        желаемое.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">LM (по всем
                                        каналам)</span><span class="c0">&nbsp;подразумевает,
                                        что действия
                                        от&nbsp;знакомства
                                        к&nbsp;утреннему кофе
                                        равноценны для
                                        продвижения, а&nbsp;TDM
                                        предполагает, что
                                        каждый шаг все
                                        более
                                        подталкивает
                                        девушку
                                        к&nbsp;решению.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Но&nbsp;ни одна
                                        из&nbsp;моделей
                                        не&nbsp;подсказывает,
                                        что на&nbsp;самом деле
                                        происходит,
                                        и&nbsp;какое действие
                                        цепочки наиболее
                                        эффективно ведет
                                        к&nbsp;результату.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">На&nbsp;сегодняшний
                                        день имеется ряд
                                        исследований,
                                        которые
                                        доказывают, что
                                        маркетологи
                                        в&nbsp;Европе, США или
                                        СНГ чаще всего
                                        обращаются
                                        к&nbsp;модели LCM. А&nbsp;вот
                                        алгоритмическими
                                        моделями
                                        пользуются
                                        значительно реже.
                                        Причем, такая
                                        картина
                                        сложилась
                                        не&nbsp;из-за каких-то
                                        определенных
                                        преимуществ
                                        выбранной модели,
                                        а&nbsp;просто из-за
                                        того, что LCM кажется
                                        наиболее
                                        понятной, хотя
                                        и&nbsp;обесценивает
                                        влияние всех
                                        каналов в цепочке,
                                        кроме
                                        последнего.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Причинами,
                                        почему
                                        наблюдается
                                        такая ситуация,
                                        можно считать
                                        следующее:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_x7wj93tru840-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Непонимание
                                                потенциального
                                                эффекта
                                                от&nbsp;моделей
                                                атрибуции,
                                                использующих
                                                более сложный
                                                расчет. Если
                                                прямо объяснить,
                                                что
                                                алгоритмические
                                                модели могут
                                                принести
                                                увеличение
                                                прибыли
                                                на&nbsp;определенный
                                                процент, вряд&nbsp;ли
                                                маркетологи
                                                откажутся
                                                от&nbsp;этого.</span></li>
                        </ul>
                </div>

                <!-- 52 -->
                <div data-num="52" class="numNUMBER page-mimi" id="container-pagnation52">
                        <li class="c17 li-bullet-7"><span class="c0">За&nbsp;атрибуцию
                                        нет
                                        ответственного,
                                        т.е. разные
                                        маркетологи
                                        могут применять
                                        в&nbsp;ходе кампании
                                        различные
                                        варианты, что
                                        приводит к&nbsp;тому,
                                        что реальный
                                        доход
                                        оказывается
                                        меньше
                                        атрибутированного.</span>
                        </li>
                        <li class="c17 li-bullet-7"><span class="c4">Слишком
                                        разрозненная
                                        информация. Google Analytics
                                        позволяет
                                        использовать
                                        стандартные
                                        отчеты,
                                        в&nbsp;которых,
                                        к&nbsp;сожалению, нет
                                        места </span><span class="c4">офлайн</span><span class="c0">-данным,
                                        ROPO-эффекту и&nbsp;т.&nbsp;д.</span></li>

                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Если эти
                                        причины
                                        устранить, то
                                        проблема
                                        атрибуции будет
                                        решаться намного
                                        проще.</span></p>
                        <p class="c5"><span class="c0"></span></p><a id="id.3j2qqm3"></a>
                        <h3 class="c15">
                                <span>Алгоритмические
                                        модели</span>
                        </h3>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c0">Внутри Google Analytics или
                                        рекламного
                                        кабинета при
                                        настройке
                                        рекламы в&nbsp;Google Ads
                                        применение более
                                        сложных моделей
                                        будет
                                        бессмысленным.
                                        В&nbsp;то&nbsp;же время, при
                                        необходимости
                                        анализа
                                        взаимного
                                        влияния всех
                                        используемых
                                        источников
                                        требуется
                                        объединение
                                        информации
                                        из&nbsp;различных
                                        сервисов. В&nbsp;этом
                                        случае
                                        предпочтительнее
                                        применять именно
                                        сложные модели.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h4 class="c82 c59" id="h.gq7xa1feqw9x"><span class="c6">Цепи
                                        Маркова (Markov Chains)</span></h4>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Цепи Маркова
                                        применялись для
                                        прогнозирования,
                                        например,
                                        букмекерскими
                                        конторами. Теперь
                                        они используются
                                        и&nbsp;для рекламных
                                        кампаний. Данная
                                        модель позволит
                                        ответить
                                        на&nbsp;вопрос,
                                        повлияет&nbsp;ли
                                        на&nbsp;транзакцию
                                        отсутствие
                                        канала
                                        в&nbsp;цепочке.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Цепи
                                        Маркова</span><span class="c4 c18 c38">&nbsp;—
                                        последовательность
                                        событий
                                        со&nbsp;счетным или
                                        конечным
                                        количеством
                                        исходов. Основная
                                        их
                                        характеристика&nbsp;—
                                        настоящее
                                        фиксировано,
                                        а&nbsp;будущее
                                        не&nbsp;зависит
                                        от&nbsp;прошлого.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 53 -->
                <div data-num="53" class="numNUMBER page-mimi" id="container-pagnation53">
                        <p class="c14"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Преимущества:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Позволяет
                                        оценить, как
                                        каналы влияют
                                        друг на&nbsp;друга,
                                        и&nbsp;выявить
                                        наиболее
                                        значимый.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Недостатки:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Недооценивает
                                        первый канал. Для
                                        использования
                                        нужны навыки
                                        программирования.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Такая модель
                                        может
                                        применяться
                                        в&nbsp;том случае, если
                                        все данные
                                        собраны в&nbsp;одну
                                        систему.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h4 class="c82 c59" id="h.qs6sjs9hrxgu"><span class="c6">Атрибуция на
                                        основе данных &nbsp;(Data-Driven
                                        Attribution, DDA)</span></h4>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Доступная
                                        платным
                                        пользователям Google Analytics
                                        модель
                                        основывается
                                        на&nbsp;данных,
                                        собираемых
                                        системой. Если
                                        предыдущие
                                        модели применяют
                                        определенные
                                        правила, заданные
                                        аналитиком или
                                        системой, то эта
                                        подобных
                                        не&nbsp;имеет,
                                        рассчитывая
                                        ценность
                                        с&nbsp;помощью
                                        полученной
                                        информации
                                        и&nbsp;Вектора Шелли.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Вектор
                                        Шелли</span><span class="c4 c18 c38">&nbsp;—
                                        в&nbsp;задачах теории
                                        кооперативных
                                        игр это принцип
                                        оптимального
                                        распределения
                                        выигрыша между
                                        участниками.
                                        Распределение
                                        происходит
                                        по&nbsp;среднему
                                        вкладу участника
                                        в&nbsp;благосостояние
                                        коалиции.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Преимущества:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Модель весьма
                                        достоверна
                                        и&nbsp;может
                                        считаться
                                        наиболее
                                        объективной. При
                                        оценке
                                        используются
                                        собственные
                                        данные. <br></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Недостатки:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Расчет
                                        возможен только
                                        в&nbsp;том случае, если
                                        имеется
                                        достаточный
                                        объем данных, что
                                        не&nbsp;всегда
                                        подходит
                                        отдельным
                                        компаниям.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 54 -->
                <div data-num="54" class="numNUMBER page-mimi" id="container-pagnation54">
                        <p class="c8"><span class="c0">Позволяет
                                        определить, какие
                                        кампании
                                        и&nbsp;ключевики
                                        работают
                                        наиболее
                                        эффективно. Имеет
                                        возможность
                                        распределения
                                        маркетингового
                                        бюджета. Однако
                                        не&nbsp;подойдет
                                        в&nbsp;том случае, если
                                        важно учитывать
                                        и&nbsp;место канала
                                        в&nbsp;цепочке.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h4 class="c82 c59" id="h.4ozf1q2jozzv"><span class="c6">OWOX BI Attribution</span></h4>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Открывает
                                        возможности для
                                        оценки
                                        взаимовлияния
                                        каналов
                                        на&nbsp;конверсию
                                        и&nbsp;движение
                                        покупателя
                                        по&nbsp;воронке.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Модель
                                        использует
                                        информацию из&nbsp;Google
                                        Analytics&nbsp;— информацию
                                        о&nbsp;том, как ведут
                                        себя
                                        пользователи.
                                        Также в&nbsp;нее можно
                                        включить данные
                                        рекламных
                                        сервисов
                                        и&nbsp;внутренней
                                        CRM-системы.
                                        Показатели можно
                                        проанализировать
                                        комплексно,
                                        используя
                                        настройку шагов
                                        воронки.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Преимущества:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Выявляет
                                        наиболее
                                        эффективный
                                        канал
                                        и&nbsp;указывает,
                                        в&nbsp;чем его
                                        эффективность.
                                        Минимальный
                                        объем данных
                                        не&nbsp;ограничен.
                                        Дает возможность
                                        выделить новых </span><span class="c4">или</span><span
                                        class="c0">&nbsp;вернувшихся
                                        пользователей,
                                        демонстрирует
                                        детальные данные
                                        по&nbsp;всем
                                        транзакциям.
                                        Учитывает маржу,
                                        исполнимость
                                        заказов. <br></span></p>
                        <p class="c8"><span class="c4 c20 c26 c38">Недостатки:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Может
                                        недооценить
                                        первый шаг
                                        воронки.</span></p>
                        <p class="c8"><span class="c0">Подойдет тем,
                                        кто желает
                                        учитывать все
                                        шаги
                                        пользователя
                                        в&nbsp;воронке,
                                        а&nbsp;также
                                        проводить
                                        объективный
                                        анализ рекламных
                                        каналов.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Подробнее о
                                        моделях
                                        атрибуции можно
                                        прочитать,
                                        например, в статье
                                        “Модели
                                        атрибуции —
                                        подробный обзор и
                                        сравнение”:
                                        https://www.owox.ru/blog/articles/marketing-attribution-models/</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c54 c110 c115"><span class="c0"></span></p>

                </div>

                <!-- 55 -->
                <div data-num="55" class="numNUMBER page-mimi" id="container-pagnation55">
                        <h2 class="c30"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 716.71px; height: 579.30px;"><img
                                                alt="" src="images/image77.png"
                                                style="width: 716.71px; height: 579.30px; margin-left: -160px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h2>
                        <h1 class="c97 c108"><span class="c3"></span></h1>
                        <h1 class="c97 c108"><span class="c3"></span></h1><a id="id.2xcytpi"></a><a id="id.1ci93xb"></a>
                </div>

                <!-- 56 -->
                <div data-num="56" class="numNUMBER page-mimi" id="container-pagnation56">
                        <h1 class="c97"><span class="c3">Обзор
                                        сервисов
                                        и&nbsp;инструментов</span>
                        </h1>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Организовать
                                        сквозную
                                        аналитику можно
                                        различными
                                        способами, далее
                                        представлены
                                        наиболее
                                        популярные
                                        сервисы
                                        и&nbsp;инструменты
                                        для этого.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8" id="h.jz8m9bb9aiyl"><span class="c0">Рассмотрим,
                                        какие данные
                                        можно собрать
                                        в&nbsp;единый
                                        механизм
                                        в&nbsp;рамках
                                        построения
                                        системы сквозной
                                        аналитики. Это
                                        будут как данные
                                        о&nbsp;продажах, так
                                        и&nbsp;другие
                                        показатели.
                                        В&nbsp;таблице
                                        приведены
                                        примеры типов
                                        систем, которые
                                        могут
                                        использоваться
                                        в&nbsp;компании,
                                        и&nbsp;примеры
                                        наиболее
                                        популярных их
                                        представителей.
                                        Соответственно,
                                        у&nbsp;каждой
                                        компании свой
                                        набор источников,
                                        и&nbsp;полное
                                        совпадение
                                        является очень
                                        редким.</span></p>
                        <p class="c5" id="h.12h0p1zh4smf"><span class="c0"></span></p>
                </div>

                <!-- 57 -->
                <div data-num="57" class="numNUMBER page-mimi" id="container-pagnation57">
                        <h3 class="c43 c59 c65" id="h.i2ky3x5mmxx5"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 612.00px; height: 750.00px;"><img
                                                alt="" src="images/image57.png"
                                                style="width: 612.00px; height: 750.00px; margin-left: -95px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h3><a id="id.2bn6wsx"></a><a id="id.3whwml4"></a>
                </div>

                <!-- 58 -->
                <div data-num="58" class="numNUMBER page-mimi" id="container-pagnation58">
                        <h2 class="c81 c65 c113"><span class="c22 c10">Типы
                                        сервисов
                                        и&nbsp;инструментов</span>
                        </h2>
                        <p class="c8"><span class="c0">Разделим
                                        представленные
                                        сервисы
                                        на&nbsp;3&nbsp;группы:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h3 class="c15" id="h.fm16zj9ulx0z"><span class="c11 c10">1.
                                        Недорогие
                                        сервисы «всё в 1»</span></h3>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Включают
                                        в&nbsp;себя базовую
                                        сквозную
                                        аналитику и
                                        другие
                                        инструменты для
                                        организации
                                        маркетинга и
                                        продаж, например:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_c115wjd1hbao-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">CRM-система</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Управление
                                                рекламой</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Лидогенерация</span>
                                </li>
                                <li class="c17 li-bullet-7"><span class="c0">Взаимодействия
                                                с&nbsp;соцсетями</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Создание
                                                landing&nbsp;page</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Виджеты
                                                на&nbsp;страницу,
                                                сайт
                                                (онлайн-консультант,
                                                обратный звонок
                                                и&nbsp;пр.)</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Автоворонки</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 59 -->
                <div data-num="59" class="numNUMBER page-mimi" id="container-pagnation59">
                        <p class="c8"><span class="c0">Типичные
                                        представители:</span></p>
                        <ul class="c9 lst-kix_cjx9fa3zwkr2-0 start">
                                <li class="c17 li-bullet-8"><span class="c0">LPTracker.ru</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Expecto.me</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">CarrotQuest.io</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">PrimeGate.io</span></li>
                        </ul>
                        <p class="c8"><span class="c4">Подходит для
                                        микробизнеса.
                                        Оплата сервиса </span><span class="c4">&nbsp;в&nbsp;районе </span><span
                                        class="c4">1тыс</span><span class="c4">. рублей
                                        в&nbsp;месяц.</span></p>
                        <h3 class="c15" id="h.8jhk81btw8j2"><span class="c11 c10">2. Сервисы
                                        сквозной
                                        аналитики</span></h3>
                        <p class="c8"><span class="c0">Специализированные
                                        сервисы, дающие
                                        более глубокую
                                        и&nbsp;качественную
                                        аналитику. Обычно
                                        интегрируются
                                        с&nbsp;CRM, системами
                                        веб-аналитики и
                                        колл-трекинга.
                                        Некоторые
                                        структуры
                                        выросли как раз
                                        из&nbsp;этих систем.</span></p>
                        <p class="c8"><span class="c0">Типичные
                                        представители:</span></p>
                        <ul class="c9 lst-kix_7tvp3vvpecia-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Roistat</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Alytics</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Comagic</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Calltouch</span></li>
                        </ul>
                        <p class="c8"><span class="c0">Подходит для
                                        малого и среднего
                                        бизнеса. Бюджет
                                        в&nbsp;районе 5-20 тыс.
                                        рублей в&nbsp;месяц.</span></p>
                        <h3 class="c15" id="h.ay9yg9k73dgq"><span class="c29">3.
                                        Кастомн</span><span>ы</span><span class="c29">е
                                        решени</span><span>я</span></h3>
                        <p class="c8"><span class="c4">Подходит для
                                        среднего
                                        и&nbsp;крупного
                                        бизнеса. Бюджет
                                        зависит от&nbsp;числа
                                        интегрируемых
                                        систем, объёма
                                        данных, типов </span><span class="c4">отчётов</span><span
                                        class="c0">&nbsp;и&nbsp;многих
                                        других
                                        параметров.</span></p>
                        <p class="c8"><span class="c0">Обычно
                                        аналитическая
                                        система
                                        состоит&nbsp;из&nbsp;таких
                                        компонентов,&nbsp;как:</span>
                        </p>
                        <ul class="c9 lst-kix_yvdh0uyt5svw-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Коннекторы
                                                сбора данных</span></li>
                                <li class="c17 li-bullet-7"><span class="c4">База для
                                                хранения
                                                и&nbsp;обработки
                                                данных (ETL, </span><span class="c4">DW</span><span class="c0">H)</span>
                                </li>
                                <li class="c17 li-bullet-7"><span class="c0">Аналитический
                                                модуль (отвечает
                                                за&nbsp;логику
                                                объединения
                                                данных на базе
                                                сквозных &nbsp;
                                                идентификаторов)</span>
                                </li>
                                <li class="c17 li-bullet-2"><span class="c4">Система
                                                визуализации
                                                данных (обычно, BI)
                                                с&nbsp;настроенными
                                        </span><span class="c4">отчётами</span></li>
                        </ul>
                        <p class="c8"><span class="c0">Коннекторы
                                        собирают данные
                                        из&nbsp;таких
                                        систем,&nbsp;как:</span></p>
                        <ul class="c9 lst-kix_c39pvpo5tfuo-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Рекламные
                                                каналы</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Сайт</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">CRM</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Телефония,
                                                почта, каналы
                                                коммуникаций
                                                (если эти данные
                                                не&nbsp;агрегированы
                                                в&nbsp;CRM)</span></li>
                        </ul>

                </div>

                <!-- 60 -->
                <div data-num="60" class="numNUMBER page-mimi" id="container-pagnation60">
                        <h2 class="c74 c65" id="h.jzzqw09d5h0o"><span class="c23">Для
                                        внедрения
                                        сквозной
                                        аналитики
                                        необходимы
                                        следующие
                                        инструменты</span><span class="c23">:</span></h2>
                        <h3 class="c15" id="h.qm6zn6z1qfvk"><span class="c11 c10">CRM</span></h3>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c0">Для
                                        интеграции
                                        подходит любая
                                        система, имеющая API
                                        и&nbsp;возможность
                                        настройки
                                        кастомных полей.</span>
                        </p>
                        <p class="c8"><span class="c0">Наиболее
                                        популярные в&nbsp;РФ:</span>
                        </p>
                        <ul class="c9 lst-kix_67ix1vos42jt-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Битрикс24</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">AmoCRM</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">RetailCRM</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Microsoft Dynamics
                                                (в&nbsp;крупных
                                                компаниях)</span></li>
                        </ul>
                        <p class="c8"><span class="c0">Наиболее
                                        популярные
                                        в&nbsp;мире:</span></p>
                        <ul class="c9 lst-kix_h1kaw5i3l8fw-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">SalesForce</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">MicroSoft Dynamics</span></li>
                        </ul>
                        <h3 class="c15" id="h.ntdugzx14nfv"><span class="c29">Сквозн</span><span>ые</span><span
                                        class="c11 c10">&nbsp;идентификаторы:</span>
                        </h3>
                        <p class="c5"><span class="c6"></span></p>
                        <p class="c8"><span class="c4">Обычно
                                        используется ClientID (Google
                                        Analytics), и&nbsp;в&nbsp;дополнение
                                        к&nbsp;нему можно
                                        взять другие </span><span class="c4">— </span><span class="c0">например, UserID
                                        Яндекс.Метрики, CoMagic,
                                        собственный
                                        идентификатор.</span></p>
                        <h3 class="c15" id="h.381b8vyc3r1f"><span class="c29">Баз</span><span>ы</span><span
                                        class="c11 c10">&nbsp;хранения
                                        и&nbsp;обработки
                                        данных:</span></h3>
                        <p class="c8"><span class="c0">Это может
                                        быть как облачное
                                        решение:</span></p>
                        <ul class="c9 lst-kix_hdta7izhzywf-0 start">
                                <li class="c17 li-bullet-2"><span class="c4">Google </span><span
                                                class="c0">BigQuery</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Microsoft Azure Cosmos&nbsp;DB</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Яндекс ClickHouse</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Amazon Redshift</span></li>
                        </ul>

                </div>

                <!-- 61 -->
                <div data-num="61" class="numNUMBER page-mimi" id="container-pagnation61">
                        <p class="c8"><span class="c0">Так и
                                        локальная база,
                                        развёрнутая
                                        на&nbsp;собственном
                                        сервере или тоже
                                        в&nbsp;облаке:</span></p>
                        <ul class="c9 lst-kix_63g0ebzbl034-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">MySQL</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">MSSQL</span></li>
                                <li class="c17 li-bullet-2"><span class="c4">PostgreSQL</span></li>
                        </ul>
                        <h3 class="c15" id="h.f61l9n2x24wx"><span class="c11 c10">Коннекторы:</span></h3>
                        <ul class="c9 lst-kix_rk9zx1n16z-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">Коннекторы
                                                собственной
                                                разработки;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Публичные
                                                коннекторы
                                                систем
                                                и&nbsp;сторонних
                                                разработчиков
                                                (например, для Google Analytics,
                                                Google Data Studio, Microsoft Power BI,
                                                существует
                                                множество
                                                бесплатных
                                                коннекторов
                                                к&nbsp;различным
                                                системам);</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Сервисы
                                                коннекторов
                                                данных,
                                                например:</span></li>
                        </ul>
                        <p class="c8"><span class="c0">— OWOX BI Pipeline</span></p>
                        <p class="c8"><span class="c0">— Albato.ru</span></p>
                        <p class="c8"><span class="c0">— apix-drive.com</span></p>
                        <p class="c8"><span class="c0">— supermetrics.com.</span></p>
                        <h3 class="c15" id="h.h3iakqkfszmh"><span class="c29">Систем</span><span>ы</span><span
                                        class="c11 c10">&nbsp;визуализации:</span>
                        </h3>
                        <ul class="c9 lst-kix_4ctmcdb3dciz-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">BI-системы,
                                                такие&nbsp;как:</span></li>
                        </ul>
                        <p class="c8"><span class="c0">— Google Data Studio</span></p>
                        <p class="c8"><span class="c0">— Microsoft Power&nbsp;BI</span></p>
                        <p class="c8"><span class="c4">— </span><span class="c4">Qlik</span><span class="c0">&nbsp;Sense
                                        /&nbsp;View</span></p>
                        <p class="c8"><span class="c0">— Tableau</span></p>
                        <ul class="c9 lst-kix_xhmfanlcikoc-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Дашборды,
                                                построенные
                                                на&nbsp;базе
                                                публичных
                                                сервисов</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Кастомные
                                                дашборды
                                                &nbsp;—например, на&nbsp;D3.js</span>
                                </li>
                        </ul>
                        <h3 class="c15" id="h.zam2s0mctkp0"><span class="c11 c10">Другие
                                        системы:</span></h3>
                        <p class="c5"><span class="c6"></span></p>
                        <ul class="c9 lst-kix_9ziltu18h8nt-0 start">
                                <li class="c17 li-bullet-7"><span class="c4">Системы
                                                автоматизации
                                                контекстной
                                                рекламы
                                                и&nbsp;управления
                                                ставками
                                                (например, Origami, Alytics, K50, </span><span
                                                class="c4">Marilyn</span><span class="c0">);</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">ERP, системы
                                                управления
                                                складом.</span></li>
                        </ul>
                </div>

                <!-- 62 -->
                <div data-num="62" class="numNUMBER page-mimi" id="container-pagnation62">
                        <p class="c8"><span class="c0">Интересно,
                                        что в&nbsp;английском
                                        языке нет общего
                                        термина для
                                        сквозной
                                        аналитики. Среди
                                        зарубежных
                                        систем принципы
                                        используются
                                        те&nbsp;же самые,
                                        но&nbsp;на&nbsp;термине
                                        никто
                                        не&nbsp;зацикливается.
                                        Есть business analytics, business intelligence, ROMI analytics, LTV analytics.
                                        Существуют также
                                        end-to-end analytics и&nbsp;cross-cutting analytics, но
                                        упоминаются
                                        редко. Наверное,
                                        там всем понятно,
                                        что аналитика
                                        должна быть
                                        сквозной
                                        по&nbsp;определению.</span>
                        </p>
                        <p class="c8"><span class="c4">Далее
                                        рассмотрим самые
                                        интересные
                                        из&nbsp;перечисленных
                                        в начале главы
                                        сервисов более
                                        подробно.</span></p>
                        <hr style="page-break-before:always;display:none;">
                </div>

                <!-- 63 -->
                <div data-num="63" class="numNUMBER page-mimi" id="container-pagnation63">
                        <h4 class="c27 c54" id="h.rw8psatgnkvm"><span class="c0"></span></h4>
                        <h4 class="c27 c54" id="h.uhglzd6bki84"><span class="c6"></span></h4><a id="id.qsh70q"></a><a
                                id="id.3as4poj"></a>
                        <h4 class="c27" id="h.27zs8zxeu91a"><span class="c6">1.
                                        Недорогие
                                        сервисы «всё в&nbsp;1»</span>
                        </h4>
                        <p class="c75 c54"><span class="c0"></span></p><a id="id.1pxezwc"></a>
                        <h5 class="c12" id="h.axg1nu2edka"><span class="c6">Lptracker</span></h5>
                        <p class="c8"><span class="c4">Система&nbsp;</span><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=http://land.lptracker.ru/?ref%3D33309&amp;sa=D&amp;source=editors&amp;ust=1614119598488000&amp;usg=AOvVaw15xqN3rvnDqDn_tO_UrWqM">LPTracker</a></span><span
                                        class="c0">&nbsp;сочетает
                                        в&nbsp;себе:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_k6g3hu5e4cbq-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Конструктор
                                                сайтов</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Простую&nbsp;CRM</span>
                                </li>
                                <li class="c17 li-bullet-7"><span class="c0">Аналитику
                                                рекламы</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Колл-трекинг</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Виртуальную&nbsp;АТС</span>
                                </li>
                                <li class="c17 li-bullet-7"><span class="c0">Callback</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Сервис
                                                захвата
                                                посетителей</span></li>
                        </ul>
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 718.52px; height: 422.50px;"><img
                                                alt="" src="images/image55.png"
                                                style="width: 718.52px; height: 422.50px; margin-left: -125px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c4">Cервис</span><span class="c4">&nbsp;является
                                        одним из&nbsp;самых
                                        популярных
                                        у&nbsp;малого бизнеса
                                        в</span><span class="c0">&nbsp;плане «всё
                                        в&nbsp;одном» (цена за
                                        использование
                                        составляет 900/3000р
                                        в&nbsp;месяц). </span></p>
                        <p class="c43 c54"><span class="c0"></span></p><a id="id.49x2ik5"></a>
                </div>

                <!-- 64 -->
                <div data-num="64" class="numNUMBER page-mimi" id="container-pagnation64">
                        <h5 class="c12" id="h.31qiqrn2g120"><span class="c6">PrimeGate.io</span></h5>
                        <p class="c43"><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 226.67px;"><img
                                                alt="59e53d1cdcff638b31b24de2.jpg" src="images/image39.jpg"
                                                style="width: 566.67px; height: 226.67px; margin-left: -50px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=http://primegate.io/?utm_source%3Dhabrhabr%26utm_medium%3Dcpc%26utm_campaign%3Dmushtuk%26utm_term%3Dpost1&amp;sa=D&amp;source=editors&amp;ust=1614119598490000&amp;usg=AOvVaw34OQt3zGVPr0WL_6D-JM6t">PrimeGate.io</a></span><span
                                        class="c4">&nbsp;— сервис
                                        сквозной
                                        аналитики. Начал
                                        работу в&nbsp;2013&nbsp;как
                                        система
                                        управления
                                        контекстной
                                        рекламой PrimeContext
                                        (биддер). В&nbsp;2014-м
                                        запущен </span><span class="c4">коллтрекинг</span><span
                                        class="c4">&nbsp;(динамический
                                        и&nbsp;статический),
                                        который сейчас
                                        является сильной
                                        стороной сервиса.
                                        Имеется своя CRM.
                                        Сервис
                                        предлагает всё
                                        под ключ:
                                        телефония, </span><span class="c4">коллтрекинг</span><span class="c4">, CRM,
                                        обратный
                                        звонок. Аналитика
                                        содержит сводные
                                </span><span class="c4">отчёты</span><span class="c0">&nbsp;по&nbsp;рекламным
                                        кампаниям,
                                        ключевым
                                        запросам,
                                        UTM-меткам.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Плюсы:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_dyj45s1do2b0-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">Всё
                                                в&nbsp;одном месте
                                                и&nbsp;интегрировано
                                                между собой;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Своя CRM
                                                (простая
                                                и&nbsp;удобная,
                                                похожа на&nbsp;PipeDrive
                                                или&nbsp;Amo);</span></li>
                                <li class="c17 li-bullet-2"><span class="c4">Качество
                                        </span><span class="c4">коллтрекинг</span><span class="c0">а (упор
                                                на&nbsp;алгоритмы);</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Сами
                                                являются
                                                оператором
                                                мобильной связи
                                                (предоставляют FMC
                                                сим-карты);</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Для
                                                отслеживания
                                                звонков
                                                по&nbsp;кампаниям
                                                в&nbsp;Яндексе
                                                не&nbsp;нужны UTM-метки;</span>
                                </li>
                                <li class="c17 li-bullet-2"><span class="c0">Свой
                                                прозвонщик
                                                номеров, который
                                                определяет
                                                доступность
                                                телефонного
                                                номера.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Резюме:</span><span class="c4">&nbsp;</span><span
                                        class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://primegate.io/?pq%3DMTUxNzAwODE5MDA0&amp;sa=D&amp;source=editors&amp;ust=1614119598492000&amp;usg=AOvVaw3m6bHAHFMurJFKvr9Jc-Eo">Сервис
                                                PrimeGate.io</a></span><span class="c0">&nbsp;подойдёт
                                        компаниям
                                        с&nbsp;большим %
                                        звонков в&nbsp;общем
                                        числе обращений
                                        и&nbsp;небольшим
                                        числом
                                        менеджеров, а
                                        также всем
                                        желающим
                                        внедрить простую
                                        CRM и&nbsp;сквозную
                                        аналитику без
                                        сложных
                                        интеграций.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 65 -->
                <div data-num="65" class="numNUMBER page-mimi" id="container-pagnation65">
                        <p class="c8"><span class="c4">В&nbsp;2018-м году
                                        система сквозной
                                        аналитики&nbsp;</span><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://primegate.io/?pq%3DMTUxNzAwODE5MDA0&amp;sa=D&amp;source=editors&amp;ust=1614119598493000&amp;usg=AOvVaw28tDFJdjM9-f6R6lpo4IB-">PrimeGate</a></span><span
                                        class="c0">&nbsp;представила
                                        конкурентные
                                        тарифы
                                        от&nbsp;1296&nbsp;рублей
                                        в&nbsp;месяц. Для
                                        малого бизнеса,
                                        который тратит
                                        на&nbsp;рекламу
                                        10—30&nbsp;тыс. в&nbsp;месяц,
                                        решение может
                                        быть очень кстати,
                                        т.к. подписка на&nbsp;Roistat
                                        на&nbsp;таких
                                        бюджетах рискует
                                        не&nbsp;окупиться.</span></p><a id="id.2p2csry"></a>
                        <h5 class="c12" id="h.7sbjfc42svdw"><span class="c6">Expecto.me</span></h5>
                        <p class="c8"><span class="c4">Новый сервис
                                </span><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://expecto.me/&amp;sa=D&amp;source=editors&amp;ust=1614119598494000&amp;usg=AOvVaw32P3T5wr-lUANDNpov5hCH">expecto.me</a></span><span
                                        class="c0">, где обещают, что
                                        всё будет просто,
                                        красиво
                                        и&nbsp;недорого.
                                        Использовать его
                                        в качестве
                                        рабочего решения
                                        пока рановато,
                                        но&nbsp;следить
                                        за&nbsp;развитием
                                        стоит, т.к.
                                        присутствуют:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_2jrhyakpi2fn-0 start">
                                <li class="c17 li-bullet-7"><span class="c4">Свой </span><span
                                                class="c4">коллтрекинг</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Своя&nbsp;CRM</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Простота
                                                настройки</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Система также
                                        развивается
                                        и&nbsp;выглядит
                                        вполне
                                        работоспособной.
                                </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 718.49px; height: 334.50px;"><img
                                                alt=""
                                                src="images/image44.png"
                                                style="width: 718.49px; height: 334.50px; margin-left: -130px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c14"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c43 c54"><span class="c0"></span></p>
                </div>

                <!-- 66 -->
                <div data-num="66" class="numNUMBER page-mimi" id="container-pagnation66">
                        <hr style="page-break-before:always;display:none;"><a id="id.147n2zr"></a><a
                                id="id.3o7alnk"></a>
                        <h4 class="c27" id="h.wqwqw31u45b6"><span class="c6">2. Сервисы
                                        сквозной
                                        аналитики</span></h4><a id="id.23ckvvd"></a>
                        <h5 class="c12" id="h.art5g8daria4"><span class="c6">Roistat</span></h5>
                        <p class="c43"><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 226.67px;"><img
                                                alt="59e53d20dcff638b31b24de8.jpg"
                                                src="images/image34.jpg"
                                                style="width: 566.67px; height: 226.67px; margin-left: -50px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=http://roistat.com/r/zdmn2wog&amp;sa=D&amp;source=editors&amp;ust=1614119598495000&amp;usg=AOvVaw3Fjt6K9Fpt4C1Kw89h-Gyg">R</a></span><span
                                        class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=http://roistat.com/r/zdmn2wog&amp;sa=D&amp;source=editors&amp;ust=1614119598496000&amp;usg=AOvVaw2GDVgO1qOYMzVM3R3TW7Fi">oistat</a></span><span
                                        class="c4">&nbsp;— система
                                        сквозной
                                        аналитики,
                                        позволяющая
                                        подключить
                                        множество
                                        различных
                                        рекламных
                                        источников
                                        с&nbsp;одной стороны
                                        и&nbsp;CRM-систем
                                        с&nbsp;другой.
                                        Показывает ROI
                                        по&nbsp;каналам,
                                        а&nbsp;также имеет
                                        собственный </span><span class="c4">коллтрекинг</span><span class="c0">, ловец
                                        лидов,
                                        работу для
                                        управления
                                        ставками,
                                        мультиканальную
                                        аналитику
                                        и&nbsp;другие
                                        возможности.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Минусы</span><span class="c4 c20 c48 c38 c29">:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_wnt4yuipugp-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Стоимость
                                                невелика, но
                                                отсекаются
                                                совсем уж
                                                микробизнесы;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">При отказе
                                                от&nbsp;системы
                                                выгрузка данных
                                                неполная, только
                                                в&nbsp;XLS;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Внутренние
                                                алгоритмы не
                                                всегда
                                                прозрачны.
                                                система
                                                работает по
                                                принципу
                                                чёрного ящика, и
                                                её данные не
                                                всегда
                                                согласуются с CRM</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Качество
                                                встроенного
                                                коллтрекинга
                                                ниже популярных
                                                специализированных
                                                решений.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Казалось&nbsp;бы,
                                        минусы
                                        существенны.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 67 -->
                <div data-num="67" class="numNUMBER page-mimi" id="container-pagnation67">
                        <p class="c8"><span class="c4 c20 c48 c38 c29">Но&nbsp;плюсов
                                        больше:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_hltp2c4oyeu-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Предлагает
                                                нужные отчёты
                                                (по&nbsp;ROI) без
                                                дополнительных
                                                настроек;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Свой робот
                                                для управления
                                                ставками;
                                                позволяет
                                                менять их
                                                на&nbsp;основе&nbsp;ROI;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Содержит
                                                свой сервис
                                                коллтрекинга;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Есть
                                                мультиканальная
                                                аналитика;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Есть свой
                                                сервис
                                                A/B-тестирования;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Относительно
                                                легко
                                                интегрируется
                                                с&nbsp;популярными CRM;</span>
                                </li>
                                <li class="c17 li-bullet-2"><span class="c0">Легко
                                                интегрируется
                                                с&nbsp;рекламными
                                                каналами;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Есть
                                                email-трекер.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48">Резюме:</span><span class="c0">&nbsp;простая в
                                        настройке
                                        система,
                                        закрывающая
                                        большую часть
                                        потребностей
                                        малого бизнеса. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Сервис&nbsp;</span><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=http://roistat.com/r/zdmn2wog&amp;sa=D&amp;source=editors&amp;ust=1614119598498000&amp;usg=AOvVaw0H7FaZeZY-iV38KJAbzkOJ">Roistat</a></span><span
                                        class="c0">&nbsp;сохраняет
                                        лидирующие
                                        позиции на&nbsp;рынке
                                        систем сквозной
                                        аналитики для
                                        малого
                                        и&nbsp;среднего
                                        бизнеса и активно
                                        развивается.</span><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 192.00px;"><img
                                                alt="59e53ce8dcff638b31b24dac.jpg"
                                                src="images/image17.jpg"
                                                style="width: 566.67px; height: 192.00px; margin-left: -30px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c0">Подарок
                                        внимательным
                                        читателям! </span></p>
                        <p class="c8"><span class="c73">Купон для
                                        новых клиентов
                                        на</span><span class="c4">&nbsp;</span><span class="c73">5000р:
                                        media-targeting</span></p>
                        <a id="id.ihv636"></a>
                </div>

                <!-- 68 -->
                <div data-num="68" class="numNUMBER page-mimi" id="container-pagnation68">
                        <h5 class="c12" id="h.62hr0moh5dxz"><span class="c6">Alytics </span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://alytics.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598499000&amp;usg=AOvVaw1zmiB7bQfPLANXriDN_w_8">alytics.ru</a></span>
                        </h3>
                        <p class="c62 c81"><span
                                        style="overflow: hidden; display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 446.50px; height: 162.43px;"><img
                                                alt=""
                                                src="images/image19.png"
                                                style="width: 446.50px; height: 162.43px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c0">Система,
                                        первоначально
                                        созданная для
                                        управления
                                        контекстной
                                        рекламой, позднее
                                        превратилась
                                        в&nbsp;полноценную
                                        систему сквозной
                                        аналитики.</span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 404.00px;"><img
                                                alt="5c2345011f25060700951af5.jpg"
                                                src="images/image52.jpg"
                                                style="width: 566.67px; height: 404.00px; margin-left: -75px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c43 c54"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Использует
                                        в&nbsp;качестве
                                        сквозного
                                        идентификатора Google
                                        ID, что можно
                                        считать
                                        преимуществом
                                        перед другими
                                        системами.</span></p><a id="id.32hioqz"></a>
                </div>

                <!-- 69 -->
                <div data-num="69" class="numNUMBER page-mimi" id="container-pagnation69">
                        <h5 class="c12" id="h.lkebq064yd8v"><span class="c6">Calltouch</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://www.calltouch.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598500000&amp;usg=AOvVaw23e4hfSCqQOpicKUGe4l-J">calltouch.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c4">Система
                                        сквозной
                                        аналитики</span><span class="c4">,
                                        коллтрекинга и
                                        управления
                                        рекламой, </span><span class="c4">Calltouch</span><span class="c4">, как
                                        и&nbsp;многие
                                        другие, выросла
                                        из&nbsp;системы
                                        коллтрекинга.
                                        Система является
                                        одним из пионеров
                                        рынка, но
                                        продолжает
                                        быстро
                                        развиваться.
                                        Преимуществом
                                        можно считать
                                        высокую точность
                                </span><span class="c4">коллтрекинга</span><span class="c4">.</span><span
                                        class="c4">&nbsp;Компания
                                        заявляет о
                                        точности
                                        определения
                                        источника в 96%
                                        &nbsp;Имеются отчёты
                                        по отдельным
                                        рекламным
                                        системам —
                                        например, по
                                        Яндекс.Директ. </span><span class="c4">Отчёт</span><span
                                        class="c0">&nbsp;показывает
                                        все заявки
                                        из&nbsp;данного
                                        источника и
                                        позволяет
                                        выделить
                                        эффективные и
                                        неэффективные
                                        рекламные
                                        объявления.
                                        Добавлена
                                        мультиканальная
                                        аналитика.
                                        которой ранее не
                                        хватало. &nbsp;В
                                        сентябре 2020 стало
                                        известно о
                                        покупке компании
                                        оператором
                                        “Манго Телеком”.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 683.17px; height: 362.50px;"><img
                                                alt=""
                                                src="images/image13.png"
                                                style="width: 683.17px; height: 362.50px; margin-left: -75px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="id.1hmsyys"></a>
                </div>

                <!-- 70 -->
                <div data-num="70" class="numNUMBER page-mimi" id="container-pagnation70">
                        <h5 class="c12" id="h.1m0qoz6vsk0y"><span class="c4">Comagic</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://www.comagic.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598501000&amp;usg=AOvVaw2uORYWI8gs4Z0EetU2duQu">comagic.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Comagic является
                                        третьей наиболее
                                        известной
                                        системой
                                        коллтрекинга
                                        на&nbsp;российском
                                        рынке. Имеет свою
                                        систему
                                        аналитики. CRM
                                        подключаются
                                        через&nbsp;API. Умеет
                                        считать&nbsp;ROI. Есть
                                        онлайн-чат
                                        и&nbsp;обратный
                                        звонок.
                                        Мультиканальной
                                        аналитики&nbsp;нет.
                                        Опционально
                                        можно подключить
                                        сторонний сервис
                                        для управления
                                        контекстной
                                        рекламой &nbsp;—
                                        например, Alytics.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4 c20 c48 c38 c29">За&nbsp;последний&nbsp;год:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_efx5qw7elzt1-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">Разработали
                                                гибкий
                                                функционал
                                                по&nbsp;правам
                                                доступа;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Реализовали
                                                функционал
                                                кастомизированных
                                                отчетов
                                                по&nbsp;любому
                                                из&nbsp;40&nbsp;измерений
                                                на&nbsp;базе отчета
                                                «Анализ
                                                трафика»;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Доработали
                                                схему
                                                определения
                                                первых
                                                качественных
                                                обращений
                                                по&nbsp;каждому их
                                                типу;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">В&nbsp;Яндекс.Метрику
                                                стали
                                                передавать
                                                звонки, чаты,
                                                заявки, цели;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Передача
                                                данных
                                                по&nbsp;графическим
                                                объявлениям
                                                из&nbsp;Яндекс.Директ;
                                                отслеживание
                                                адаптивных
                                                и&nbsp;расширенных
                                                динамических
                                                объявлений Google Ads;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Автоматическое
                                                создание
                                                карточек
                                                «Задачи»,
                                                «Сделки»,
                                                «Контакты»,
                                                «Лиды»
                                                на&nbsp;входящие или
                                                пропущенные
                                                звонки и&nbsp;другие
                                                события;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Синхронизация
                                                в&nbsp;CoMagic и&nbsp;CRM
                                                сотрудников,
                                                клиентов,
                                                звонков, чатов,
                                                заявок, сделок;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Интеграция
                                                с&nbsp;Power&nbsp;BI.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c74"><span class="c0">Система
                                        популярна &nbsp;—
                                        например, у
                                        компаний,
                                        работающих в
                                        сфере
                                        недвижимости.</span><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 269.33px;"><img
                                                alt="59e53ccedcff638b31b24d88.jpg"
                                                src="images/image32.jpg"
                                                style="width: 566.67px; height: 269.33px; margin-left: -50px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="id.41mghml"></a>
                </div>

                <!-- 71 -->
                <div data-num="71" class="numNUMBER page-mimi" id="container-pagnation71">
                        <h5 class="c12" id="h.eebtlllouohg"><span class="c6">K50</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://k50.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598503000&amp;usg=AOvVaw2AJs0hYuKlsHY2XwSiMIf1">k50.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Содержит
                                        сервисы для
                                        создания
                                        и&nbsp;управления
                                        контекстной
                                        рекламой
                                        и&nbsp;аналитики:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_ned3zzpdztlc-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">K50:
                                                Статистика</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">K50: Трекер</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">K50:
                                                Генератор</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">K50: Правила</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">K50:
                                                Оптимизатор</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">K50:&nbsp;BI</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Callback</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Сквозная
                                                аналитика</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">K50 </span><span class="c4">остаётся</span><span
                                        class="c0">&nbsp;ведущим
                                        игроком на&nbsp;рынке,
                                        предоставляя
                                        систему
                                        генерации
                                        контекстной
                                        рекламы,
                                        управления
                                        ставками
                                        и,&nbsp;конечно,
                                        сквозную
                                        аналитику
                                        и&nbsp;BI-систему.
                                        Статистика
                                        собирает данные, а
                                        K50 BI их
                                        визуализирует.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c43"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 297.33px;"><img
                                                alt="59e53cd5dcff638b31b24d91.jpg"
                                                src="images/image74.jpg"
                                                style="width: 566.67px; height: 297.33px; margin-left: -50px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c74"><span class="c4">В октябре 2020
                                        стало известно о
                                        покупке сервиса
                                        компанией Яндекс.
                                </span></p><a id="id.2grqrue"></a>
                </div>

                <!-- 72 -->
                <div data-num="72" class="numNUMBER page-mimi" id="container-pagnation72">
                        <h5 class="c12" id="h.orkzc5crjx8h"><span class="c6">Kissmetrics</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://www.kissmetricshq.com/&amp;sa=D&amp;source=editors&amp;ust=1614119598506000&amp;usg=AOvVaw35caDvIUnMaJmgw3sIrgM4">kissmetricshq.com</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Популярная
                                        зарубежная
                                        система
                                        аналитики. Имеет
                                        массу
                                        возможностей
                                        и&nbsp;очень мощный
                                        инструментарий.
                                        Из&nbsp;недостатков
                                        стоит отметить
                                        сложность
                                        настройки
                                        и&nbsp;высокую цену.</span></p>
                        <p class="c5"><span class="c0"></span></p><a id="id.3fwokq0"></a>
                        <h5 class="c12" id="h.wau2t82z10i5"><span class="c6">Mango telecom</span><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 280.00px;"><img
                                                alt="5d21b475a280b100075b1bc0.jpg"
                                                src="images/image68.jpg"
                                                style="width: 566.67px; height: 280.00px; margin-left: -75px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://www.mango-office.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598506000&amp;usg=AOvVaw3bVMu7VAPQyx1TOHFyL_sT">mango-office.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Крупная
                                        телеком-компания,
                                        являющаяся одним
                                        из&nbsp;лидеров рынка
                                        IP-телефонии,
                                        не&nbsp;могла
                                        остаться
                                        в&nbsp;стороне
                                        от&nbsp;темы сквозной
                                        аналитики.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Только
                                        за&nbsp;последнее
                                        время компания
                                        запустила:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_9nheg9m4ww4f-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Собственный
                                                сервис
                                                коллтрекинга</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Сервис
                                                бизнес-аналитики</span>
                                </li>
                                <li class="c17 li-bullet-7"><span class="c0">Интеграцию
                                                своей телефонии c
                                                Roistat</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Если
                                        вспомнить, что
                                        у&nbsp;них есть своя CRM,
                                        а&nbsp;телефония
                                        является одной
                                        из&nbsp;лидирующих
                                        на&nbsp;рынке, стоит
                                        присмотреться
                                        к&nbsp;этим сервисам
                                        повнимательнее.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 73 -->
                <div data-num="73" class="numNUMBER page-mimi" id="container-pagnation73">
                        <p class="c43"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 373.33px;"><img
                                                alt="59e53cccdcff638b31b24d85.jpg"
                                                src="images/image46.jpg"
                                                style="width: 566.67px; height: 373.33px; margin-left: -50px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="id.1v1yuxt"></a>
                        <h5 class="c12" id="h.iwf7604ev7ah"><span class="c6">Sef </span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://sef.com.ua/&amp;sa=D&amp;source=editors&amp;ust=1614119598508000&amp;usg=AOvVaw0CXOHurR_4NJuKYsS92LvV">sef.com.ua</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Украинский
                                        облачный сервис
                                        сквозной
                                        аналитики для
                                        любого типа
                                        бизнеса.
                                        Позволяет весьма
                                        эффективно
                                        отслеживать
                                        продуктивность
                                        запущенных
                                        рекламных
                                        кампаний
                                        и&nbsp;маркетинговой
                                        стратегии
                                        в&nbsp;целом. Как
                                        следствие,
                                        детальные
                                        аналитические
                                        данные позволяют
                                        перераспределить
                                        ресурсы
                                        с&nbsp;малоэффективных
                                        каналов на&nbsp;более
                                        результативные.
                                        Повышение
                                        рентабельности
                                        воронки продаж
                                        обеспечивается
                                        следующими
                                        факторами:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_yi6r305d6whb-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Выявление
                                                потерь
                                                потенциальной
                                                дополнительной
                                                прибыли;</span></li>
                                <li class="c17 li-bullet-7"><span class="c4">Отсечение
                                        </span><span class="c4">малодоходных</span><span class="c0">&nbsp;рекламных
                                                каналов или
                                                уменьшение
                                                соответствующих
                                                статей
                                                расходов;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Эффективное
                                                перераспределение
                                                рекламного
                                                бюджета;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Вывод
                                                конверсии
                                                на&nbsp;требуемый
                                                уровень;</span></li>
                                <li class="c17 li-bullet-2"><span class="c4">Расчёт</span><span
                                                class="c0">&nbsp;и&nbsp;реализация
                                                краткосрочных
                                                и&nbsp;долгосрочных
                                                стратегий
                                                доходности.</span></li>
                        </ul>
                </div>

                <!-- 74 -->
                <div data-num="74" class="numNUMBER page-mimi" id="container-pagnation74">
                        <p class="c57"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 322.67px;"><img
                                                alt="5d5b0a9ba48f540006ae10d9.jpg"
                                                src="images/image1.jpg"
                                                style="width: 566.67px; height: 322.67px; margin-left: -75px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="id.4f1mdlm"></a>
                        <h5 class="c12" id="h.57g73ove216r"><span class="c6">Elly</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.elly.pro/&amp;sa=D&amp;source=editors&amp;ust=1614119598510000&amp;usg=AOvVaw2oyJ99jUOAjJrTpnBTCcCM">ru.elly.pro</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Отечественный
                                        сервис сквозной
                                        аналитики
                                        от&nbsp;российской
                                        компании IT-Agency,
                                        успешно
                                        представленной
                                        на&nbsp;рынке уже
                                        более 8&nbsp;лет.
                                        Продукт призван
                                        сделать
                                        инвестиции
                                        в&nbsp;маркетинг
                                        более
                                        эффективными,
                                        расходы
                                        сократить,
                                        а&nbsp;продажи
                                        увеличить.
                                        Интересно, что Elly
                                        помогает
                                        оптимизировать
                                        деятельность
                                        бизнеса любой
                                        сферы, будь то
                                        финансовая,
                                        строительная
                                        область или даже
                                        развлекательное
                                        мобильное
                                        приложение.
                                        Процесс
                                        интеграции
                                        выглядит
                                        следующим
                                        образом:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_pziu23x7ls6h-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Демонстрация
                                                возможностей
                                                сервиса
                                                и&nbsp;освещение
                                                типичных
                                                проблемных
                                                мест;</span></li>
                                <li class="c17 li-bullet-7"><span class="c4">Составление
                                                проекта и&nbsp;сбор
                                                всей
                                                необходимой
                                                информации с&nbsp;</span><span class="c4">учётом</span><span
                                                class="c0">&nbsp;особенностей
                                                компании;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Налаживание
                                                сбора
                                                аналитических
                                                данных со&nbsp;всех
                                                ключевых
                                                источников,
                                                включая целевой
                                                сайт, приложения,
                                                CRM и&nbsp;т.д.;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Запуск
                                                сервиса,
                                                регулярная
                                                отчётность
                                                с&nbsp;аналитической
                                                поддержкой.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Продукт
                                        доступен
                                        по&nbsp;подписке,
                                        и&nbsp;его стоимость
                                        начинается
                                        от&nbsp;80&nbsp;000&nbsp;р./мес.
                                        По&nbsp;заявлениям
                                        авторов,
                                        окупаемость
                                        затрат
                                        происходит
                                        за&nbsp;3&nbsp;мес. при
                                        рекламном
                                        бюджете
                                        от&nbsp;1&nbsp;млн.&nbsp;руб.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 75 -->
                <div data-num="75" class="numNUMBER page-mimi" id="container-pagnation75">
                        <p class="c43"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 474.67px;"><img
                                                alt="5d5b0d9fad7e130007c70dfa.jpg"
                                                src="images/image14.jpg"
                                                style="width: 566.67px; height: 474.67px; margin-left: -50px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="kix.dz15hteo0iup"></a>
                        <h5 class="c85 c59" id="h.klpw2aid4fyc"><span class="c6">Smalldata</span></h5>
                        <h3 class="c28" id="h.ckgrtyocitp"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://cvetkov.org/&amp;sa=D&amp;source=editors&amp;ust=1614119598511000&amp;usg=AOvVaw0KRbUDkN1o1gVajeiDzaI_">cvetkov.org</a></span>
                        </h3>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Система
                                        сквозной
                                        аналитики от
                                        проекта&nbsp;«Бизнес-Молодость».
                                        В&nbsp;качестве
                                        системы
                                        визуализации
                                        используется Microsoft Power BI.
                                        Основной упор
                                        сделан на&nbsp;оценку
                                        работы
                                        менеджеров и
                                        оптимизацию
                                        процессов отдела
                                        продаж, в
                                        результате чего
                                        эффективность
                                        последнего
                                        значительно
                                        повышается.
                                        Авторы
                                        гарантируют
                                        увеличение
                                        оборота на треть в
                                        первые три месяца
                                        использования
                                        системы.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 76 -->
                <div data-num="76" class="numNUMBER page-mimi" id="container-pagnation76">
                        <p class="c8"><span class="c0">Временные
                                        затраты на
                                        рутинные
                                        операции могут
                                        быть уменьшены, в
                                        среднем, в три
                                        раза, а контроль
                                        расходов
                                        полностью
                                        автоматизируется.
                                        Специалисты
                                        компании
                                        проводят полное
                                        обучение
                                        сотрудников
                                        клиентских
                                        организаций, что
                                        обеспечивает
                                        максимальную
                                        отдачу от их
                                        рабочей
                                        деятельности.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Стоимость
                                        услуг платформы
                                        начинается
                                        от&nbsp;75&nbsp;тыс.&nbsp;руб.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 496.00px;"><img
                                                alt="5d87debadced830007d1b2ac.jpg"
                                                src="images/image79.jpg"
                                                style="width: 566.67px; height: 496.00px; margin-left: -50px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="id.19c6y18"></a>
                </div>

                <!-- 77 -->
                <div data-num="77" class="numNUMBER page-mimi" id="container-pagnation77">
                        <h5 class="c12" id="h.9j4bvr1c70bg"><span class="c4">Analyticsgroup</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://analyticsgroup.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598512000&amp;usg=AOvVaw21Bl7pk6tWy8zwHFDwT3vw">analyticsgroup.ru</a></span>
                        </h3>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Автоматизированное
                                        аналитическое
                                        решение на&nbsp;базе
                                </span><span class="c4">QlikSense</span><span class="c0">,
                                        предназначенное
                                        для анализа рынка,
                                        оценки
                                        возможностей и
                                        планирования
                                        затрат/эффективности
                                        рекламных
                                        кампаний. Система
                                        обладает
                                        широкими
                                        возможностями
                                        кластеризации и
                                        сегментирования
                                        клиентской базы, а
                                        также позволяет
                                        управлять
                                        разработкой и
                                        жизненным циклом
                                        продукта (PLM).</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 318.67px;"><img
                                                alt="59e53cc9dcff638b31b24d7f.jpg"
                                                src="images/image43.jpg"
                                                style="width: 566.67px; height: 318.67px; margin-left: -60px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">AnalyticsGroup</span><span class="c0">&nbsp;эффективно
                                        прогнозирует
                                        продажи по
                                        отдельным
                                        группам на основе
                                        уже имеющихся
                                        данных. По
                                        утверждению
                                        авторов системы,
                                        автоматизация
                                        сбора и
                                        визуализация
                                        бизнес-данных
                                        позволяет
                                        находить новые
                                        точки роста,
                                        определять ROI и
                                        добиваться
                                        максимальных
                                        результатов.</span></p><a id="id.3tbugp1"></a>
                </div>

                <!-- 78 -->
                <div data-num="78" class="numNUMBER page-mimi" id="container-pagnation78">
                        <h5 class="c12" id="h.1bjqmej1ugo4"><span class="c6">Segmentstream</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://segmentstream.com/ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598513000&amp;usg=AOvVaw0ZmhLKa_zU1Dp7qJ8zN1HE">segmentstream.com/ru</a></span>
                        </h3>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Небольшой
                                        белорусский
                                        стартап
                                        за&nbsp;несколько лет
                                        перерос
                                        в&nbsp;обширную
                                        платформу
                                        управления
                                        маркетинговой
                                        инфраструктурой,
                                        которая
                                        занимается
                                        сбором,
                                        обработкой
                                        и&nbsp;анализом
                                        большого
                                        количества
                                        информации. </span><span class="c4">Чёткая</span><span
                                        class="c4">&nbsp;и&nbsp;выверенная
                                        организация
                                        учёта данных
                                        осуществляется
                                        на&nbsp;базе
                                        облачного
                                        хранилища Google BigQuery.
                                        Бизнес-пользователю
                                        или IT-специалисту
                                        больше не&nbsp;нужно
                                        заниматься
                                        ручным импортом
                                        данных
                                        из&nbsp;различных
                                        источников, так
                                        как всё это за&nbsp;них
                                        делает платформа
                                </span><span class="c4">SegmentStream</span><span class="c0">. Итак,
                                        сервис
                                        позволяет:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_ub21e5rjl67t-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Более
                                                точно
                                                сегментировать
                                                аудиторию;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Повышать
                                                эффективность
                                                маркетинговых
                                                стратегий;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Организовать
                                                обмен данными
                                                со&nbsp;сторонними
                                                сервисами;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Снижать
                                                нагрузку
                                                на&nbsp;целевые
                                                сайты;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Вести
                                                мониторинг
                                                потока данных
                                                на&nbsp;сайтах
                                                в&nbsp;режиме
                                                реального
                                                времени, а&nbsp;также
                                                уведомлять
                                                об&nbsp;обнаруженных
                                                ошибках в&nbsp;JavaScript;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Обеспечивать
                                                компанию
                                                профессиональной
                                                командой
                                                поддержки
                                                и&nbsp;сопровождения.</span>
                                </li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c43"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 424.00px;"><img
                                                alt="5d5b0f03a48f540006ae11b3.jpg"
                                                src="images/image48.jpg"
                                                style="width: 566.67px; height: 424.00px; margin-left: -50px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="id.28h4qwu"></a>
                </div>

                <!-- 79 -->
                <div data-num="79" class="numNUMBER page-mimi" id="container-pagnation79">
                        <h5 class="c12" id="h.xddaxsjj4z7l"><span class="c6">Trackad</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://www.trackad.ai/ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598515000&amp;usg=AOvVaw0-l45CckbWHMz0_4AtfiPE">trackad.ai/ru</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Комплексный
                                        набор
                                        инструментов для
                                        онлайн-маркетинга.
                                        Распространяется
                                        по&nbsp;модели SaaS&nbsp;—
                                        оплата
                                        по&nbsp;подписке.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">• TrackAd Collector&nbsp;—
                                        позволяет всего
                                        за&nbsp;считанные
                                        минуты
                                        максимально
                                        точно определить
                                        степень
                                        рентабельности
                                        используемых
                                        источников
                                        трафика. Данные
                                        по&nbsp;всем
                                        рекламным
                                        кампаниям будут
                                        собраны в&nbsp;одном
                                        месте в&nbsp;удобном
                                        для дальнейшего
                                        анализа виде.
                                        Быстрая оценка ROI
                                        и&nbsp;других
                                        ключевых
                                        параметров.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">• </span><span class="c4">TrackAd</span><span
                                        class="c0">&nbsp;360&nbsp;—
                                        показывает
                                        стоимость
                                        каждого шага
                                        текущей воронки
                                        продаж.
                                        Инструмент
                                        позволяет
                                        снизить CPO до&nbsp;50%
                                        и&nbsp;увеличить ROI
                                        по&nbsp;каждому
                                        источнику на&nbsp;10—30%.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">• </span><span class="c4">TrackAd</span><span
                                        class="c0">&nbsp;Lead&nbsp;—
                                        помогает
                                        оптимизировать
                                        конверсионную
                                        воронку
                                        и&nbsp;повышать
                                        рентабельность
                                        инвестиций
                                        в&nbsp;привлечение
                                        клиентов. Решение
                                        предназначено
                                        для наиболее
                                        продуктивной
                                        работы с&nbsp;лидами.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">• </span><span class="c4">TrackAd</span><span
                                        class="c4">&nbsp;Affiliate&nbsp;— заточен
                                        под </span><span class="c4">партнёрский</span><span class="c4">&nbsp;маркетинг.
                                        Этот специальный
                                        модуль призван
                                        облегчить работу
                                        с&nbsp;</span><span class="c4">партнёрскими</span><span
                                        class="c0">&nbsp;программами
                                        и&nbsp;CPA-сетями,
                                        а&nbsp;также защитить
                                        от&nbsp;фродов.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">По&nbsp;свидетельствам
                                        клиентов,
                                        техническое
                                        и&nbsp;маркетинговое
                                        сопровождение
                                        является одной
                                        из&nbsp;главных
                                        сильных сторон
                                        компании TrackAd Group.</span></p>
                        <h3 class="c31 c63"><span class="c6"></span></h3>
                </div>

                <!-- 80 -->
                <div data-num="80" class="numNUMBER page-mimi" id="container-pagnation80">
                        <h3 class="c47"><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 274.67px;"><img
                                                alt="5d5b1028ad7e130007c70e6d.jpg"
                                                src="images/image61.jpg"
                                                style="width: 566.67px; height: 274.67px; margin-left: -75px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h3><a id="id.nmf14n"></a>
                        <h5 class="c12" id="h.wu7hhxkcvt9a"><span class="c6">Funnel</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://funnel.io/&amp;sa=D&amp;source=editors&amp;ust=1614119598517000&amp;usg=AOvVaw0camprt-5q7UC8zyAqy7oU">funnel.io</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Шведский
                                        сервис сбора,
                                        обработки
                                        и&nbsp;визуализации
                                        аналитических
                                        данных. Этот
                                        продукт
                                        наверняка
                                        придётся
                                        по&nbsp;вкусу тем, кто
                                        предпочитает
                                        чисто «западное»,
                                        европейское
                                        видение
                                        оптимизации
                                        маркетинговых
                                        процессов. Сервис
                                        доступен
                                        по&nbsp;подписке,
                                        стоимость
                                        тарифов
                                        ранжируется
                                        в&nbsp;зависимости
                                        от&nbsp;размера
                                        рекламного
                                        бюджета компании.
                                        Пользовательский
                                        интерфейс
                                        доступен только
                                        на&nbsp;английском
                                        языке. Пара
                                        акцентов
                                        на&nbsp;особенностях
                                        Funnel:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_5iais8am4mub-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">Оперативное
                                                извлечение,
                                                структурирование
                                                и&nbsp;сопоставление
                                                обширных данных
                                                о&nbsp;продажах и&nbsp;KPI;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Готовые
                                                интеграции
                                                с&nbsp;505&nbsp;рекламными
                                                платформами,
                                                список
                                                постоянно
                                                дополняется;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Большое
                                                количество
                                                предоставляемых
                                                параметров
                                                и&nbsp;метрик для
                                                анализа;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Минимум
                                                ручного
                                                вмешательства
                                                -максимум
                                                автоматизации;</span></li>
                                <li class="c17 li-bullet-1"><span class="c4">Простая
                                                навигация
                                                и&nbsp;быстрое,
                                                интуитивно
                                                понятное
                                                управление
                                                процессами&nbsp;—
                                                одна
                                                из&nbsp;действительно
                                                сильных сторон
                                                продукта,
                                                а&nbsp;составление
                                                и&nbsp;выгрузка </span><span class="c4">отчётов</span><span
                                                class="c0">&nbsp;осуществляются
                                                вообще в&nbsp;пару
                                                кликов;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Интеграция
                                                со&nbsp;многими
                                                сторонними
                                                сервисами, вроде
                                                Google Analytics, BigQuery, Amazon Redshift
                                                и&nbsp;прочих.</span></li>
                        </ul>
                </div>

                <!-- 81 -->
                <div data-num="81" class="numNUMBER page-mimi" id="container-pagnation81">
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c12" id="h.m2v1mmbqlg97"><span class="c4"><br></span><a id="id.37m2jsg"></a><span
                                        style=" display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 249.33px;"><img
                                                alt="5d5b4dbdf9abae0006c5d8aa.jpg"
                                                src="images/image28.jpg"
                                                style="width: 566.67px; height: 249.33px; margin-left: -80px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h5>
                        <h3 class="c47"><span class="c6">Mixpanel</span><br><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://mixpanel.com/&amp;sa=D&amp;source=editors&amp;ust=1614119598519000&amp;usg=AOvVaw1p8qI0pDfZkPRxbd1TJpkv">mixpanel.com</a></span>
                        </h3>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Ещё</span><span class="c0">&nbsp;один
                                        известный
                                        европейский
                                        продукт,
                                        нацеленный
                                        на&nbsp;работу
                                        с&nbsp;мобильными
                                        приложениями. Его
                                        главная функция
                                        заключается
                                        в&nbsp;очень точном
                                        отслеживании
                                        поведенческих
                                        факторов
                                        пользователей,
                                        определении,
                                        какой именно этап
                                        ключевым образом
                                        влияет
                                        на&nbsp;итоговую
                                        конверсию.
                                        Обладая такой
                                        ценной
                                        аналитической
                                        информацией,
                                        можно
                                        максимально
                                        продуктивно
                                        выстраивать
                                        воронку продаж.
                                        На&nbsp;сегодняшний
                                        день более 250&nbsp;тыс.
                                        сайтов
                                        и&nbsp;приложений
                                        используют Mixpanel.
                                        В&nbsp;чём&nbsp;же его
                                        главные
                                        особенности?</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_i8388su77ztj-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Впечатляющие
                                                аналитические
                                                возможности;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">«Действия
                                                важнее
                                                просмотров»&nbsp;—
                                                один
                                                из&nbsp;неофициальных
                                                девизов
                                                компании, как&nbsp;бы
                                                говорящий сам
                                                за&nbsp;себя;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Гибкая
                                                работа
                                                с&nbsp;уведомлениями
                                                пользователей:
                                                самостоятельно
                                                настраивайте
                                                желаемый дизайн,
                                                формулировки
                                                и&nbsp;т.д.;</span></li>
                        </ul>
                </div>

                <!-- 82 -->
                <div data-num="82" class="numNUMBER page-mimi" id="container-pagnation82">
                        <li class="c17 li-bullet-7"><span class="c0">Сегментирование
                                        событий
                                        по&nbsp;выбранному
                                        признаку,
                                        позволяющее
                                        наглядно
                                        визуализировать
                                        поведенческий
                                        контур
                                        потенциальных
                                        клиентов
                                        на&nbsp;нужном
                                        этапе;</span></li>
                        <li class="c17 li-bullet-7"><span class="c0">Чистый
                                        минималистичный
                                        дизайн и, как
                                        следствие,
                                        быстрое
                                        обучение
                                        и&nbsp;комфортный
                                        рабочий
                                        процесс;</span></li>
                        <li class="c55 c59 c65 li-bullet-7"><span class="c0">Бесплатный
                                        пробный тариф,
                                        вполне
                                        подходящий для
                                        того, чтобы
                                        оценить
                                        возможности
                                        продукта.</span></li>

                        <p class="c28 c54 c59 c65"><span class="c0"></span></p>
                        <h3 class="c47"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 314.67px;"><img
                                                alt="5d5b5026a48f540006ae1858.jpg"
                                                src="images/image58.jpg"
                                                style="width: 566.67px; height: 314.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h3><a id="id.1mrcu09"></a>
                        <h5 class="c12" id="h.93eju7lo4v8l"><span class="c6">Marketo</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://www.marketo.com/&amp;sa=D&amp;source=editors&amp;ust=1614119598520000&amp;usg=AOvVaw2MKmeHvRzTMXO5vsnNyq0t">marketo.com</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Marketo, Inc — это
                                        американская
                                        софтверная
                                        компания, которая
                                        сосредоточила
                                        свою работу над
                                        маркетинговыми
                                        программными
                                        комплексами. И,
                                        начиная с&nbsp;2006&nbsp;года,
                                        Marketo&nbsp;— это их флагман,
                                        подходящий как
                                        для среднего, так
                                        и&nbsp;для большого
                                        бизнеса. Решением
                                        целого ряда
                                        важнейших задач
                                        является
                                        использование
                                        полной
                                        автоматизации
                                        во&nbsp;всех ключевых
                                        процессах.
                                        А&nbsp;использование
                                        искусственного
                                        интеллекта
                                        позволяет
                                        прогнозировать
                                        движение рынка
                                        и&nbsp;выстраивать
                                        наиболее
                                        продуктивные
                                        маркетинговые
                                        стратегии. Вот
                                        лишь некоторые
                                        сильные стороны
                                        Маркето:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 83 -->
                <div data-num="83" class="numNUMBER page-mimi" id="container-pagnation83">
                        <ul class="c9 lst-kix_l2w9errjnnmd-0 start">
                                <li class="c55 li-bullet-7"><span class="c0">Охват всех
                                                возможных точек
                                                соприкосновения
                                                с&nbsp;потенциальным
                                                клиентом;</span></li>
                                <li class="c55 li-bullet-1"><span class="c0">Почтовые
                                                рассылки,
                                                соцсети,
                                                мобильные
                                                приложения, лиды
                                                в&nbsp;интернете&nbsp;—
                                                работайте
                                                с&nbsp;чем-то
                                                наиболее для вас
                                                эффективным или
                                                со&nbsp;всем сразу;</span></li>
                                <li class="c55 li-bullet-2"><span class="c0">Быстрое
                                                составление
                                                и&nbsp;запуск
                                                рекламных
                                                кампаний;</span></li>
                                <li class="c55 li-bullet-7"><span class="c0">Широкие
                                                аналитические
                                                возможности;</span></li>
                                <li class="c55 c59 c65 li-bullet-1"><span class="c0">Интеграция CRM
                                                и&nbsp;других
                                                сторонних
                                                сервисов.</span></li>
                        </ul>
                        <p class="c28 c54 c59 c65"><span class="c0"></span></p>
                        <h5 class="c12" id="h.7qwp9y5c87v4"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 304.00px;"><img
                                                alt="5d5b5a72ad7e130007c71550.jpg"
                                                src="images/image15.jpg"
                                                style="width: 566.67px; height: 304.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h5>
                        <h5 class="c1" id="h.2zwb5sm5enop"><span class="c6"></span></h5>
                        <h5 class="c1" id="h.ze9rt6s2zet9"><span class="c6"></span></h5>
                        <h5 class="c1" id="h.2qmj7rhuh9fg"><span class="c6"></span></h5>
                        <h5 class="c1" id="h.651pn9xigei2"><span class="c6"></span></h5>
                        <h5 class="c1" id="h.3ssrinza3k3z"><span class="c6"></span></h5>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                </div>

                <!-- 84 -->
                <div data-num="84" class="numNUMBER page-mimi" id="container-pagnation84">
                        <h5 class="c12" id="h.vnqsov64kchd"><span class="c4"><br></span><a id="id.46r0co2"></a><span
                                        class="c6">Databox</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://databox.com/&amp;sa=D&amp;source=editors&amp;ust=1614119598522000&amp;usg=AOvVaw1SJgt6OszVM-N0BsZ-cfeI">databox.com</a></span>
                        </h3>
                        <p class="c25"><span class="c0"></span></p>
                        <p class="c75 c104"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 368.00px;"><img
                                                alt="5d5b74d4a48f540006ae1af4.jpg"
                                                src="images/image5.jpg"
                                                style="width: 566.67px; height: 368.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c0">Высокопродуктивная
                                        машина по&nbsp;сбору
                                        маркетинговых
                                        данных,
                                        призванная
                                        повысить
                                        рентабельность
                                        любого бизнеса.
                                        «Все ваши KPI
                                        в&nbsp;одном месте»&nbsp;—
                                        так кратко можно
                                        охарактеризовать
                                        этот любопытный
                                        сервис.
                                        Подключите
                                        нужные вам базы
                                        данных
                                        и&nbsp;работайте
                                        из&nbsp;любого места
                                        с&nbsp;любого
                                        устройства. Чем Databox
                                        выделяется
                                        на&nbsp;рынке:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_rcymxis7y2y1-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">Широчайшие
                                                возможности
                                                интеграции
                                                различных
                                                источников для
                                                максимально
                                                эффективного
                                                отбора
                                                информации;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Простое
                                                создание
                                                аналитических
                                                дашбордов;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">ARPU, CAC, LTV, ROAS&nbsp;— эти
                                                и&nbsp;многие другие
                                                важнейшие
                                                метрики
                                                и&nbsp;экономические
                                                показатели
                                                вашего бизнеса
                                                собираются
                                                в&nbsp;удобном
                                                графическом
                                                виде на&nbsp;вашем
                                                устройстве
                                                всего в&nbsp;пару
                                                кликов;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Удобный
                                                конструктор для
                                                создания
                                                панелей
                                                мониторинга;</span></li>
                        </ul>
                </div>

                <!-- 85 -->
                <div data-num="85" class="numNUMBER page-mimi" id="container-pagnation85">
                        <li class="c17 li-bullet-7"><span class="c4">Гибко
                                        настраиваемая </span><span class="c4">отчётность</span><span class="c0">;</span>
                        </li>
                        <li class="c17 li-bullet-2"><span class="c0">Практичная
                                        система
                                        оповещений
                                        на&nbsp;любом
                                        устройстве;</span></li>
                        <li class="c17 li-bullet-7"><span class="c0">В&nbsp;наличии
                                        бесплатный
                                        тариф,
                                        ограниченный
                                        лишь
                                        количеством
                                        источников
                                        и&nbsp;частотой
                                        обновления
                                        данных.</span></li>

                        <h3 class="c31 c63"><span class="c6"></span></h3>
                        <h5 class="c12" id="h.2rlu90iv9bg4"><span class="c4"><br></span><a id="id.2lwamvv"></a><span
                                        class="c6">Hubspot</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://www.hubspot.com/&amp;sa=D&amp;source=editors&amp;ust=1614119598524000&amp;usg=AOvVaw1RBubrfO7F3YV1OEokvWFg">hubspot.com</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Впечатляющая
                                        по&nbsp;своей
                                        эффективности
                                        система
                                        управления вашим
                                        бизнесом. В&nbsp;Hubspot
                                        собрано
                                        практически всё,
                                        что необходимо
                                        для ведения
                                        успешного
                                        онлайн-маркетинга.
                                        Важная аналитика,
                                        взаимодействие
                                        с&nbsp;соцсетями
                                        и&nbsp;мобильными
                                        приложениями,
                                        а&nbsp;также
                                        собственная CRM&nbsp;—
                                        это лишь немногое
                                        из&nbsp;того, что
                                        находится
                                        на&nbsp;борту этого
                                        программного
                                        бизнес-решения.
                                        Для ознакомления
                                        можно взглянуть
                                        на&nbsp;этот
                                        расширенный
                                        перечень
                                        возможностей:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_g8dau6qpzrwv-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Нахождение
                                                клиентов
                                                во&nbsp;всех
                                                возможных
                                                уголках
                                                интернета:
                                                настраивайте
                                                почтовые
                                                рекламные
                                                кампании,
                                                работайте через
                                                приложения
                                                и&nbsp;соцсети;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Простое
                                                управление
                                                контентом как
                                                на&nbsp;собственных
                                                сайтах, так
                                                и&nbsp;в&nbsp;соцсетях;</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Ключевые
                                                аналитические
                                                данные
                                                по&nbsp;важнейшим
                                                маркетинговым
                                                каналам;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Бенчмарки
                                                деятельности
                                                конкурентов;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Собственная CRM
                                                хранит все
                                                важные детали
                                                и&nbsp;контакты
                                                клиентов,
                                                а&nbsp;также историю
                                                ваших с&nbsp;ними
                                                взаимодействий;</span>
                                </li>
                                <li class="c17 li-bullet-7"><span class="c0">Интегрированный
                                                конструктор
                                                сайтов, CMS;</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Встроенный
                                                сервис
                                                сокращения
                                                ссылок.</span></li>
                        </ul>
                        <h3 class="c31 c63"><span class="c6"></span></h3>
                </div>

                <!-- 86 -->
                <div data-num="86" class="numNUMBER page-mimi" id="container-pagnation86">
                        <h3 class="c31"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 394.67px;"><img
                                                alt="5d5b763ef9abae0006c5dba0.jpg"
                                                src="images/image80.jpg"
                                                style="width: 566.67px; height: 394.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h3><a id="id.111kx3o"></a>
                        <h5 class="c12" id="h.uper1qofn4pk"><span class="c6">Callibri</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://callibri.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598526000&amp;usg=AOvVaw1j4NQd2sW21S1r-SBd8B37">callibri.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c4">Российская
                                        компания и&nbsp;</span><span class="c4">одноимённый</span><span
                                        class="c0">&nbsp;продукт,
                                        представляющий
                                        собой единую
                                        платформу
                                        маркетинговой
                                        поддержки для
                                        вашей компании.
                                        Одной
                                        из&nbsp;отличительных
                                        черт является
                                        демократичная
                                        ценовая политика,
                                        что делает этот
                                        сервис доступным
                                        даже для малого
                                        бизнеса. Десятки
                                        встроенных
                                        инструментов
                                        обеспечивают
                                        комфортную
                                        работу
                                        с&nbsp;потенциальными
                                        и&nbsp;постоянными
                                        клиентами.
                                        Наиболее
                                        характерные
                                        особенности:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_vgfrf4we2ed-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">Собственная
                                                небольшая CRM;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Коллтрекинг
                                                и&nbsp;email-трекинг;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Универсальный
                                                кабинет для
                                                коммуникаций,
                                                объединяющий
                                                в&nbsp;себе все
                                                основные
                                                соцсети
                                                и&nbsp;мессенджеры
                                                (Вконтакте,
                                                Одноклассники, Facebook,
                                                Viber, Telegram и&nbsp;т.д.);</span></li>
                        </ul>
                </div>

                <!-- 87 -->
                <div data-num="87" class="numNUMBER page-mimi" id="container-pagnation87">
                        <li class="c17 li-bullet-7"><span class="c0">Полная
                                        интеграция
                                        с&nbsp;основными
                                        сервисами
                                        Яндекса, Гугла
                                        и&nbsp;многими
                                        другими;</span></li>
                        <li class="c17 li-bullet-7"><span class="c0">Простой
                                        интерфейс
                                        и&nbsp;понятная
                                        реализация
                                        позволяют
                                        обходиться без
                                        IT-специалиста;</span></li>
                        <li class="c17 li-bullet-2"><span class="c0">Круглосуточная
                                        поддержка.</span></li>

                        <p class="c43 c54"><span class="c0"></span></p>
                        <h5 class="c12" id="h.7l3p72i5m1x5"><span class="c4"><br></span><a id="id.3l18frh"></a><span
                                        class="c6">Calltracking</span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 116.00px;"><img
                                                alt="5d5b7df4ad7e130007c718ad.jpg"
                                                src="images/image7.jpg"
                                                style="width: 566.67px; height: 116.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://calltracking.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598527000&amp;usg=AOvVaw3upxiCnrU_m6LtdYzzecxj">calltracking.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Ещё один
                                        интересный
                                        сервис
                                        от&nbsp;отечественной
                                        компании, который
                                        отслеживает
                                        звонки клиентов
                                        и&nbsp;предоставляет
                                        данные
                                        по&nbsp;эффективности
                                        текущих
                                        рекламных
                                        кампаний.
                                        В&nbsp;наличии также
                                        современные
                                        возможности
                                        SIP-телефонии
                                        со&nbsp;всеми её
                                        преимуществами.
                                        Итак, с&nbsp;чем&nbsp;же
                                        приходится иметь
                                        дело:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_4mk4t72l391l-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Комфортная
                                                работа
                                                со&nbsp;звонками:
                                                запись,
                                                прослушивание,
                                                хранение
                                                основной
                                                информации
                                                о&nbsp;звонившем;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Детальная
                                                отчётность
                                                и&nbsp;сегментирование
                                                по&nbsp;источникам
                                                выявляют
                                                наиболее
                                                популярные
                                                и&nbsp;продуктивные
                                                рекламные
                                                каналы;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">UTM-метки
                                                помогают
                                                определить
                                                источники
                                                звонков
                                                и&nbsp;выявить
                                                обсуждаемые
                                                категории
                                                товаров;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Высокая
                                                эффективность
                                                применения даже
                                                при скромных
                                                рекламных
                                                бюджетах;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Доступность
                                                для малого
                                                бизнеса.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 88 -->
                <div data-num="88" class="numNUMBER page-mimi" id="container-pagnation88">
                        <h5 class="c12" id="h.9vchql556xe1"><span class="c4"><br></span><a id="id.206ipza"></a><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 369.33px;"><img
                                                alt="5d5b7f7af9abae0006c5dd18.jpg"
                                                src="images/image54.jpg"
                                                style="width: 566.67px; height: 369.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h5>
                        <h3 class="c47"><span class="c6">Alloka</span><br><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://alloka.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598529000&amp;usg=AOvVaw1eUOaq7l4bHDO-U3i9zWHT">alloka.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c4">Российский
                                        сервис
                                        отслеживания
                                        и&nbsp;</span><span class="c4">учёта</span><span class="c0">&nbsp;источников
                                        телефонных
                                        обращений. Услуги
                                        данного
                                        коллтрекинга
                                        будут полезны
                                        компаниям,
                                        размещающим
                                        рекламу
                                        на&nbsp;оффлайн-площадках.
                                        Инструмент
                                        предоставляет
                                        исчерпывающие
                                        статистические
                                        данные, поэтому вы
                                        всегда сможете
                                        оценить
                                        эффективность
                                        того или иного
                                        рекламного
                                        канала.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 89 -->
                <div data-num="89" class="numNUMBER page-mimi" id="container-pagnation89">
                        <p class="c8 c59 c107"><span class="c0">Все
                                        входящие
                                        обращения
                                        клиентов
                                        находятся
                                        в&nbsp;одном месте,
                                        а&nbsp;количество
                                        подключаемых
                                        сторонних
                                        сервисов (Яндекс,
                                        Гугл, amoCRM, Битрикс24
                                        и&nbsp;т.д.) значительно
                                        упрощает работу
                                        персонала,
                                        расширяя ваши
                                        маркетинговые
                                        возможности. Есть
                                        возможность
                                        использовать как
                                        городские, так
                                        и&nbsp;федеральные
                                        номера.</span></p>
                        <p class="c5 c59 c65"><span class="c0"></span></p>
                        <h5 class="c12" id="h.82uzgzvjcco7"><span class="c4"><br></span><a id="id.4k668n3"></a><span
                                        class="c6">Quon</span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 225.33px;"><img
                                                alt="5d5b8024f9abae0006c5dd3d.jpg"
                                                src="images/image22.jpg"
                                                style="width: 566.67px; height: 225.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://www.quon.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598530000&amp;usg=AOvVaw2bMdI3c6JUjmKtEL_DdYwt">quon.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Комплекс
                                        сервисов
                                        сквозной
                                        аналитики, каждый
                                        из&nbsp;которых
                                        подключается
                                        по&nbsp;мере
                                        надобности:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">• QUON </span><span class="c4">Calltracking</span><span
                                        class="c4">&nbsp;—
                                        сервис
                                        динамического
                                        коллтрекинга,
                                        поддерживающий
                                        все необходимые
                                        интеграции
                                        и&nbsp;позволяющий
                                        получить
                                        контроль над
                                        рекламой
                                        и&nbsp;зависящими
                                        от&nbsp;</span><span class="c4">неё</span><span class="c0">&nbsp;продажами.
                                        Компания
                                        сотрудничает
                                        сразу
                                        с&nbsp;несколькими
                                        крупными
                                        провайдерами
                                        связи.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">• QUON Context&nbsp;— это
                                        решение хорошо </span><span class="c4">подойдёт</span><span class="c0">&nbsp;для
                                        быстрой
                                        и&nbsp;эффективной
                                        настройки
                                        контекстной
                                        рекламы
                                        в&nbsp;рекламных
                                        кампаниях
                                        Яндекс.Директ.
                                        Достигается это
                                        за&nbsp;счёт
                                        значительной
                                        автоматизации
                                        большинства
                                        ключевых
                                        процессов.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">• QUON Callback&nbsp;— сервис
                                        обратных звонков,
                                        простой
                                        и&nbsp;практичный. При
                                        заказе звонка
                                        клиентом
                                        на&nbsp;вашем сайте
                                        менеджеру
                                        приходит дозвон.
                                        Большой
                                        ассортимент
                                        всевозможных
                                        удобных настроек
                                        в&nbsp;наличии.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 90 -->
                <div data-num="90" class="numNUMBER page-mimi" id="container-pagnation90">
                        <p class="c8"><span class="c4">• QUON Predict&nbsp;— данный
                                        сервисный
                                        продукт
                                        бесплатен
                                        и&nbsp;позволяет
                                        быстро прикинуть
                                        окупаемость
                                        бизнеса
                                        в&nbsp;Яндекс.Директ
                                        в&nbsp;зависимости
                                        от&nbsp;ключевых фраз,
                                        рекламного
                                        бюджета и&nbsp;</span><span class="c4">ещё</span><span class="c0">&nbsp;ряда
                                        параметров.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c12" id="h.oifog7mwgygr"><span class="c4"><br></span><a id="id.2zbgiuw"></a><span
                                        class="c4">Utmstat</span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 208.00px;"><img
                                                alt="5d5b80e4f9abae0006c5dd6b.jpg"
                                                src="images/image31.jpg"
                                                style="width: 566.67px; height: 208.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://hello.utmstat.com/&amp;sa=D&amp;source=editors&amp;ust=1614119598531000&amp;usg=AOvVaw18S2iXhd5Qit_k140ZVVE-">utmstat.com</a></span>
                        </h3>
                        <p class="c8"><span class="c4">Любопытный
                                        московский
                                        сервис сквозной
                                        аналитики,
                                        сочетающий
                                        в&nbsp;себе
                                        собственную CRM,
                                        колл-трекер, CRA и&nbsp;</span><span class="c4">партнёрский</span><span
                                        class="c0">&nbsp;маркетинг,
                                        UNIT-экономику
                                        и&nbsp;набор
                                        дашбордов&nbsp;с&nbsp;ключевыми
                                        индикаторами
                                        эффективности
                                        вашего бизнеса.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">По&nbsp;заверению
                                        разработчиков,
                                        приложен
                                        максимум усилий
                                        для того, чтобы вы
                                        не&nbsp;тратили время
                                        на&nbsp;изучение всех
                                        тонкостей
                                        и&nbsp;настроек,
                                        а&nbsp;занимались
                                        своим делом,
                                        предоставив им
                                        возможность
                                        позаботиться обо
                                        всех технических
                                        аспектах. Команда
                                        Utmstat готова
                                        разработать для
                                        вашей компании
                                        готовое
                                        аналитическое
                                        решение «под
                                        ключ».</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 91 -->
                <div data-num="91" class="numNUMBER page-mimi" id="container-pagnation91">
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 600.00px; height: 470.00px;"><img
                                                alt=""
                                                src="images/image4.png"
                                                style="width: 600.00px; height: 470.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                </div>

                <!-- 92 -->
                <div data-num="92" class="numNUMBER page-mimi" id="container-pagnation92">
                        <h5 class="c12" id="h.i5ahzo9wm47g"><span class="c4">Smartanalytics</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://smartanalytics.io&amp;sa=D&amp;source=editors&amp;ust=1614119598533000&amp;usg=AOvVaw1CanPhMi6Ws1sDukPMS6JD">smartanalytics.io</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Платформа
                                        объединяет
                                        данные из 50+
                                        источников
                                        данных. Сервис
                                        обеспечивает
                                        аналитику с
                                        широкой
                                        сегментацией, в
                                        том числе с
                                        многоуровневыми
                                        сегментами.
                                        Например, можно
                                        анализировать не
                                        только
                                        "источник/канал-кампания-ключ",
                                        но и типы
                                        устройств,
                                        позиции, площадки
                                        размещения,
                                        города, типы
                                        рекламных
                                        кампаний, баннеры,
                                        группы другое.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Визуализации
                                        с поддержкой
                                        многоуровневого
                                        &nbsp;drill-down строятся на
                                        собственном
                                        движке. Кастомные
                                        отчеты и дашборды
                                        настраиваются
                                        пользователем с
                                        помощью drag`n`drop.
                                        Имеется работа с
                                        когортами и
                                        person-based-аналитикой.
                                        Поддерживает
                                        онлайн- и
                                        офлайн-расходы.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Система имеет
                                        учёт длинного
                                        цикла сделки и
                                        повторных продаж.
                                        Платформа
                                        позволяет
                                        анализировать
                                        эффективность
                                        маркетинга,
                                        учитывая доходы и
                                        расходы при цикле
                                        сделки любой
                                        длительности и
                                        при любом
                                        количестве
                                        повторных продаж.
                                        Имеется работа с
                                        когортами.</span></p>
                        <h3 class="c31"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 340.23px; height: 287.31px;"><img
                                                alt=""
                                                src="images/image26.png"
                                                style="width: 340.23px; height: 287.31px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h3>

                </div>

                <!-- 93 -->
                <div data-num="93" class="numNUMBER page-mimi" id="container-pagnation93">
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 624.00px; height: 349.47px;"><img
                                                alt="limit-image"
                                                src="images/image23.png"
                                                style="width: 624.00px; height: 349.47px; margin-left: -0.00px; margin-top: -0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c12" id="h.p50mx6823i38"><span class="c6">ROMI.Center</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://romi.center&amp;sa=D&amp;source=editors&amp;ust=1614119598534000&amp;usg=AOvVaw37KSA3DKItcR55AumlNfHr">romi.center</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Сервис
                                        сквозной
                                        аналитики с
                                        доступной ценой 990
                                        рублей в месяц.
                                        Позволяет
                                        визуализировать
                                        данные в
                                        собственных
                                        дашбордах, в Google Data Studio, а
                                        также передавать
                                        их в Google Analytics.</span></p>
                        <p class="c5"><span class="c0"></span></p>

                </div>

                <!-- 94 -->
                <div data-num="94" class="numNUMBER page-mimi" id="container-pagnation94">
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 624.00px; height: 432.33px;"><img
                                                alt=""
                                                src="images/image24.jpg"
                                                style="width: 624.00px; height: 432.33px; margin-left: -0.00px; margin-top: -0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c12" id="h.3gndt17jr1xb"><span class="c6">LTVytics</span></h5>
                        <h3 class="c28 c59 c65" id="h.ez1i5nz8y68k"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://ltvytics.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598535000&amp;usg=AOvVaw1I5D7gbEHZ3-Wf7Pkj_UT2">ltvytics.ru</a></span>
                        </h3>
                        <p class="c69"><span class="c0">Специально
                                        заточенный под
                                        работу с
                                        интернет-магазинами,
                                        этот сервис
                                        собирает и
                                        предоставляет
                                        исчерпывающие
                                        данные по каждому
                                        клиенту. Владелец
                                        интернет-магазина
                                        может в любой
                                        момент
                                        сформировать
                                        отчет по выручке
                                        за выбранный
                                        период и увидеть
                                        долю прибыли от
                                        новых и
                                        постоянных
                                        клиентов. Обладая
                                        этой информацией,
                                        можно оперативно
                                        скорректировать
                                        расходы на
                                        привлечение
                                        новых и удержание
                                        старых
                                        покупателей.</span></p>
                        <p class="c69 c54"><span class="c0"></span></p>
                        <p class="c69"><span class="c0">Удобное
                                        сегментирование
                                        аудитории,
                                        экспорт данных в
                                        сторонние
                                        системы,
                                        интеграции с CRM и
                                        рекламными
                                        сервисами - всё
                                        это в наличии.</span></p>
                        <p class="c69 c54"><span class="c0"></span></p>
                </div>

                <!-- 95 -->
                <div data-num="95" class="numNUMBER page-mimi" id="container-pagnation95">
                        <p class="c69"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 527.00px; height: 417.00px;"><img
                                                alt=""
                                                src="images/image11.png"
                                                style="width: 527.00px; height: 417.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <hr style="page-break-before:always;display:none;"><a id="id.3cqmetx"></a><a
                                id="id.1rvwp1q"></a>
                </div>

                <!-- 96 -->
                <div data-num="96" class="numNUMBER page-mimi" id="container-pagnation96">
                        <h4 class="c27" id="h.3tqd3rlmdnyh"><span class="c4">Коннекторы</span></h4>
                        <p class="c25"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Коннекторы
                                        позволяют
                                        соединить
                                        различные
                                        сервисы друг с
                                        другом. Сначала
                                        нужно
                                        определиться
                                        какие нужны
                                        сервисы, а потом
                                        выбрать
                                        коннектор.
                                        Подробнее о
                                        коннекторах
                                        ниже.</span></p>
                        <p class="c25"><span class="c0"></span></p><a id="id.4bvk7pj"></a>
                        <h5 class="c12" id="h.fe96a0apkqo"><span class="c6">BI Connect</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=http://connect.mybi.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598536000&amp;usg=AOvVaw3Cp5v2r5-DfqPK2gy8SYTj">connect.mybi.ru</a></span>
                        </h3>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Недавно
                                        появился сервис
                                </span><span class="c4">myBI</span><span class="c4">&nbsp;Connect
                                        от&nbsp;компании </span><span class="c4">MyBI</span><span class="c0">. Сервис
                                        создает для
                                        пользователя
                                        облачное
                                        хранилище Microsoft Azure
                                        и&nbsp;позволяет
                                        подключиться
                                        к&nbsp;различным
                                        источникам
                                        данных.</span></p>
                        <p class="c8"><span class="c4">Работает с </span><span class="c4">отчётами</span><span
                                        class="c0">&nbsp;в
                                        Microsoft Power BI.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 216.00px;"><img
                                                alt="59e53ce6dcff638b31b24da9.jpg"
                                                src="images/image47.jpg"
                                                style="width: 566.67px; height: 216.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>

                </div>

                <!-- 97 -->
                <div data-num="97" class="numNUMBER page-mimi" id="container-pagnation97">
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 266.67px;"><img
                                                alt="59e53ce5dcff638b31b24da6.jpg"
                                                src="images/image12.jpg"
                                                style="width: 566.67px; height: 266.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="id.2r0uhxc"></a>
                        <h5 class="c12" id="h.koxl6x894ikj"><span class="c6">Owox</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://owox.ru&amp;sa=D&amp;source=editors&amp;ust=1614119598537000&amp;usg=AOvVaw2Nfmy1fzy7Aa234ZOXB2ZH">owox.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Компания OWOX
                                        подходит под
                                        определение
                                        «технологической»&nbsp;—
                                        их продукты
                                        непросты
                                        в&nbsp;освоении
                                        и&nbsp;не&nbsp;пиарятся
                                        на&nbsp;каждом углу, и
                                        всё же
                                        используются
                                        крупными
                                        компаниями. Их
                                        стоимость, при
                                        этом, адекватна
                                        как&nbsp;для малого,
                                        так и&nbsp;среднего
                                        бизнеса.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">BI Pipeline&nbsp;— система
                                        соединяется
                                        в&nbsp;себя потоки
                                        данных
                                        из&nbsp;различных
                                        источников:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 98 -->
                <div data-num="98" class="numNUMBER page-mimi" id="container-pagnation98">
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 345.33px;"><img
                                                alt="59e53ce2dcff638b31b24da3.jpg"
                                                src="images/image67.jpg"
                                                style="width: 566.67px; height: 345.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 465.33px;"><img
                                                alt="59e53ce0dcff638b31b24da0.jpg"
                                                src="images/image78.jpg"
                                                style="width: 566.67px; height: 465.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>

                </div>

                <!-- 99 -->
                <div data-num="99" class="numNUMBER page-mimi" id="container-pagnation99">
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 228.00px;"><img
                                                alt="59e53cdfdcff638b31b24d9d.jpg"
                                                src="images/image81.jpg"
                                                style="width: 566.67px; height: 228.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c4">Другой
                                        продукт компания
                                        представила
                                        относительно
                                        недавно: сервис
                                        для атрибуции
                                        заказа на&nbsp;основе
                                        воронки. Он
                                        работает с&nbsp;Google BigQuery
                                        и&nbsp;позволяет
                                        придавать разные
                                        значения
                                        посещениям сайта
                                        при
                                        мультиканальной
                                        конверсии. Сервис
                                        используют </span><span class="c4">несэмплированные</span><span
                                        class="c0">&nbsp;данные Google
                                        Analytics.
                                        Стоимость
                                        составляет
                                        от&nbsp;114&nbsp;до&nbsp;1400$
                                        в&nbsp;месяц.<br></span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 282.42px;"><img
                                                alt="59e53cdcdcff638b31b24d9a.jpg"
                                                src="images/image37.jpg"
                                                style="width: 566.67px; height: 282.42px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="id.1664s55"></a>
                        <h5 class="c12" id="h.tjo1a0tkvhq6"><span class="c6">Albato</span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://albato.ru&amp;sa=D&amp;source=editors&amp;ust=1614119598538000&amp;usg=AOvVaw1OOMW5waMDkRAVTAIjOChZ">albato.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Сервис
                                        позволяет
                                        провести
                                        интеграции
                                        (которые зачастую
                                        ограничены)
                                        разных систем.
                                        Например,
                                        из&nbsp;Битрикс24 в&nbsp;Google Sheets
                                        можно выгрузить
                                        только новые лиды
                                        и&nbsp;изменения
                                        статуса сделок.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 100 -->
                <div data-num="100" class="numNUMBER page-mimi" id="container-pagnation100">
                        <p class="c8"><span class="c0">А&nbsp;если вам
                                        нужно выгружать
                                        что-то ещё: сумму
                                        сделок, число
                                        звонков, закрытых
                                        лидов? Тогда
                                        придётся брать
                                        другой
                                        инструмент —
                                        например,
                                        «Аналитика
                                        Битрикс24», —
                                        и&nbsp;делать полную
                                        выгрузку в&nbsp;базу.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Цена &nbsp;—999 р.
                                        в&nbsp;месяц.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c12" id="h.hvyupimu5aeq"><span class="c4"><br></span><a id="id.3q5sasy"></a><span
                                        class="c6">Renta</span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 273.33px;"><img
                                                alt="59e53ccadcff638b31b24d82.jpg"
                                                src="images/image9.jpg"
                                                style="width: 566.67px; height: 273.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h5>
                        <h3 class="c47"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://renta.im&amp;sa=D&amp;source=editors&amp;ust=1614119598539000&amp;usg=AOvVaw0hbDeG8UNok05fYuhuvouj">renta.im</a></span>
                        </h3>
                        <p class="c8"><span class="c4">Сбалансированный
                                        инструмент для
                                        выгрузки сырых
                                        данных
                                        из&nbsp;большого
                                        количества
                                        источников с&nbsp;их
                                        последующим
                                        разложением
                                        по&nbsp;полочкам.
                                        Удобная
                                        визуализация
                                        собранных данных
                                        покажет все
                                        нужные метрики
                                        в&nbsp;одном месте: CPO, ROI, LTV
                                        и&nbsp;прочие. Модели
                                        атрибуции
                                        поддаются гибкой
                                        ручной настройке
                                        под любые
                                        требования.
                                        Интеграция
                                        поддерживается
                                        со&nbsp;многими
                                        популярными
                                        сервисами
                                        и&nbsp;платформами.</span></p>
                        <p class="c75 c54"><span class="c0"></span></p><a
                                id="t.93bf108c414c40a0cf1b050bfd3f60866ee0eae9"></a><a id="t.0"></a>
                </div>


                <!-- 101 -->
                <div data-num="101" class="numNUMBER page-mimi" id="container-pagnation101">
                        <table class="c84">
                                <tbody>
                                        <tr class="c91">
                                                <td class="c87" colspan="1" rowspan="1">
                                                        <p class="c64"><span class="c6">Реклама</span></p>
                                                </td>
                                                <td class="c51" colspan="1" rowspan="1">
                                                        <p class="c64"><span class="c6">CRM и
                                                                        Маркетинговая
                                                                        Автоматизация</span>
                                                        </p>
                                                </td>
                                                <td class="c117" colspan="1" rowspan="1">
                                                        <p class="c64"><span class="c6">Базы
                                                                        Данных</span></p>
                                                </td>
                                                <td class="c80" colspan="1" rowspan="1">
                                                        <p class="c64"><span class="c6">BI-инструменты</span>
                                                        </p>
                                                </td>
                                        </tr>
                                        <tr class="c91">
                                                <td class="c87" colspan="1" rowspan="1">
                                                        <p class="c64"><span class="c0">Bing</span></p>
                                                        <p class="c64"><span class="c0">Facebook</span></p>
                                                        <p class="c64"><span class="c0">Google Ads</span></p>
                                                        <p class="c64"><span class="c0">MyTarget</span></p>
                                                        <p class="c64"><span class="c4">TwitterAds</span></p>
                                                        <p class="c64"><span class="c0">VK</span></p>
                                                        <p class="c64"><span class="c0">Яндекс.Директ</span>
                                                        </p>
                                                        <p class="c64"><span class="c0">Яндекс.Маркет</span>
                                                        </p>
                                                </td>
                                                <td class="c51" colspan="1" rowspan="1">
                                                        <p class="c64"><span class="c0">ActiveCampaign</span></p>
                                                        <p class="c64"><span class="c0">Esputnik</span></p>
                                                        <p class="c64"><span class="c0">Mailchimp</span></p>
                                                        <p class="c64"><span class="c0">Salesforce</span></p>
                                                </td>
                                                <td class="c117" colspan="1" rowspan="1">
                                                        <p class="c64"><span class="c0">BigQuery</span></p>
                                                        <p class="c64"><span class="c0">Clickhouse</span></p>
                                                        <p class="c64"><span class="c0">Microsoft SQL</span></p>
                                                        <p class="c64"><span class="c0">MySQL</span></p>
                                                        <p class="c64"><span class="c0">PostgreSQL</span></p>
                                                        <p class="c64"><span class="c0">Amazon RedShift</span></p>
                                                </td>
                                                <td class="c80" colspan="1" rowspan="1">
                                                        <p class="c64"><span class="c0">Google Data Studio</span></p>
                                                        <p class="c64"><span class="c0">Mode</span></p>
                                                        <p class="c64"><span class="c0">Power BI</span></p>
                                                        <p class="c64"><span class="c0">Tableau</span></p>
                                                </td>
                                        </tr>
                                </tbody>
                        </table>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Интеграция
                                        осуществляется в
                                        несколько
                                        кликов.&nbsp;
                                        Любопытно, что
                                        разработчики из Renta.im
                                        также
                                        реализовали
                                        возможность
                                        синхронизации
                                        между базами
                                        данных MySQL и BigQuery, что
                                        может оказаться
                                        весьма удобным,
                                        так как не требует
                                        подключения
                                        дополнительных
                                        библиотек. При
                                        начале работы с
                                        сервисом даются 7
                                        дней бесплатного
                                        использования с
                                        полным не
                                        урезанным
                                        функционалом.</span></p>
                        <p class="c5"><span class="c0"></span></p><a id="kix.1tv2igpta03"></a>
                </div>

                <!-- 102 -->
                <div data-num="102" class="numNUMBER page-mimi" id="container-pagnation102">
                        <h5 class="c59 c85" id="h.k1fdcsg4itui"><span class="c6">BI&nbsp;Data</span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 390.67px;"><img
                                                alt="5d87d6c9dced830007d1b06c.jpg"
                                                src="images/image33.jpg"
                                                style="width: 566.67px; height: 390.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h5>
                        <h3 class="c28" id="h.kw3hovb1f8kn"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=http://bi-data.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598545000&amp;usg=AOvVaw1nHUnSF72ADiPruJ-cQL03">bi-data.ru</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Промежуточный
                                        слой (коннектор)
                                        между выбранными
                                        вами
                                        аналитическими
                                        платформами и&nbsp;CRM
                                        Битрикс24. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Основной
                                        функционал
                                        заключается в
                                        выгрузке сырых
                                        данных
                                        из&nbsp;Битрикс24
                                        в&nbsp;локальную БД. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Работает
                                        с&nbsp;различными
                                        базами данных,
                                        в&nbsp;том числе:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_ecsoldwn0u85-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">LocalDB</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">MySQL</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">PostgreSQL</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">MSSQL</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Передача
                                        данных
                                        осуществляется в
                                        такие
                                        популярные&nbsp;BI, как
                                        QlikView, </span><span class="c4">QlikSense</span><span class="c4">, Tableau и
                                        Power BI.
                                        &nbsp;В&nbsp;качестве
                                        примера имеются
                                        готовые </span><span class="c4">отчёты</span><span class="c0">&nbsp;для
                                        Microsoft Power&nbsp;BI.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Поддерживается
                                        как коробочная,
                                        так и облачная
                                        версия Битрикс24. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <span
                                style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 309.33px;"><img
                                        alt="5d87dea8dced830007d1b2a8.jpg"
                                        src="images/image27.png"
                                        style="width: 566.67px; height: 309.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                        title=""></span>
                </div>

                <!-- 103 -->
                <div data-num="103" class="numNUMBER page-mimi" id="container-pagnation103">
                        <h5 class="c50 c94" id="h.69hexb3zgmfm"><span class="c6"><br>Supermetrics</span></h5>
                        <h3 class="c8 c94" id="h.uyvzawtpvo99"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://supermetrics.com/&amp;sa=D&amp;source=editors&amp;ust=1614119598548000&amp;usg=AOvVaw3Tcm32snicyk1ANgr0K2eL">supermetrics.com</a></span>
                        </h3>
                        <p class="c62"><span class="c0">SSA-сервис
                                        позволяет
                                        подключить
                                        множество
                                        различных систем,
                                        включая: </span></p>
                        <ul class="c9 lst-kix_k23q7v8iorbj-0 start">
                                <li class="c37 li-bullet-7"><span class="c0">Яндекс.Директ</span>
                                </li>
                                <li class="c37 li-bullet-2"><span class="c0">Яндекс.Метрику</span>
                                </li>
                                <li class="c37 li-bullet-7"><span class="c0">Вконтакте</span></li>
                        </ul>
                        <p class="c62"><span class="c0">Такой набор
                                        является
                                        приятной
                                        редкостью для
                                        зарубежных
                                        систем.</span></p>
                        <p class="c62"><span class="c0">Работает в
                                        том числе с Google BigQuery и Google Data
                                        Studio.</span></p>
                        <h5 class="c85 c59" id="h.yibdcnk00lgs"><span class="c4">StreamMyData</span></h5>
                        <p class="c8"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://streammydata.ru/&amp;sa=D&amp;source=editors&amp;ust=1614119598549000&amp;usg=AOvVaw0NumHejvAK05xLbPN-f5PM">streammydata.ru</a></span><span
                                        class="c0"><br><br>Этот сервис
                                        собирает данные
                                        из различных
                                        источников в
                                        одном месте и
                                        представляет их в
                                        удобном виде.
                                        Инструмент
                                        предназначен для
                                        маркетологов,
                                        директоров по
                                        продажам и
                                        владельцев
                                        бизнеса;
                                        позволяет на
                                        основе собранной
                                        информации
                                        построить
                                        сквозную
                                        аналитику и
                                        оценить конечную
                                        эффективность
                                        бизнеса.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">В наличии
                                        тестовый
                                        14-дневный период,
                                        позволяющий
                                        оценить весь
                                        доступный
                                        функционал.</span></p>
                        <p class="c28 c54"><span class="c0"></span></p>
                        <p class="c5"><span class="c4 c20 c26 c38"></span></p>
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 624.00px; height: 266.67px;"><img
                                                alt=""
                                                src="images/image72.png"
                                                style="width: 624.00px; height: 266.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                </div>

                <!-- 104 -->
                <div data-num="104" class="numNUMBER page-mimi" id="container-pagnation104">
                        <h5 class="c12" id="h.vn3qbs2ayass"><span class="c4">Менеджер
                                        Конверсий</span></h5>
                        <h3 class="c28 c59 c65" id="h.c3rzp0wcn936"><span class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://xn--b1adcabbetjgqnfn2afr.xn--p1ai/&amp;sa=D&amp;source=editors&amp;ust=1614119598551000&amp;usg=AOvVaw2KN3UMSPJe7ApfT_viwOiD">менеджерконверсий</a></span><span
                                        class="c4 c20"><a class="c2"
                                                href="https://www.google.com/url?q=https://xn--b1adcabbetjgqnfn2afr.xn--p1ai/&amp;sa=D&amp;source=editors&amp;ust=1614119598551000&amp;usg=AOvVaw2KN3UMSPJe7ApfT_viwOiD">.рф</a></span>
                        </h3>
                        <p class="c8"><span class="c0">Облачный
                                        коннектор
                                        позволяет
                                        передавать
                                        данные о лидах и
                                        транзакциях из CRM в
                                        рекламные
                                        кабинеты и
                                        системы
                                        аналитики —
                                        например, в Google Analytics. Это
                                        позволяет
                                        улучшить работу
                                        автоматических
                                        стратегий
                                        рекламных
                                        &nbsp;систем и
                                        визуализировать
                                        данные &nbsp;в Power BI (сам
                                        сервис выгрузку в
                                        Power BI не производит).</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 680.05px; height: 405.33px;"><img
                                                alt=""
                                                src="images/image73.png"
                                                style="width: 680.05px; height: 405.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h5 class="c12" id="h.eqttw69pfelb"><span class="c4">С</span><a id="id.34g0dwd"></a><span
                                        class="c6">истемы
                                        веб-аналитики</span></h5>
                        <p class="c8"><span class="c4">Системы
                                        веб-аналитики
                                        собирают данные с
                                        сайта
                                        посредством
                                        установленного
                                        счётчика.
                                        Наиболее
                                        популярная
                                        система в мире </span><span class="c4">—</span><span class="c0">&nbsp;Google
                                        Analytics. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">В Рунете
                                        большей
                                        популярностью
                                        пользуется
                                        Яндекс.Метрика, но
                                        обычно на
                                        коммерческие
                                        проекты ставятся
                                        обе системы. Эти
                                        системы собирают
                                        общую информацию
                                        о посетителе и
                                        обычно работают
                                        на основе сессии,
                                        не идентифицируя
                                        человека
                                        персонально. В
                                        этом их
                                        ограничение. </span></p>
                </div>

                <!-- 105 -->
                <div data-num="105" class="numNUMBER page-mimi" id="container-pagnation105">
                        <p class="c8"><span class="c0">Однако, они
                                        являются
                                        необходимой
                                        составляющей и
                                        для систем
                                        сквозной
                                        аналитики по
                                        многим причинам:</span>
                        </p>
                        <ul class="c9 lst-kix_ibng7xenohdh-0 start">
                                <li class="c35 li-bullet-0"><span class="c0">установлены на
                                                большинстве
                                                сайтов (во многом
                                                благодаря
                                                простоте и
                                                бесплатности);</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">предоставляют
                                                функциональность
                                                сбора множества
                                                данных на сайте;</span>
                                </li>
                                <li class="c35 li-bullet-0"><span class="c0">являются
                                                составной
                                                частью
                                                экосистем Гугла
                                                и Яндекса, имея
                                                возможность
                                                получать данные
                                                из их систем
                                                контекстной
                                                рекламы
                                                напрямую;</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">могут
                                                иметь
                                                идентификатор
                                                клиента, который
                                                удобно
                                                использовать в
                                                системе
                                                сквозной
                                                аналитики,
                                                например client ID в Google Analytics.</span></li>
                        </ul>
                        <p class="c46"><span class="c0"></span></p>
                        <p class="c75 c54"><span class="c42 c10 c38"></span></p><a id="id.1jlao46"></a>
                        <h6 class="c16" id="h.h9pp94vtvsbi"><span class="c4">Яндекс.М</span><span
                                        class="c6">етрика</span></h6>
                        <p class="c8"><span class="c4">Яндекс.Метрика,
                                        самая популярная
                                        система
                                        веб-аналитики в
                                        Рунете, тоже
                                        движется в
                                        сторону сквозной
                                        аналитики.
                                        Например,
                                        появилась
                                        интеграция с
                                        популярными
                                        системами
                                        коллтрекинга</span><span class="c0">.</span></p>
                </div>

                <!-- 106 -->
                <div data-num="106" class="numNUMBER page-mimi" id="container-pagnation106">
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 648.00px;"><img
                                                alt="59e53cc7dcff638b31b24d7c.jpg"
                                                src="images/image62.jpg"
                                                style="width: 566.67px; height: 648.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c74"><span class="c4">Для
                                        интеграции с
                                        другими
                                        сервисами и
                                        выгрузки данных, у
                                        Метрики имеется Logs
                                        API. Подробные
                                        инструкции для
                                        работы с ним
                                        доступны на сайте:
                                </span><span class="c4 c20 c111"><a class="c2"
                                                href="https://www.google.com/url?q=https://yandex.ru/dev/metrika/doc/api2/logs/&amp;sa=D&amp;source=editors&amp;ust=1614119598555000&amp;usg=AOvVaw3zN5hZoXYN07AYHbXX-URK">https://yandex.ru/dev/metrika/doc/api2/logs/</a></span>
                        </p>
                        <p class="c74"><span class="c0">&nbsp;</span></p>
                </div>

                <!-- 107 -->
                <div data-num="107" class="numNUMBER page-mimi" id="container-pagnation107">
                        <h6 class="c16" id="h.u2pslk7r4572"><span class="c4">Google analytics </span></h6>
                        <p class="c57"><span class="c4 c10">Google Analytics</span><span class="c4">, с</span><span
                                        class="c4">истема
                                        аналитики от&nbsp;Google.
                                        Одна из&nbsp;самых
                                        популярных
                                        систем
                                        веб-аналитики
                                        в&nbsp;мире. Бесплатна
                                        в&nbsp;базовой версии.
                                        Позволяет гибко
                                        настраивать </span><span class="c4">отчёты</span><span class="c0">.
                                        Широкая
                                        поддержка
                                        агентствами
                                        и&nbsp;сторонними
                                        специалистам.</span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 181.33px;"><img
                                                alt="5d42ddb72589ef0007a81581.jpg"
                                                src="images/image63.jpg"
                                                style="width: 566.67px; height: 181.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 700.00px; height: 420.00px;"><img
                                                alt=""
                                                src="images/image3.png"
                                                style="width: 700.00px; height: 420.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Имеет
                                        сквозной
                                        идентификатор Client ID,
                                        7&nbsp;встроенных
                                        моделей
                                        атрибуции,
                                        включая
                                        мультиканальные.</span>
                        </p>
                </div>

                <!-- 108 -->
                <div data-num="108" class="numNUMBER page-mimi" id="container-pagnation108">
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">К&nbsp;сожалению,
                                        сама по&nbsp;себе Google Analytics
                                        не&nbsp;является
                                        системой
                                        сквозной
                                        аналитики. Её
                                        можно </span><span class="c4">донастроить</span><span
                                        class="c0">&nbsp;и&nbsp;научить
                                        считать ROI, либо
                                        интегрировать
                                        с&nbsp;другими
                                        структурами и
                                        устройствами.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c71"><span class="c4">Систему п</span><span class="c0">роще
                                        использовать как
                                        дополнительный
                                        инструмент,
                                        нежели
                                        отстраивать
                                        сквозную
                                        аналитику на&nbsp;её
                                        основе.</span></p>
                        <p class="c14"><span class="c0"></span></p>
                        <p class="c71"><span class="c0">В декабре 2020-го
                                        года вышла версия
                                        4 со
                                        множественными
                                        улучшениями:</span></p>
                        <p class="c14"><span class="c0"></span></p>



                        <ul class="c9 lst-kix_xteu8tv7iyt6-0 start">
                                <li class="c35 li-bullet-0"><span class="c0">Кросс-платформенное
                                                отслеживание. Google Analytics 4
                                                собирает данные
                                                по сайтам и
                                                мобильным
                                                приложениям и
                                                объединяет их в
                                                единой
                                                отчетности.</span></li>
                        </ul>
                        <h5 class="c50 c68" id="h.ei5wd87pe6f6"><span class="c0"></span></h5>
                </div>

                <!-- 109 -->
                <div data-num="109" class="numNUMBER page-mimi" id="container-pagnation109">
                        <ul class="c9 lst-kix_dbx0tacrcvev-0 start">
                                <li class="c39 li-bullet-0">
                                        <h5 id="h.2q8awvp3ez5d" style="display:inline"><span class="c0">Улучшенная
                                                        статистика. В
                                                        отличие от Universal Analytics,
                                                        где собирались
                                                        данные только о
                                                        просмотрах
                                                        страниц, Google Analytics 4
                                                        позволяет
                                                        посмотреть
                                                        глубину
                                                        прокрутки,
                                                        исходящие клики,
                                                        поиск по сайту,
                                                        взаимодействия
                                                        с видео и т.д.</span></h5>
                                </li>
                        </ul>
                        <h5 class="c50 c68" id="h.vw1noxk6ds82"><span class="c0"></span></h5>
                        <ul class="c9 lst-kix_8xro39ufeh8w-0 start">
                                <li class="c39 li-bullet-0">
                                        <h5 id="h.lmlp5obxzs8u" style="display:inline"><span class="c0">Мощные
                                                        инструменты
                                                        аналитики.
                                                        «Центр анализа»
                                                        Google Analytics 4 позволяет
                                                        формировать
                                                        собственные
                                                        отчеты и
                                                        проводить
                                                        анализ по любым
                                                        метрикам.
                                                        Например,
                                                        анализировать
                                                        пути
                                                        пользователей,
                                                        проводить
                                                        когортный
                                                        анализ,
                                                        сравнивать
                                                        сегменты,
                                                        добавлять
                                                        собственные
                                                        последовательности
                                                        конверсии и т. д.</span>
                                        </h5>
                                </li>
                        </ul>
                        <h5 class="c50 c68" id="h.j0fjg7nlih7b"><span class="c0"></span></h5>
                        <ul class="c9 lst-kix_tqe6jm7hakww-0 start">
                                <li class="c39 li-bullet-0">
                                        <h5 id="h.q91cz1topz4x" style="display:inline"><span class="c0">Глубокий
                                                        анализ
                                                        вовлеченности
                                                        пользователей. В
                                                        Google Analytics 4 нет такого
                                                        понятия как
                                                        «показатель
                                                        отказов». Вместо
                                                        этого
                                                        используется
                                                        новый способ
                                                        отслеживания
                                                        вовлеченности.
                                                        Он позволяет
                                                        узнать, с каких
                                                        устройств люди
                                                        чаще всего
                                                        делают покупки,
                                                        какой контент
                                                        предпочитают
                                                        посетители
                                                        разного
                                                        возраста,
                                                        пользователи
                                                        какой страны
                                                        чаще
                                                        просматривают
                                                        видео и т. д.</span></h5>
                                </li>
                        </ul>
                        <p class="c46"><span class="c42 c10 c38"></span></p>
                        <ul class="c9 lst-kix_s4awubqasj85-0 start">
                                <li class="c39 li-bullet-0">
                                        <h5 id="h.p0ki6d9tccjq" style="display:inline"><span class="c0">Прогнозирование
                                                        склонности к
                                                        покупке. На
                                                        основе анализа
                                                        поведения
                                                        пользователей
                                                        они
                                                        сегментируются
                                                        на тех, кто в
                                                        течение 7 дней
                                                        совершит
                                                        покупку и на тех,
                                                        кто уйдет ни с
                                                        чем.</span></h5>
                                </li>
                        </ul>
                        <hr style="page-break-before:always;display:none;"><a id="id.2iq8gzs"></a><a
                                id="id.43ky6rz"></a>
                </div>

                <!-- 110 -->
                <div data-num="110" class="numNUMBER page-mimi" id="container-pagnation110">
                        <h5 class="c50 c103" id="h.9rnah3czbmpl"><span class="c6">BI-Системы</span></h5>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c90 c70"><span class="c73 c60 c48">Business intelligence</span><span
                                        class="c4 c60 c48">&nbsp;(</span><span class="c4 c60 c48">сокращённо</span><span
                                        class="c4 c60 c48">&nbsp;</span><span class="c73 c60 c48">BI</span><span
                                        class="c4 c60 c48">) —
                                        обозначение
                                        компьютерных
                                        методов и
                                        инструментов для
                                        организаций,
                                        обеспечивающих
                                        перевод
                                        транзакционной
                                        деловой
                                        информации в </span><span class="c4 c60 c48">человекочитаемую</span><span
                                        class="c4 c60 c48">&nbsp;форму,
                                        пригодную для </span><span class="c4 c48 c120"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/%25D0%2591%25D0%25B8%25D0%25B7%25D0%25BD%25D0%25B5%25D1%2581-%25D0%25B0%25D0%25BD%25D0%25B0%25D0%25BB%25D0%25B8%25D0%25B7&amp;sa=D&amp;source=editors&amp;ust=1614119598561000&amp;usg=AOvVaw2_2G9oeOgD7e-XOXF6dzKC">бизнес-анализа</a></span><span
                                        class="c4 c18 c60">, а также
                                        средства для
                                        массовой работы с
                                        такой
                                        обработанной
                                        информацией.</span></p>
                        <p class="c90 c70"><span class="c4 c18 c60">Цель BI —
                                        интерпретировать
                                        большое
                                        количество
                                        данных, заостряя
                                        внимание лишь на
                                        ключевых
                                        факторах
                                        эффективности,
                                        моделируя исход
                                        различных
                                        вариантов
                                        действий,
                                        отслеживая
                                        результаты
                                        принятия
                                        решений.</span></p>
                        <p class="c70 c90"><span class="c4 c20 c48 c111"><a class="c2"
                                                href="https://www.google.com/url?q=https://ru.wikipedia.org/wiki/Business_Intelligence&amp;sa=D&amp;source=editors&amp;ust=1614119598562000&amp;usg=AOvVaw1bPuIlsA43GkiuyHswOlEL">https://ru.wikipedia.org/wiki/Business_Intelligence</a></span>
                        </p>
                        <p class="c54 c70 c122"><span class="c4 c10 c60"></span></p>
                        <p class="c71"><span class="c0">BI-системы или
                                        системы
                                        визуализации
                                        данных,
                                        применяются не
                                        только в
                                        маркетинге, с их
                                        использованием
                                        визуализируются
                                        любые данные из
                                        любых
                                        подразделений
                                        компании,
                                        будь-то:</span></p>
                        <ul class="c9 lst-kix_51ayb31m0it9-0 start">
                                <li class="c35 li-bullet-0"><span class="c0">маркетинг</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">продажи</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">логистика</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">HR</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">финансы</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">управленческий
                                                учёт</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">бухгалтерия</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">складской
                                                учёт</span></li>
                                <li class="c35 li-bullet-0"><span class="c0">стратегическое
                                                планирование</span></li>
                        </ul>
                        <p class="c75 c54 c96"><span class="c0"></span></p>
                        <p class="c75 c96 c123"><span class="c4">Всё что
                                        можно
                                        визуализировать
                                        в виде графиков,
                                        диаграмм, все
                                        данные, имеющие
                                        числовые
                                        значения, могут
                                        быть
                                        визуализированы
                                        при помощи BI. Такие
                                        системы в
                                        основном
                                        использует
                                        крупный и средний
                                        бизнес, но и малый
                                        и даже
                                        микробизнес
                                        также успешно
                                        работает с
                                        BI-системами,
                                        пускай и
                                        ограничиваясь
                                        отдельными </span><span class="c4">отчётами</span><span class="c4">,
                                        без комплексного
                                        внедрения и
                                        построения
                                        единой DWH. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">На&nbsp;рынке
                                        существует
                                        множество
                                        BI-систем, но&nbsp;число
                                        лидеров
                                        уменьшилось, если
                                        судить по&nbsp;отчёту
                                        Gather.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 111 -->
                <div data-num="111" class="numNUMBER page-mimi" id="container-pagnation111">
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 784.25px; height: 782.67px;"><img
                                                alt=""
                                                src="images/image42.png"
                                                style="width: 784.25px; height: 782.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c0">Сейчас
                                        BI-системы
                                        образовали
                                        лидирующую
                                        тройку:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_vici9jmjdhc9-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Microsoft Power&nbsp;BI</span></li>
                                <li class="c17 li-bullet-7"><span
                                                class="c0">Qlik&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                (QlikView
                                                и Qlik Sense)</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Tableau</span></li>
                        </ul>
                </div>

                <!-- 112 -->
                <div data-num="112" class="numNUMBER page-mimi" id="container-pagnation112">
                        <p class="c75 c54"><span class="c0"></span></p>
                        <p class="c75 c96"><span class="c0">Рассмотрим
                                        эти системы
                                        подробнее</span></p><a id="id.xvir7l"></a>
                        <h6 class="c16" id="h.twe7kccynh9k"><span class="c6">Microsoft Power&nbsp;BI</span></h6>
                        <p class="c8"><span class="c0">Эффективная
                                        служба
                                        бизнес-аналитики
                                        от&nbsp;всеми
                                        известной
                                        корпорации
                                        с&nbsp;мировым именем.
                                        Выбор средних
                                        и&nbsp;крупных
                                        компаний. По
                                        оценка автора,
                                        наиболее
                                        популярная
                                        BI-система в
                                        России.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Краткий
                                        перечень
                                        ключевых
                                        особенностей
                                        сервиса:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ol class="c9 lst-kix_anebq4wy8skk-0 start" start="1">
                                <li class="c17 li-bullet-1"><span class="c0">Визуализация
                                                и&nbsp;наглядность
                                                представления
                                                полученной
                                                информации
                                                в&nbsp;предельно
                                                понятном виде;</span></li>
                                <li class="c17 li-bullet-1"><span class="c0">Возможность
                                                как локальной,
                                                так и&nbsp;облачной
                                                работы
                                                с&nbsp;данными;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Простая
                                                и&nbsp;эффективная
                                                реализация
                                                совместного
                                                доступа
                                                к&nbsp;панелям
                                                мониторинга
                                                и&nbsp;интерактивным
                                                отчётам;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Быстрое
                                                извлечение
                                                данных из&nbsp;любых
                                                источников
                                                и&nbsp;обновление их
                                                в&nbsp;режиме
                                                реального
                                                времени;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Широкие
                                                возможности
                                                делегирования
                                                и&nbsp;масштабирования
                                                задач;</span></li>
                        </ol>
                        <p class="c5"><span class="c0"></span></p>
                        <h6 class="c16" id="h.n91vhsgplbme">
                                style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000;
                                transform:
                                rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);
                                width: 566.67px;
                                height: 314.67px;"&gt;<img alt="5d5b003dad7e130007c70b7f.jpg"
                                        src="images/image50.jpg"
                                        style="width: 566.67px; height: 314.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                        title=""></h6>
                </div>

                <!-- 113 -->
                <div data-num="113" class="numNUMBER page-mimi" id="container-pagnation113">
                        <h6 class="c16" id="h.n91vhsgplbme"><span class="c4"><br></span><a id="id.3hv69ve"></a><span
                                        class="c4">Qlikview,
                                </span><span class="c4">Qliksense</span></h6>
                        <p class="c8"><span class="c0">Две очень
                                        похожих
                                        BI-платформы
                                        от&nbsp;шведской
                                        компании QlikTech, уже
                                        более 26&nbsp;лет
                                        успешно
                                        представляет
                                        свои продукты
                                        на&nbsp;рынке. Оба
                                        программных
                                        комплекса
                                        предназначены
                                        для сбора,
                                        систематизации
                                        и&nbsp;накопления
                                        данных для
                                        бизнес-аналитики.
                                        Визуализация
                                        полученных
                                        результатов
                                        достигается при
                                        помощи удобного
                                        набора различных
                                        графиков, таблиц
                                        и&nbsp;диаграмм.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">QlickView</span><span class="c0">&nbsp;— это
                                        первый
                                        из&nbsp;продуктов
                                        линейки, и,
                                        по&nbsp;заявлению
                                        компании, для
                                        эффективной
                                        работы с&nbsp;ним
                                        не&nbsp;требуется
                                        большой опыт
                                        в&nbsp;IT-индустрии.
                                        Платформа
                                        поддерживает
                                        самые разные
                                        источники данных,
                                        начиная
                                        с&nbsp;текстовых, XML или
                                        Excel файлов
                                        и&nbsp;заканчивая
                                        базами данных
                                        и&nbsp;ресурсами
                                        в&nbsp;сети.
                                        ПО&nbsp;компании
                                        использует
                                        запатентованное
                                        ядро и
                                        собственный&nbsp;формат
                                        хранения данных QVD,
                                        и&nbsp;всё вместе это
                                        обеспечивает
                                        конкурентно
                                        высокую скорость
                                        работы.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">QlickSense</span><span class="c0">&nbsp;—
                                        второй продукт
                                        компании,
                                        и&nbsp;на&nbsp;правах
                                        наследника он
                                        обладает более
                                        расширенным
                                        функционалом,
                                        а&nbsp;порог
                                        вхождения для
                                        работы
                                        с&nbsp;платформой
                                        стал ещё ниже.
                                        Основные отличия
                                        заключаются
                                        в&nbsp;использовании
                                        ассоциативного
                                        поиска
                                        в&nbsp;оперативной
                                        памяти, а&nbsp;также
                                        в&nbsp;более
                                        самостоятельной
                                        работе
                                        непосредственного
                                        бизнес-пользователя
                                        без
                                        необходимости
                                        привлечения
                                        квалифицированного
                                        IT-специалиста.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 114 -->
                <div data-num="114" class="numNUMBER page-mimi" id="container-pagnation114">
                        <h6 class="c16" id="h.n02o02h665np"><span class="c4"><br></span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 534.67px;"><img
                                                alt="5d5b01dbad7e130007c70bb8.jpg"
                                                src="images/image75.jpg"
                                                style="width: 566.67px; height: 534.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h6>
                        <h6 class="c16" id="h.n02o02h665np"><span class="c4"><br></span><a id="id.1x0gk37"></a><span
                                        class="c6">Tableau</span></h6>
                        <p class="c8"><span class="c0">Комплексная
                                        интерактивная
                                        аналитическая
                                        система родом
                                        из&nbsp;Калифорнии&nbsp;—
                                        это ещё один
                                        широко известный
                                        представитель
                                        семейства
                                        BI-платформ.
                                        Благодаря
                                        фирменным
                                        инновационным
                                        технологиям Data Engine и&nbsp;VizQL
                                        скорость
                                        и&nbsp;эффективность
                                        работы с&nbsp;данными
                                        в&nbsp;этом
                                        программном
                                        комплексе
                                        не&nbsp;может быть
                                        переоценена.
                                        И&nbsp;это
                                        не&nbsp;единственные
                                        отличительные
                                        особенности
                                        данного
                                        продукта:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_45c5373ic06f-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">Дружелюбное
                                                отношение
                                                к&nbsp;начинающему
                                                бизнес-пользователю;</span>
                                </li>
                                <li class="c17 li-bullet-1"><span class="c0">Гибкие
                                                в&nbsp;настройке
                                                и&nbsp;простые
                                                в&nbsp;обращении
                                                инструменты;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Практически
                                                любой формат
                                                обрабатываемых
                                                данных;</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Быстрое
                                                создание
                                                интерактивных
                                                дашбордов
                                                методом drag’n’drop;</span></li>
                                <li class="c17 li-bullet-1"><span class="c4">Оперативное
                                                формирование
                                                и&nbsp;выгрузка </span><span class="c4">отчётов</span><span
                                                class="c0">&nbsp;любой
                                                сложности;</span></li>
                        </ul>
                </div>

                <!-- 115 -->
                <div data-num="115" class="numNUMBER page-mimi" id="container-pagnation115">
                        <li class="c17 li-bullet-2"><span class="c4">Тандем
                                        технологий Data Engine
                                        и&nbsp;</span><span class="c4">VizQL</span><span class="c0">&nbsp;обеспечивает
                                        мгновенное
                                        извлечение
                                        данных
                                        и&nbsp;построение
                                        эффектной
                                        визуализации
                                        в&nbsp;режиме
                                        реального
                                        времени;</span></li>
                        <li class="c17 li-bullet-7"><span class="c0">Быстрая
                                        установка
                                        и&nbsp;внедрение.</span></li>

                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h6 class="c16" id="h.664qaikftvnt"><span class="c4"><br></span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 378.67px;"><img
                                                alt="5d5b08a9a48f540006ae107e.jpg"
                                                src="images/image2.jpg"
                                                style="width: 566.67px; height: 378.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></h6>
                        <h6 class="c16" id="h.664qaikftvnt"><span class="c4"><br></span><a id="id.4h042r0"></a><span
                                        class="c6">Google Data
                                        Studio</span></h6>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 364.50px; height: 182.25px;"><img
                                                alt=""
                                                src="images/image25.png"
                                                style="width: 364.50px; height: 182.25px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span class="c4">Отдельно
                                        стоит выделить Google Data
                                        Studio&nbsp;— бесплатный
                                        инструмент,
                                        хорошо
                                        интегрированный
                                        в&nbsp;экосистему Google.
                                        Продукт&nbsp;быстро
                                        развивается и для
                                        малого и среднего
                                        бизнеса
                                        составляет
                                        серьезную
                                        конкуренцию Microsoft Power BI. </span>
                        </p>
                </div>

                <!-- 116 -->
                <div data-num="116" class="numNUMBER page-mimi" id="container-pagnation116">
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 438.67px;"><img
                                                alt="5c215615e3d9620700964746.jpg"
                                                src="images/image59.jpg"
                                                style="width: 566.67px; height: 438.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c8"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 624.00px; height: 258.67px;"><img
                                                alt=""
                                                src="images/image86.png"
                                                style="width: 624.00px; height: 258.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h4 class="c112 c59 c65 c110" id="h.i1ja46vb31if"><span class="c6">Другие
                                        компании</span></h4>
                        <p class="c8"><span class="c4">На&nbsp;рынке
                                        существует
                                        некоторое
                                        количество
                                        компаний,
                                        внедряющих
                                        BI-системы. По&nbsp;сути,
                                </span><span class="c4">они
                                        настраивают
                                        сквозную </span><span class="c0">аналитику,
                                        но&nbsp;предоставляют
                                        не&nbsp;SAAS-сервис, а
                                        услугу: внедрение
                                        сервиса. Зачастую
                                        трудно отличить
                                        SAAS-сервис
                                        от&nbsp;агентств и
                                        интеграторов.
                                        Многие агентства
                                        имеют
                                        собственные
                                        разработки, но
                                        предлагают их
                                        только своим
                                        клиентам в рамках
                                        более
                                        комплексного
                                        пакета услуг.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 117 -->
                <div data-num="117" class="numNUMBER page-mimi" id="container-pagnation117">
                        <p class="c8"><span class="c0">Резюмируя,
                                        если вы выбираете
                                        BI-систему, можно
                                        рекомендовать:</span></p>
                        <ol class="c9 lst-kix_6f6iq1c5zjwj-0 start" start="1">
                                <li class="c35 li-bullet-0"><span class="c0">Google Data Studio для
                                                несложных
                                                маркетинговых
                                                отчетов,
                                                веб-аналитики
                                                (связки с Google Analytics, Big Query), в
                                                целом, для малого
                                                и среднего
                                                бизнеса.</span></li>
                                <li class="c35 li-bullet-0"><span class="c4">Microsoft Power BI для
                                                более
                                                комплексных
                                                решений, когда
                                                требуется
                                                визуализировать
                                                не только
                                                маркетинг, когда
                                                в компании уже
                                                используются
                                                продукты Microsoft (Dynamics, Sharepoint, Azure),
                                                в целом, для
                                                крупного
                                                бизнеса.</span></li>
                        </ol><a id="id.2w5ecyt"></a><a id="id.1baon6m"></a>
                        <h5 class="c59 c103 c114" id="h.h1294z6874u"><span class="c6">Другие
                                        компоненты
                                        системы</span></h5><a id="id.3vac5uf"></a>
                        <h3 class="c47"><span class="c6">CRM</span></h3>
                        <p class="c8"><span class="c0">Основным
                                        источником
                                        данных для
                                        системы
                                        аналитики
                                        становится CRM.
                                        Существует
                                        множество
                                        вариантов,
                                        познакомимся с
                                        &nbsp;самыми
                                        известными.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 118 -->
                <div data-num="118" class="numNUMBER page-mimi" id="container-pagnation118">
                        <p class="c49"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 596.28px; height: 623.50px;"><img
                                                alt=""
                                                src="images/image83.png"
                                                style="width: 596.28px; height: 623.50px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span><span class="c0">Gartner CRM Magic Quadrant</span></p>
                        <p class="c8"><span class="c0">CRM делятся
                                        на&nbsp;облачные
                                        и&nbsp;коробочные,
                                        на&nbsp;решения для
                                        крупного
                                        и&nbsp;малого бизнеса
                                        и&nbsp;т.&nbsp;д.&nbsp;Gartner CRM Magic Quadrant
                                        показывает
                                        популярные
                                        в&nbsp;мире системы,
                                        однако из&nbsp;них
                                        лишь часть имеет
                                        популярность
                                        в&nbsp;России. В&nbsp;то&nbsp;же
                                        время у&nbsp;нас есть
                                        собственные
                                        решения, которые
                                        в&nbsp;мировой топ
                                        не&nbsp;попадают.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Популярные
                                        в&nbsp;России
                                        облачные
                                        решения:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_rcm4nsit15g7-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Битрикс24</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">amoCRM</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 119 -->
                <div data-num="119" class="numNUMBER page-mimi" id="container-pagnation119">
                        <p class="c8"><span class="c0">Менее
                                        популярные:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_8byihk5x848s-0 start">
                                <li class="c17 li-bullet-7"><span class="c4">ReatailCRM</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Мегаплан</span>
                                </li>
                                <li class="c17 li-bullet-7"><span class="c0">BPM Online</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Наиболее
                                        известные
                                        коробочные
                                        решения:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_ontm8lvg5nf6-0 start">
                                <li class="c33 li-bullet-2">
                                        <h6 id="h.u0ut66yhuo3" style="display:inline"><span
                                                        class="c0">1C:&nbsp;CRM</span></h6>
                                </li>
                                <li class="c17 li-bullet-7"><span class="c0">Битрикс24</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Самое
                                        популярное
                                        решение в&nbsp;мире:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_vjevxi6plz7y-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">SalesForce</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Решения для
                                        крупного
                                        бизнеса:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_lpdw8knggqg2-0 start">
                                <li class="c17 li-bullet-2"><span class="c0">Microsoft Dynamics</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">SAP</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Из&nbsp;других
                                        решений можно
                                        вспомнить
                                        удобные PipeDrive и&nbsp;SugarCRM
                                        с&nbsp;открытым
                                        исходным кодом.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Также
                                        в&nbsp;большинстве
                                        индустрий
                                        существуют
                                        специализированные
                                        отраслевые
                                        системы,
                                        адаптированные
                                        под конкретные
                                        узкие задачи.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Обзор рынка
                                        CRM-систем выходит
                                        за&nbsp;рамки нашего
                                        обсуждения,
                                        поэтому подробно
                                        рассмотрим
                                        только 1&nbsp;систему.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <h3 class="c8" id="h.naou7cu88x58"><span class="c11 c10">Битрикс24</span>
                        </h3>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c71"><span class="c4">Битрикс24 —
                                        одна из самых
                                        популярных в
                                        России CRM, ее
                                        используют
                                        множество
                                        компаний малого,
                                        среднего и даже
                                        крупного бизнеса.
                                        Изучим не&nbsp;весь ее
                                        функционал,
                                        а&nbsp;именно
                                        возможности
                                        маркетинговой
                                        аналитики.</span></p>
                </div>

                <!-- 120 -->
                <div data-num="120" class="numNUMBER page-mimi" id="container-pagnation120">
                        <p class="c71"><span class="c0">В системе
                                        имеется модуль
                                        “Сквозная
                                        аналитика”,
                                        позволяющий
                                        подключить
                                        рекламные
                                        системы
                                        Яндекс.Директ, Google Ads и
                                        системы
                                        веб-аналитики
                                        Яндекс.Метрику и Google
                                        Analytics.</span></p>
                        <p class="c14"><span class="c0"></span></p>
                        <p class="c71"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 679.69px; height: 309.50px;"><img
                                                alt=""
                                                src="images/image20.png"
                                                style="width: 679.69px; height: 309.50px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c14"><span class="c0"></span></p>
                        <p class="c71"><span class="c4">Данная
                                        аналитика
                                        работает на базе
                                        UTM-меток, без
                                        присвоения
                                        клиенту
                                        идентификатора,
                                        это уменьшает </span><span class="c4">её</span><span
                                        class="c4">&nbsp;функциональность
                                        и точность в
                                        сравнении со
                                        “взрослыми”
                                        системами. Однако,
                                        бесплатность
                                        модуля (в рамках
                                        платной CRM) делает
                                        её популярной и в
                                        качестве
                                        базового
                                        инструмента, она
                                        безусловно,
                                        полезна.</span></p>
                </div>

                <!-- 121 -->
                <div data-num="121" class="numNUMBER page-mimi" id="container-pagnation121">
                        <h6 class="c112 c59 c110" id="h.tvamq0y21do7"><span class="c6">Коллтрекинг</span></h6>
                        <p class="c76 c59"><span class="c0">Хотя
                                        современные
                                        сервисы
                                        коллтрекинга и
                                        стараются стать
                                        полноценными
                                        системами
                                        сквозной
                                        аналитики, они не
                                        могут
                                        игнорировать
                                        спрос на
                                        интеграцию в
                                        другие системы.
                                        Также есть
                                        сервисы,
                                        предоставляющие
                                        только
                                        коллтрекинг.</span></p>
                        <p class="c76 c59"><span class="c6">IP-телефония</span></p>
                        <p class="c76 c59"><span class="c4">Это может
                                        быть как
                                        виртуальная АТС
                                        на базе облачного
                                        решения, так и ПО,
                                        размещенное на
                                        собственных
                                        серверах, чаще
                                        всего — </span><span class="c4">Arterisk</span><span class="c0">.</span>
                        </p>
                        <p class="c76 c59"><span class="c0">Из облачных
                                        решений
                                        популярны:</span></p>
                        <ul class="c9 lst-kix_cb3q9hskgps3-0 start">
                                <li class="c58 li-bullet-0"><span class="c0">Манго-офис;</span></li>
                                <li class="c58 li-bullet-0"><span class="c0">Sipuni;</span></li>
                                <li class="c58 li-bullet-0"><span class="c0">onlinePBX;</span></li>
                                <li class="c58 li-bullet-0"><span class="c0">Gravitel;</span></li>
                                <li class="c58 li-bullet-0"><span class="c0">VoxImplant (встроен
                                                в Битрикс24)</span></li>
                                <li class="c58 li-bullet-0"><span class="c0">Zadarma.</span></li>
                        </ul>
                        <h6 class="c59 c110 c112" id="h.9upqwq6ovvhp"><span class="c6">Виджеты
                                        на сайт</span></h6>
                        <p class="c59 c76"><span class="c0">Онлайн-консультанты,
                                        сервисы
                                        обратного звонка,
                                        виджеты
                                        интеграции с
                                        соцсетями
                                        достаточно
                                        разнообразны, а их
                                        интеграция в
                                        общую систему
                                        зачастую
                                        затруднительна
                                        из-за ограничений
                                        API.</span></p>
                        <p class="c76 c59"><span class="c0">&nbsp;Примеры
                                        популярных
                                        решений:</span></p>
                        <p class="c5 c59"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_b6vu1bw6e7x1-0 start">
                                <li class="c17 c59 li-bullet-2"><span class="c0">Jivosite</span></li>
                                <li class="c17 c59 li-bullet-7"><span class="c0">LiveTex</span></li>
                                <li class="c17 c59 li-bullet-2"><span class="c0">Envybox</span></li>
                                <li class="c17 c59 li-bullet-2"><span class="c0">Redhelper + RedConnect</span></li>
                                <li class="c17 c59 li-bullet-1"><span class="c4">Callbackhunter</span></li>
                        </ul>
                </div>

                <!-- 122 -->
                <div data-num="122" class="numNUMBER page-mimi" id="container-pagnation122">
                        <p class="c41"><span class="c0"></span></p>
                        <h1 class="c100 c59 c65" id="h.4n7pneqnea1y"><span class="c3">Рекомендации
                                        при внедрении
                                        сквозной
                                        аналитики</span></h1>
                        <p class="c8"><span class="c0">Подводя итог,
                                        если вы
                                        загорелись идеей
                                        внедрения
                                        сквозной
                                        аналитики,
                                        помните:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c73">1.</span><span class="c4">&nbsp;Самое
                                        сложное&nbsp;—
                                        не&nbsp;настроить
                                        BI-систему для
                                        отображения
                                        нужных графиков,
                                        а&nbsp;внедрить CRM так,
                                        чтобы все данные
                                        проходили через
                                </span><span class="c4">неё</span><span class="c0">. Если CRM
                                        уже внедрена,
                                        построение
                                        сквозной
                                        аналитики сильно
                                        упрощается.
                                        Но&nbsp;только если
                                        это популярная
                                        облачная CRM
                                        из&nbsp;небольшого
                                        списка,
                                        а&nbsp;не&nbsp;некая
                                        малоизвестная
                                        и&nbsp;не&nbsp;имеющая API.
                                        Если у&nbsp;вас не
                                        популярное
                                        решение без API,
                                        сложность задачи
                                        становится
                                        равносильной
                                        оной при
                                        отсутствии&nbsp;CRM.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c73">2.</span><span class="c4">&nbsp;Чтобы
                                        от&nbsp;CRM была
                                        реальная польза,
                                        ей следует быть
                                        омниканальной,
                                        в&nbsp;идеале все лиды
                                        со&nbsp;всех каналов
                                        должны попадать
                                        в&nbsp;</span><span class="c4">неё</span><span class="c0">&nbsp;автоматически.
                                        Но&nbsp;при этом CRM
                                        может успешно
                                        работать без
                                        интеграции с&nbsp;ERP.
                                        Если у&nbsp;вас старая
                                        1С, и&nbsp;придётся
                                        выставлять счета
                                        вручную без
                                        синхронизации, то
                                        это проблема,
                                        которая несильно
                                        мешает внедрению
                                        CRM и&nbsp;работе
                                        в&nbsp;целом.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c73">3.</span><span class="c0">&nbsp;Прежде
                                        чем начинать,
                                        нужно быть
                                        готовыми
                                        к&nbsp;сложностям
                                        и&nbsp;к&nbsp;тому, что
                                        «интеграции
                                        в&nbsp;1&nbsp;клик»
                                        работают
                                        не&nbsp;всегда
                                        и&nbsp;не&nbsp;всегда дают
                                        полную
                                        интеграцию
                                        в&nbsp;нужном виде,
                                        а&nbsp;значит только API,
                                        только хардкор.
                                        Готовых решений
                                        нет ни у&nbsp;кого.
                                        У&nbsp;всех своя
                                        специфика,
                                        но&nbsp;даже на&nbsp;базе
                                        самых популярных
                                        CRM (Битрикс и&nbsp;amo),
                                        самой популярной
                                        системы сквозной
                                        аналитики (Roistat),
                                        самого
                                        популярного
                                        движка сайта
                                        (Битрикс), самой
                                        популярной
                                        SIP-телефонии, самых
                                        популярных
                                        консультантов
                                        (Живосайт или Livetex)&nbsp;—
                                        нет работающей
                                        интеграции всего
                                        и&nbsp;вся из&nbsp;коробки
                                        так, как этого&nbsp;бы
                                        хотелось.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 123 -->
                <div data-num="123" class="numNUMBER page-mimi" id="container-pagnation123">
                        <p class="c8"><span class="c73">4.</span><span class="c0">&nbsp;Если
                                        вы&nbsp;— владелец
                                        бизнеса, сначала
                                        оцените, сколько
                                        времени и&nbsp;денег
                                        уйдет, потом
                                        умножьте
                                        на&nbsp;3&nbsp;и&nbsp;подумайте,
                                        стоит&nbsp;ли делать
                                        сейчас или позже.
                                        Стоит&nbsp;ли делать
                                        всё сразу
                                        (внедрять CRM,
                                        запускать
                                        рекламу
                                        и&nbsp;настраивать
                                        сквозную
                                        аналитику) или&nbsp;же
                                        можно по&nbsp;очереди
                                        (сначала CRM
                                        и&nbsp;реклама).
                                        Сквозная
                                        аналитика нужна,
                                        когда у&nbsp;вас много
                                        каналов
                                        привлечения
                                        трафика. Если
                                        у&nbsp;вас пока только
                                        Яндекс.Директ, то
                                        выгодней сначала
                                        подключить Google.Ads
                                        и&nbsp;добиться там
                                        схожей стоимости
                                        лида, а&nbsp;уже потом
                                        настраивать
                                        сложные системы.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c73">5.</span><span class="c0">&nbsp;Не&nbsp;думайте,
                                        что в&nbsp;больших
                                        кампаниях дела
                                        обстоят лучше.
                                        Крупный бизнес
                                        вообще не&nbsp;отдаст
                                        данные из&nbsp;CRM
                                        стороннему
                                        сервису (защита
                                        персональных
                                        данных). Поэтому
                                        маркетологи
                                        в&nbsp;брендах думают
                                        в&nbsp;категориях
                                        обезличенных
                                        сегментов,
                                        а&nbsp;не&nbsp;о&nbsp;user_id. Даже
                                        в&nbsp;крупном
                                        ритейле бывает
                                        так, что
                                        информация
                                        о&nbsp;маркетинговых
                                        акциях заносится
                                        в разное
                                        ПО&nbsp;(кассовое, CRM
                                        и&nbsp;т.д.), и&nbsp;нет
                                        единой базы, ROI
                                        акций
                                        не&nbsp;считается.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c73">6.</span><span class="c0">&nbsp;Последнее
                                        и&nbsp;главное.
                                        Несмотря на&nbsp;все
                                        сложности,
                                        сквозная
                                        аналитика
                                        всё-таки жизненно
                                        необходима для
                                        построения
                                        бизнеса
                                        в&nbsp;условиях
                                        высокой
                                        конкуренции.</span></p><a id="id.3mzq4wv"></a><a id="id.1302m92"></a>
                        <h2 class="c74 c59 c103"><span class="c22 c10">Пример
                                        кейса с&nbsp;Roistat</span></h2>
                        <p class="c8"><span class="c4">Давайте
                                        отдохнём от
                                        проблем и
                                        сложностей
                                        внедрения и </span><span class="c4">вернёмся</span><span class="c0">&nbsp;к
                                        пользе сквозной
                                        аналитики.
                                        Рассмотрим
                                        на&nbsp;примере
                                        небольшого кейса,
                                        как сквозная
                                        аналитика
                                        помогает
                                        на&nbsp;реальных
                                        проектах,
                                        и&nbsp;почему нельзя
                                        доверять
                                        веб-аналитике,
                                        ориентируясь
                                        только
                                        на&nbsp;стоимость
                                        лида.</span></p>
                        <p class="c5"><span class="c0"></span></p><a id="id.2250f4o"></a>
                </div>

                <!-- 124 -->
                <div data-num="124" class="numNUMBER page-mimi" id="container-pagnation124">
                        <h3 class="c15"><span class="c11 c10">Магазин
                                        автозапчастей
                                        detali15.ru</span></h3>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <ul class="c9 lst-kix_ek4l2d2ly4ix-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">CRM Битрикс24</span></li>
                                <li class="c17 li-bullet-2"><span class="c4">Отдел
                                                продаж </span><span class="c4">—</span><span
                                                class="c0">&nbsp;4&nbsp;менеджера</span></li>
                                <li class="c17 li-bullet-7"><span class="c0">Сайт
                                                Битрикс</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">70%
                                                обращений&nbsp;—
                                                звонки</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">До&nbsp;внедрения
                                        Roistat:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_3gdjakixa1s1-0 start">
                                <li class="c17 li-bullet-7"><span class="c0">Реклама:
                                                Яндекс.Директ</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Бюджет:
                                                ~50&nbsp;тыс. в&nbsp;месяц</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">После
                                        внедрения Roistat:</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_xd8w9ozi289i-0 start">
                                <li class="c17 li-bullet-1"><span class="c0">Запущены
                                                другие
                                                рекламные
                                                каналы: Google Ads,
                                                Яндекс.Маркет;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Увеличено
                                                число каналов
                                                коммуникации:
                                                онлайн-консультант
                                                (Jivosite), ловец лидов (Roistat),
                                                CRM-форма (Битрикс-24);</span>
                                </li>
                                <li class="c17 li-bullet-7"><span class="c0">Все каналы
                                                связаны с&nbsp;CRM
                                                Битрикс24;</span></li>
                                <li class="c17 li-bullet-2"><span class="c0">Выстроены
                                                бизнес-процессы
                                                возобновления
                                                сотрудничества,
                                                отправка счетов
                                                и&nbsp;коммерческих
                                                предложений
                                                из&nbsp;CRM.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Месячный
                                        оборот вырос с 4 до 7
                                        млн. рублей.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Помимо Roistat,
                                        сделаны отчёты
                                        по&nbsp;каналам
                                        коммуникации и по
                                        менеджерам в&nbsp;Power&nbsp;BI.</span>
                        </p>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c0">Но&nbsp;основной
                                        системой всё-таки
                                        является Roistat. Далее
                                        2&nbsp;примера, как Roistat
                                        помогает решить
                                        управленческие
                                        задачи, которые
                                        нельзя верно
                                        отрегулировать
                                        на&nbsp;основании
                                        цены лида.</span></p>
                </div>

                <!-- 125 -->
                <div data-num="125" class="numNUMBER page-mimi" id="container-pagnation125">
                        <p class="c8"><span class="c4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 687.50px; height: 382.33px;"><img
                                                alt=""
                                                src="images/image59.png"
                                                style="width: 687.50px; height: 382.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c43 c54"><span class="c0"></span></p>
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 691.50px; height: 388.09px;"><img
                                                alt=""
                                                src="images/image85.jpg"
                                                style="width: 691.50px; height: 388.09px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                </div>

                <!-- 126 -->
                <div data-num="126" class="numNUMBER page-mimi" id="container-pagnation126">
                        <h3 class="c15"><span class="c11 c10">Инсайты</span></h3>
                        <h3 class="c15 c63"><span class="c11 c10"></span></h3><a id="id.319y80a"></a>
                        <h4 class="c24" id="h.t3uorj4vxq4g"><span class="c78 c10 c38">1. Москва
                                        и&nbsp;регионы</span></h4>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c4">В&nbsp;регионах
                                        трафик дешевле: 4р
                                        за клик в&nbsp;Москве,
                                        2р в&nbsp;регионах.
                                        В&nbsp;итоге, лид
                                        из&nbsp;регионов
                                        стоит дешевле
                                        московского.
                                        Однако, если
                                        посмотреть
                                        на&nbsp;продажи, видно,
                                        что конверсия
                                        по&nbsp;продажам
                                        по&nbsp;этим лидам
                                        гораздо ниже. Люди
                                        ищут магазин в&nbsp;</span><span class="c4">своём</span><span
                                        class="c0">&nbsp;городе
                                        и&nbsp;не&nbsp;соглашаются
                                        на&nbsp;предоплату
                                        и&nbsp;долгое
                                        ожидание
                                        доставки. ROI
                                        московской
                                        рекламной
                                        кампании намного
                                        выше, чем
                                        у&nbsp;региональной:</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <h4 class="c59 c104 c105" id="h.c35gtrfrtzxz">
                                <span><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><a
                                        id="id.1gf8i83"></a><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 181.33px;"><img
                                                alt="59e53cefdcff638b31b24db8.jpg"
                                                src="images/image82.jpg"
                                                style="width: 566.67px; height: 181.33px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span>
                        </h4>
                </div>

                <!-- 127 -->
                <div data-num="127" class="numNUMBER page-mimi" id="container-pagnation127">
                        <h4 class="c59 c104 c105" id="h.c35gtrfrtzxz">
                                <span><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><a
                                        id="id.1gf8i83"></a><span class="c10 c38 c78">2. Директ
                                        против Ads</span>
                        </h4>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c0">В&nbsp;Директе
                                        клик стоит 3&nbsp;рубля,
                                        в&nbsp;Google.Ads 1&nbsp;рубль.
                                        Кажется, нужно
                                        расширять Ads.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Если
                                        посмотреть
                                        стоимость лида,
                                        она примерно
                                        одинакова. </span><span class="c0">Но&nbsp;мы смотрим
                                        глубже и&nbsp;видим:</span></p>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c0">• Конверсия
                                        в&nbsp;продажу
                                        у&nbsp;лидов с&nbsp;Ads&nbsp;хуже</span>
                        </p>
                        <p class="c8"><span class="c0">• Средний
                                        чек&nbsp;ниже</span></p>
                        <p class="c8"><span class="c0">• Повторных
                                        продаж меньше</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Все эти
                                        факторы
                                        уменьшают
                                        итоговую выгоду
                                        привлечения
                                        через Ads. ROI вложений
                                        в&nbsp;Ads ниже.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Отказались&nbsp;ли
                                        мы от&nbsp;Ads? Конечно,
                                        нет. Но&nbsp;снизили
                                        ставки так, что </span><span class="c4">кампании</span><span
                                        class="c0">&nbsp;тратят
                                        намного меньше,
                                        а&nbsp;ROI такой&nbsp;же, как
                                        в&nbsp;Директе.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">В&nbsp;общем,
                                        несмотря
                                        на&nbsp;сложности,
                                        сквозная
                                        аналитика
                                        работает —
                                        и&nbsp;успешно. Roistat&nbsp;—
                                        наверное, самый
                                        простой способ её
                                        попробовать.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 198.67px;"><img
                                                alt="59e53ceddcff638b31b24db5.jpg"
                                                src="images/image69.jpg"
                                                style="width: 566.67px; height: 198.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                </div>

                <!-- 128 -->
                <div data-num="128" class="numNUMBER page-mimi" id="container-pagnation128">
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 182.67px;"><img
                                                alt="59e53cecdcff638b31b24db2.jpg"
                                                src="images/image6.jpg"
                                                style="width: 566.67px; height: 182.67px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 566.67px; height: 208.00px;"><img
                                                alt="59e53ceadcff638b31b24daf.jpg"
                                                src="images/image18.jpg"
                                                style="width: 566.67px; height: 208.00px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p><a id="id.2fk6b3p"></a>
                        <h2 class="c59 c65 c74" id="h.11l6teyy906m"><span class="c22 c10">Будущее</span></h2>
                        <p class="c25"><span class="c42 c10 c38"></span></p>
                        <p class="c8"><span class="c0">Любая метрика
                                        интернет-маркетинга
                                        — это проекция
                                        реального
                                        бизнеса
                                        на&nbsp;цифровой
                                        инструментарий.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 129 -->
                <div data-num="129" class="numNUMBER page-mimi" id="container-pagnation129">
                        <p class="c43"><span
                                        style="display: inline-block; margin: 0.00px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 719.38px; height: 840.50px;"><img
                                                alt=""
                                                src="images/image35.jpg"
                                                style="width: 719.38px; height: 840.50px; margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);"
                                                title=""></span></p>
                        <p class="c43 c54"><span class="c0"></span></p>
                </div>

                <!-- 130 -->
                <div data-num="130" class="numNUMBER page-mimi" id="container-pagnation130">
                        <p class="c8"><span class="c4">Когда-то
                                        давно мы мерили
                                        стоимость показа
                                        и&nbsp;клика, потом CPO (CPL),
                                        потом ROI (ROMI), CAC, сейчас
                                        пытаемся
                                        правильно
                                        атрибутировать
                                        каналы и&nbsp;считать
                                        LTV. Но&nbsp;и&nbsp;это
                                        не&nbsp;предел, а&nbsp;лишь
                                        очень </span><span class="c4">упрощённая</span><span class="c0">&nbsp;схема,
                                        не&nbsp;отражающая
                                        реальность
                                        должным образом.
                                        Бизнесу нужна
                                        прибыль. Эту
                                        банальность
                                        повторяют очень
                                        часто, но&nbsp;хочется
                                        всё-таки
                                        приблизить
                                        имеющийся
                                        инструментарий
                                        к&nbsp;конечной
                                        задаче&nbsp;—
                                        максимизации
                                        прибыли.</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Что&nbsp;же
                                        требуется для
                                        максимизации
                                        прибыли, неужели
                                        текущих метрик
                                        и&nbsp;данных
                                        не&nbsp;хватает для
                                        принятия решений?
                                        Нет, не&nbsp;хватает.
                                        Нет механик
                                        и&nbsp;сервисов, при
                                        которых умные
                                        скрипты </span><span class="c4">проставят</span><span class="c4">&nbsp;вам
                                        ставки,
                                        исходя
                                        из&nbsp;максимизации
                                        прибыли при
                                        заданных
                                        значениях
                                        конверсии,
                                        маржинальности
                                        бизнеса,
                                        стоимости </span><span class="c4">заёмных</span><span class="c0">&nbsp;средств
                                        и&nbsp;других
                                        бизнес-параметров.</span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Некоторые
                                        пытаются
                                        приблизиться
                                        к&nbsp;этому, но стоит
                                        упомянуть K50
                                        (оптимизатор
                                        умеет
                                        максимизировать
                                        прибыль) и&nbsp;тот&nbsp;же
                                        Roistat (робот на&nbsp;основе
                                        ROI).</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c75 c106 c93"><span class="c0">Куда
                                        движутся системы
                                        сквозной
                                        аналитики? Трудно
                                        сказать
                                        наверняка, но есть
                                        некоторые
                                        предположения:</span></p>
                        <p class="c75 c54 c106 c96"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_q1huati8nxr-0 start">
                                <li class="c34 li-bullet-0"><span class="c4">&nbsp;Упрощение
                                                и&nbsp;стандартизация
                                                интеграций. Пока
                                        </span><span class="c4">идёт</span><span class="c4">&nbsp;этап
                                                интеграции
                                                всего со&nbsp;всем,
                                                но&nbsp;скоро
                                                насыщение будет
                                                достигнуто,
                                                и&nbsp;останется
                                                только упрощать
                                                интеграцию
                                                до&nbsp;1&nbsp;клика
                                                и&nbsp;добавлять
                                                тонкие
                                                настройки
                                                в&nbsp;интерфейс
                                                вместо текущих
                                                скриптов и&nbsp;</span><span class="c4">вебхуков</span><span
                                                class="c0">.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_m2daq541vih6-0 start">
                                <li class="c34 li-bullet-0"><span class="c0">Замена
                                                маркетинговых
                                                метрик
                                                на&nbsp;бизнес-метрики.
                                                Т.е.
                                                из&nbsp;инструмента
                                                маркетолога
                                                система
                                                превращается
                                                в&nbsp;инструмент
                                                для всех&nbsp;—
                                                маркетолога,
                                                аналитика, РОПа,
                                                генерального
                                                директора,
                                                собственника
                                                бизнеса.
                                                Дашборды должны
                                                гибко
                                                настраиваться
                                                под каждого
                                                сотрудника.</span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 131 -->
                <div data-num="131" class="numNUMBER page-mimi" id="container-pagnation131">
                        <ul class="c9 lst-kix_2kzab2pzr8b9-0 start">
                                <li class="c34 li-bullet-0"><span class="c0">&nbsp;Увеличение
                                                точности данных
                                                за&nbsp;счёт более
                                                сложных моделей
                                                атрибуции
                                                и&nbsp;разделения
                                                алгоритмов
                                                по&nbsp;рыночным
                                                нишам/ портретам
                                                клиента. Модель
                                                атрибуции
                                                должна быть
                                                умной, на&nbsp;основе
                                                воронки и всех
                                                имеющихся
                                                данных.
                                                Представьте, что
                                                мы оцениваем
                                                вклад
                                                рекламного
                                                источника, в&nbsp;том
                                                числе
                                                анализируя
                                                записи
                                                разговоров
                                                клиента
                                                с&nbsp;менеджером.
                                                После
                                                одной&nbsp;рекламы
                                                звонок был
                                                по&nbsp;делу и&nbsp;привёл
                                                к&nbsp;продаже. После
                                                другой&nbsp;— звонок
                                                был,
                                                но&nbsp;к&nbsp;продаже
                                                не&nbsp;привёл.
                                                Алгоритм мог&nbsp;бы
                                                распознать
                                                голос
                                                и&nbsp;проанализировать
                                                с&nbsp;той или иной
                                                степенью
                                                достоверности,
                                                виноват&nbsp;ли
                                                менеджер, или,
                                                например,
                                                реклама обещала
                                                что-то
                                                не&nbsp;соответствующее
                                                действительности.</span>
                                </li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_xbd2x5vi0tol-0 start">
                                <li class="c34 li-bullet-0"><span class="c0">&nbsp;Помимо
                                                имеющихся
                                                метрик, можно
                                                ввести
                                                коэффициент
                                                лояльности&nbsp;— %
                                                влияния рекламы
                                                на&nbsp;повторную
                                                покупку.
                                                От&nbsp;0&nbsp;(повторную
                                                продажу делает
                                                только реклама)
                                                до&nbsp;100% (повторная
                                                продажа
                                                совершается
                                                независимо
                                                от&nbsp;рекламы).
                                                Коэффициент
                                                зависит
                                                от&nbsp;отрасли,
                                                известности
                                                бренда, его
                                                программ
                                                лояльности
                                                и,&nbsp;конечно,
                                                уникальности
                                                продукции. </span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_ujvjf85aw9bl-0 start">
                                <li class="c34 li-bullet-0"><span class="c4">&nbsp;Не&nbsp;забываем
                                                добавлять k-factor, т.е.
                                                рекомендации </span><span class="c4">—</span><span
                                                class="c4">&nbsp;банальный
                                                «сарафан». Если
                                                средний ваш
                                                клиент приводит
                                                ещё 0,5&nbsp;клиента,
                                                неверно это
                                                игнорировать
                                                при </span><span class="c4">подсчёте</span><span
                                                class="c0">&nbsp;эффективности
                                                маркетинга. ROMI и&nbsp;LTV
                                                нужно считать
                                                с&nbsp;его учётом. </span></li>
                        </ul>
                        <p class="c5"><span class="c0"></span></p>
                        <ul class="c9 lst-kix_efiu1zu5otsx-0 start">
                                <li class="c34 li-bullet-0"><span class="c4">&nbsp;Помимо
                                                предоставления
                                                набора
                                                дашбордов,
                                                BI-системы
                                                движутся
                                                в&nbsp;сторону
                                                поиска
                                                на&nbsp;естественном
                                                языке. </span><span class="c0">Т.е.
                                                системы должны
                                                двигаться
                                                в&nbsp;сторону
                                                интеллектуальности
                                                и&nbsp;из&nbsp;маркетингового
                                                инструмента
                                                превращаться
                                                в&nbsp;бизнес-инструмент.
                                                Что же, надеемся
                                                увидеть много
                                                интересного
                                                в&nbsp;будущем!</span></li>
                        </ul>
                </div>


                <!-- 132 -->
                <div data-num="132" class="numNUMBER page-mimi" id="container-pagnation132">
                        <h2 class="c74 c59 c65" id="h.3vn4cjj2g7pe"><span>Итог</span><a id="kix.1570gxjmoia"></a>
                        </h2>
                        <p class="c8"><span class="c0">Аналитика —
                                        важный
                                        инструмент
                                        повышения
                                        эффективности
                                        рекламы. В первую
                                        очередь нужно
                                        понимать, пришло
                                        ли время её
                                        внедрять или пока
                                        рано. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c0">Далее стоит
                                        выбрать
                                        инструменты
                                        исходя из
                                        возможностей
                                        вашего бизнеса и
                                        задач. Лучше
                                        внедрить более
                                        простой
                                        инструмент и
                                        начать извлекать
                                        из него выгоду,
                                        чем замахнуться
                                        на создание некой
                                        идеальной
                                        системы и
                                        переоценить свои
                                        ресурсы. </span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <p class="c8"><span class="c4">Также стоит
                                        помнить, что на
                                        успех маркетинга
                                        влияет далеко не
                                        только аналитика.
                                        4P никто не отменял,
                                        а если говорить об
                                        интернет-маркетинге,
                                        грамотная
                                        настройка
                                        контекстной
                                        рекламы и
                                        проработка
                                        связок
                                        (запрос-объявление-страница)
                                        позволяют
                                        существенно
                                        повысить
                                        эффективность
                                        работы. Пока у вас
                                        это не сделано на
                                        базовом уровне,
                                        сложную систему
                                        сквозной
                                        аналитики
                                        внедрять рано.
                                        Условно, сначала
                                        нужно добиться
                                        чтобы менеджеры
                                        брали трубку,
                                        потом чтобы они не
                                        посылали
                                        клиентов... к
                                        конкурентам, и
                                        только после
                                        этого
                                        выстраивать
                                        аналитику. Желаю
                                        всем поскорее
                                        пройти этот </span><span class="c4">нелёгкий</span><span
                                        class="c0">&nbsp;путь!</span></p>
                        <p class="c5"><span class="c0"></span></p>
                </div>

                <!-- 133 -->
                <div data-num="133" class="numNUMBER page-mimi" id="container-pagnation133">
                        <h2 class="c81 c65 c121" id="h.2qflbph2nyv4"><span class="c22 c10">В
                                        работе над книгой
                                        помогали</span></h2>
                        <p class="c8"><span class="c4">Книгу хочу
                                        посвятить своей
                                        жене и детям, без
                                        которых она была
                                        бы написана на 2
                                        года раньше.</span></p>
                        <h4 class="c82 c59" id="h.p48b4mg0ch84"><span class="c6">Редакторы:</span></h4>
                        <p class="c8"><span class="c0">Элина
                                        Махмудова</span></p>
                        <p class="c8"><span class="c0">Александр
                                        Керенский</span></p>
                        <p class="c8"><span class="c0">Карина
                                        Борская</span></p>
                        <p class="c8"><span class="c0">Светлана
                                        Папуша</span></p>
                        <h4 class="c59 c82" id="h.fhjzp9d0ei4f"><span class="c6">Иллюстратор: </span></h4>
                        <p class="c8"><span class="c0">Татьяна
                                        Иванова</span></p>
                        <p class="c5"><span class="c0"></span></p>
                        <h4 class="c82 c59" id="h.g2pm94beczwa"><span class="c6">Благодарности:</span>
                        </h4>
                        <p class="c8"><span class="c0">Виталий
                                        Трохин</span></p>
                        <p class="c8"><span class="c0">Олег
                                        Закутный</span></p>
                        <p class="c8"><span class="c0">Сергей
                                        Шивалин</span></p>
                        <p class="c8"><span class="c0">Артём
                                        Султанов</span></p>
                        <h4 class="c82 c59" id="h.s8dygbw0mdio"><span class="c6">Использованы
                                        материалы:</span></h4>
                        <p class="c8"><span class="c0">Ольги
                                        Миргородской</span></p>
                        <p class="c8"><span class="c0">Дмитрия
                                        Комаровского</span></p>
                        <p class="c8"><span class="c4">Марии </span><span class="c4">Бочевой</span></p>
                        <p class="c8"><span class="c4">Оксаны </span><span class="c4">Шейдаевой</span></p>
                        <p class="c8"><span class="c4">PromoPult Team</span></p>
                        <p class="c52"><span class="c10 c70 c124"><a class="c2"
                                                href="https://www.google.com/url?q=https://vc.ru/u/304035-promopult-team&amp;sa=D&amp;source=editors&amp;ust=1614119598596000&amp;usg=AOvVaw3ARvAhEUiKjISVJg_w_Q_v"></a></span>
                        </p>
                        <p class="c5"><span class="c0"></span></p>
                        <div>
                                <p class="c25"><span class="c42 c10 c38"></span></p>
                        </div>
                </div>
        </div>


        <div data-num="134" class="container-pagnation134" id="container-pagnation134">
                <ol id="tableOfContents" class="tableOfContents" onclick="pagination(event)">
                        <li id=""><a href="/страница-2" class="page-link" data-page=2 id="page">Дисклеймер</a></li>
                        <li id=""><a href="/страница-4" class="page-link" data-page=4 id="page">Предисловие</a></li>
                        <li id=""><a href="/страница-4" class="page-link" data-page=4 id="page">Базовые понятия
                                </a>
                                <ul>
                                        <li id=""><a href="/страница-5" class="page-link" data-page=5 id="page">Виды
                                                        источников</a></li>
                                        <li id=""><a href="/страница-6" class="page-link" data-page=6 id="page">Каналы
                                                        коммуникаций</a></li>
                                        <li id=""><a href="/страница-7" class="page-link" data-page=7 id="page">Путь
                                                        клиента</a></li>
                                        <li id=""><a href="/страница-7" class="page-link" data-page=7 id="page">Модели
                                                        продаж рекламы:</a></li>
                                        <li id=""><a href="/страница-10" class="page-link" data-page=10
                                                        id="page">Конверсия</a></li>
                                        <li id=""><a href="/страница-14" class="page-link" data-page=14 id="page">Как
                                                        увеличить конверсию?</a></li>
                                </ul>
                        </li>
                        <li id=""><a href="/страница-17" class="page-link" data-page=17 id="page">ROI (ROMI)
                                </a>
                                <ul>
                                        <li id=""><a href="/страница-20" class="page-link" data-page=20
                                                        id="page">Сквозной принцип в аналитике</a></li>
                                        <li id=""><a href="/страница-21" class="page-link" data-page=21
                                                        id="page">Логическая ошибка высокого ROMI</a></li>
                                </ul>
                        </li>
                        <li id=""><a href="/страница-23" class="page-link" data-page=23 id="page">Как считать?
                                        Пример:</a></li>
                        <li id=""><a href="/страница-26" class="page-link" data-page=26 id="page">Сквозная аналитика как
                                        жизненная необходимость</a></li>
                        <li id=""><a href="/страница-30" class="page-link" data-page=30 id="page">Кому нужна сквозная
                                        аналитика</a></li>
                        <li id=""><a href="/страница-31" class="page-link" data-page=31 id="page">Кому не обязательна
                                        сквозная аналитика</a></li>
                        <li id=""><a href="/страница-32" class="page-link" data-page=32 id="page">Проблемы внедрения
                                </a>
                                <ul>
                                        <li id=""><a href="/страница-33" class="page-link" data-page=33
                                                        id="page">Проблема 1: отдел продаж</a></li>
                                        <li id=""><a href="/страница-36" class="page-link" data-page=36
                                                        id="page">Проблема 2: техническая</a></li>
                                </ul>
                        </li>
                        <li id=""><a href="/страница-39" class="page-link" data-page=39 id="page">ROPO-эффект</a></li>
                        <li id=""><a href="/страница-42" class="page-link" data-page=42 id="page">Сквозной идентификатор
                                        на примере GOOGLE CLIENT ID</a></li>
                        <li id=""><a href="/страница-44" class="page-link" data-page=44 id="page">Модели атрибуции
                                </a>
                                <ul>
                                        <li id=""><a href="/страница-46" class="page-link" data-page=46 id="page">First
                                                        Click (FCM)</a></li>
                                        <li id=""><a href="/страница-46" class="page-link" data-page=46 id="page">Last
                                                        Click (LCM)</a></li>
                                        <li id=""><a href="/страница-47" class="page-link" data-page=47 id="page">Last
                                                        Non-Direct Click (LN-DC)</a></li>
                                        <li id=""><a href="/страница-48" class="page-link" data-page=48
                                                        id="page">Position Based (PB)</a></li>
                                        <li id=""><a href="/страница-49" class="page-link" data-page=49 id="page">Time
                                                        Decay (TD)</a></li>
                                        <li id=""><a href="/страница-49" class="page-link" data-page=49 id="page">Linear
                                                        model (LM)</a></li>
                                </ul>
                        </li>
                        <li id=""><a href="/страница-50" class="page-link" data-page=50 id="page">Выбор модели атрибуции
                                        и проблема стандартных вариантов</a></li>
                        <li id=""><a href="/страница-52" class="page-link" data-page=52 id="page">Алгоритмические модели
                                </a>
                                <ul>
                                        <li id=""><a href="/страница-52" class="page-link" data-page=52 id="page">Цепи
                                                        Маркова (Markov Chains)</a></li>
                                        <li id=""><a href="/страница-53" class="page-link" data-page=53
                                                        id="page">Атрибуция на основе данных (Data-Driven Attribution,
                                                        DDA)</a></li>
                                        <li id=""><a href="/страница-54" class="page-link" data-page=54 id="page">OWOX
                                                        BI Attribution</a></li>
                                </ul>
                        </li>
                        <li id=""><a href="/страница-56" class="page-link" data-page=56 id="page">Обзор сервисов и
                                        инструментов</a></li>
                        <li id=""><a href="/страница-58" class="page-link" data-page=58 id="page">Типы сервисов и
                                        инструментов
                                </a>
                                <ul>
                                        <li id=""><a href="/страница-58" class="page-link" data-page=58
                                                        id="page">Недорогие сервисы «всё в 1»</a></li>
                                        <li id=""><a href="/страница-59" class="page-link" data-page=59
                                                        id="page">Сервисы сквозной аналитики</a></li>
                                        <li id=""><a href="/страница-59" class="page-link" data-page=59
                                                        id="page">Кастомные решения</a></li>
                                </ul>
                        </li>
                        <li id=""><a href="/страница-63" class="page-link" data-page=63 id="page">Недорогие сервисы «всё
                                        в 1»
                                </a>
                                <ul>
                                        <li id=""><a href="/страница-63" class="page-link" data-page=63
                                                        id="page">Lptracker</a></li>
                                        <li id=""><a href="/страница-64" class="page-link" data-page=64
                                                        id="page">PrimeGate.io</a></li>
                                        <li id=""><a href="/страница-65" class="page-link" data-page=65
                                                        id="page">Expecto.me</a></li>
                                </ul>
                        </li>
                        <li id=""><a href="/страница-66" class="page-link" data-page=66 id="page">Сервисы сквозной
                                        аналитики
                                </a>
                                <ul>
                                        <li id=""><a href="/страница-66" class="page-link" data-page=66
                                                        id="page">Roistat</a></li>
                                        <li id=""><a href="/страница-68" class="page-link" data-page=68
                                                        id="page">Alytics </a></li>
                                        <li id=""><a href="/страница-69" class="page-link" data-page=69
                                                        id="page">Calltouch</a></li>
                                        <li id=""><a href="/страница-70" class="page-link" data-page=70
                                                        id="page">Comagic</a></li>
                                        <li id=""><a href="/страница-71" class="page-link" data-page=71
                                                        id="page">K50</a></li>
                                        <li id=""><a href="/страница-72" class="page-link" data-page=72
                                                        id="page">Kissmetrics</a></li>
                                        <li id=""><a href="/страница-72" class="page-link" data-page=72 id="page">Mango
                                                        telecom</a></li>
                                        <li id=""><a href="/страница-73" class="page-link" data-page=73 id="page">Sef
                                                </a></li>
                                        <li id=""><a href="/страница-74" class="page-link" data-page=74 id="page">Elly
                                                </a></li>
                                        <li id=""><a href="/страница-75" class="page-link" data-page=75
                                                        id="page">Smalldata </a></li>
                                        <li id=""><a href="/страница-77" class="page-link" data-page=77
                                                        id="page">Analyticsgroup </a></li>
                                        <li id=""><a href="/страница-78" class="page-link" data-page=78
                                                        id="page">Segmentstream </a></li>
                                        <li id=""><a href="/страница-79" class="page-link" data-page=79
                                                        id="page">Trackad </a></li>
                                        <li id=""><a href="/страница-80" class="page-link" data-page=80 id="page">Funnel
                                                </a></li>
                                        <li id=""><a href="/страница-81" class="page-link" data-page=81
                                                        id="page">Mixpanel </a></li>
                                        <li id=""><a href="/страница-82" class="page-link" data-page=82
                                                        id="page">Marketo </a></li>
                                        <li id=""><a href="/страница-84" class="page-link" data-page=84
                                                        id="page">Databox </a></li>
                                        <li id=""><a href="/страница-85" class="page-link" data-page=85
                                                        id="page">Hubspot </a></li>
                                        <li id=""><a href="/страница-86" class="page-link" data-page=86
                                                        id="page">Callibri </a></li>
                                        <li id=""><a href="/страница-87" class="page-link" data-page=87
                                                        id="page">Calltracking </a></li>
                                        <li id=""><a href="/страница-88" class="page-link" data-page=88 id="page">Alloka
                                                </a></li>
                                        <li id=""><a href="/страница-89" class="page-link" data-page=89 id="page">Quon
                                                </a></li>
                                        <li id=""><a href="/страница-90" class="page-link" data-page=90
                                                        id="page">Utmstat </a></li>
                                        <li id=""><a href="/страница-92" class="page-link" data-page=92
                                                        id="page">Smartanalytics </a></li>
                                        <li id=""><a href="/страница-93" class="page-link" data-page=93
                                                        id="page">ROMI.Center </a></li>
                                        <li id=""><a href="/страница-94" class="page-link" data-page=94
                                                        id="page">LTVytics </a></li>
                                </ul>
                        </li>
                        <li id=""><a href="/страница-96" class="page-link" data-page=96 id="page">Коннекторы</a>
                                <ul>
                                        <li id=""><a href="/страница-96" class="page-link" data-page=96 id="page">BI
                                                        Connect</a></li>
                                        <li id=""><a href="/страница-97" class="page-link" data-page=97
                                                        id="page">Owox</a></li>
                                        <li id=""><a href="/страница-99" class="page-link" data-page=99
                                                        id="page">Albato</a></li>
                                        <li id=""><a href="/страница-100" class="page-link" data-page=100
                                                        id="page">Renta</a></li>
                                        <li id=""><a href="/страница-102" class="page-link" data-page=102 id="page">BI
                                                        Data</a></li>
                                        <li id=""><a href="/страница-103" class="page-link" data-page=103
                                                        id="page">Supermetrics</a></li>
                                        <li id=""><a href="/страница-103" class="page-link" data-page=103
                                                        id="page">StreamMyData</a></li>
                                        <li id=""><a href="/страница-104" class="page-link" data-page=104
                                                        id="page">Менеджер Конверсий</a></li>
                                        <li id=""><a href="/страница-104" class="page-link" data-page=104
                                                        id="page">Системы веб-аналитики</a></li>
                                        <li id=""><a href="/страница-105" class="page-link" data-page=105
                                                        id="page">Яндекс.Метрика</a></li>
                                        <li id=""><a href="/страница-107" class="page-link" data-page=107
                                                        id="page">Google analytics</a></li>
                                        <li id=""><a href="/страница-110" class="page-link" data-page=110
                                                        id="page">BI-Системы</a></li>
                                        <li id=""><a href="/страница-112" class="page-link" data-page=112
                                                        id="page">Microsoft Power BI</a></li>
                                        <li id=""><a href="/страница-114" class="page-link" data-page=114
                                                        id="page">Tableau</a></li>
                                        <li id=""><a href="/страница-115" class="page-link" data-page=115
                                                        id="page">Google Data Studio</a></li>
                                        <li id=""><a href="/страница-117" class="page-link" data-page=117
                                                        id="page">CRM</a></li>
                                        <li id=""><a href="/страница-119" class="page-link" data-page=119
                                                        id="page">Битрикс24</a></li>
                                </ul>
                        </li>
                        <li id=""><a href="/страница-122" class="page-link" data-page=122 id="page">Рекомендации при
                                        внедрении сквозной аналитики</a></li>
                        <li id=""><a href="/страница-123" class="page-link" data-page=123 id="page">Пример кейса с
                                        Roistat</a></li>
                        <li id=""><a href="/страница-124" class="page-link" data-page=124 id="page">Магазин
                                        автозапчастей detali15.ru</a></li>
                        <li id=""><a href="/страница-126" class="page-link" data-page=126 id="page">Инсайты</a></li>
                        <li id=""><a href="/страница-128" class="page-link" data-page=128 id="page">Будущее</a></li>
                        <li id=""><a href="/страница-132" class="page-link" data-page=132 id="page">Итог</a></li>
                        <li id=""><a href="/страница-133" class="page-link" data-page=133 id="page">В работе над книгой
                                        помогали</a></li>
                </ol>
        </div>

        <script src="js.js"></script>





</body>

</html>